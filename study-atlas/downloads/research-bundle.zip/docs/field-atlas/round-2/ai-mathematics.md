# Round 2 — AI-assisted mathematics and independent mathematics peer review

Started from the actual six-report Round1 freeze. Re-read selected original passages and corrected only owned AI artifacts; no mathematics-peer file was edited. `ai-mathematics-checks.json` records sixteen actual passage matches, original capture hashes, derived-text hashes, calculations and final artifact identities.

## Own-domain repairs

- Made published threshold counts explicit: Siege has3/10 under mean correctness≥0.5, but2/10 under the stricter mean-grade-equals1 convention; Astra has7 versus5. Neither count is a claim of machine-verified or unanimously accepted new theorems. First Proof Table2 and its caption were checked directly.
- Expanded the corrected First ProofProblem2 statement to retain the order of quantifiers: one Whittaker functionW must be selected before varyingπ, whileV may depend onπ. The provider explicitly retracts confidence in this attempt. Added definitions for the newly explicit representation notation.
- Transcribed Problem4's Φ quantity in the exact organizer double-sum-of-squared-reciprocals form, rather than an algebraically related inner-sum-squared expression. The ledger now prioritizes exact source notation.
- Preserved the distinct contribution accounts: human recognition/repair and Jang–Ryu authorship in the NAG collaboration; author-reported model-origin proof strategy plus human checking/transcription in the MLE paper. Neither is silently converted into fully autonomous mathematical discovery.
- Strengthened the formal-proof boundary: selected Lean declarations, imports and checking instructions are retrieved artifacts; no Lean kernel, dependency-axiom audit or Comparator execution occurred. A formal proposition and its intended historical theorem also require statement comparison.
- Kept the three named October7 withdrawals specific. November24 strongly-polynomial LP and exactω=9/4 titles remain unverified source claims with original manuscripts unread and independent checks pending. Strong polynomiality and an exact exponent equality are not weakened into easier claims.
- Clarified the metadata index:730 unique PDF records remain unread-indexed. The373 family headings are what this parser recognized, versus375 declared by the catalogue; this is not proof the repository header is wrong. Two families may be unparsed, differently formatted or outside the selected view.

## Independent mathematics peer review

Read the captured abstracts and introductory theorem/definition passages, with exact PDF hashes checked:

- **Kakeya:** Wang–Zahlv1 Theorem1.1 claims full Hausdorff/Minkowski dimension inR3. Theorem1.2 explicitly leaves the maximal-functionK=3 conjecture unresolved. The peer chapter already preserves this distinction. A full-dimension set need not have positive measure: fixing binary digits at sparse positions2^j gives a measure-zero set of dimension1; its Cartesian cube supplies the corresponding dimension3 counterexample to that general implication. This is a logical scope check, not a counterexample to the Kakeya theorem.
- **Geometric Langlands:** PartIv3 explicitly says first of five papers, with an eight-person project. Its scope is global/unramified, characteristic zero; the introduction fixes a smooth complete curve and connected reductive group. PartI constructs the automorphic-to-spectral functor and compares formulations. A functor alone need not be an equivalence: the inclusion of a one-object discrete category in a two-object discrete category is a simple countercontrol. Requested the peer make the five-paper/global-unramified scope concrete without claiming all five proofs were read.
- **Moving sofa:** Definition1.1.2 requires a nonempty connected closed planar shape, continuously movable by orientation-preserving rigid motions through the specified unit-widthL. Requested explicit admissibility rather than only “body.” Area scales as the square of corridor width; the2.2195… constant belongs to unit width. The peer correctly avoids animation/numerical-candidate certification.
- **Hilbert6:** Theorem1 requires an existing Boltzmann solution with specified velocity-weighted bounds and the quantitativeα/A/time condition. Theorems2/3 fix smooth fluid solutions on their intervals; Theorem2 states the global-time extension conditionally. Requested these concrete limitations instead of generic “assumptions.” A derivation conditioned on an existing smooth solution cannot establish unconditional global regularity. The peer already correctly rejects all-of-Hilbert6 and arbitrary-fluid interpretations.

These findings were sent to root and the mathematics owner. No source-scope overclaim blocker was found in the inspected current peer chapter; the requested changes increase precision, not the claimed reading depth.

## Executed controls and integrity

Independently counted published versus strict grade totals. For a scalar Gaussian atn=2, forward-KL risk diverges because the inverse chi-square moment has a1/x singularity; reverse-KL risk is finite, EulerGamma/2≈0.28860783245. Computed truncated lower bounds grow with the logarithm of the cutoff, reinforcing why finite samples do not prove a finite expectation. A truth-table control shows thatP→P can be true whileP is false; a proof under an extra assumption cannot be advertised as an unconditional theorem. This does not allege that a particular retrieved certificate has such a defect.

Validated unique domain IDs, topic parent levels, every edge endpoint and24 source capture hashes. All730 index paths remain unique and unread. No external proof code was executed. The chapter remains within the requested substantial length. Source authenticity and integrated book/graph checks belong to root's independent pass.

## Frozen identities and decision

- AI dataset SHA-256: `2ad9b9bdfea1647f6d4281380ac02b3dd0189e16504827242c7a31cbd600b886`.
- Chapter SHA-256: `ee6521f4a37a2f6c3fc61ccfa9c92bdfba1f41cffefc93f5464f80204d1d3fd6`.
- Metadata index SHA-256: `fdad865795e6dc828f282f9f99b3387656d8a4a3accee7ae1e1e822ef2822c70`.

Admit the corrected selected corpus for final integrated review, with original-proof and independent-review gaps still visible. No newly certified major theorem, human peer-review panel, publication or extra research round is claimed.
