# Gravity specialist — adaptive round2

Started from the actual six-role round1freeze. Scope was the selected criticisms: repair truncatedDESIreading, deepen contemporarystrong-fieldsources, check GR/calculus hypotheses and independently test sensitiveconventions. No extra agent, laboratory result, new corpus-completeness claim or publication was added.

## Primary-source repair, actually executed

Retrieved fullDESIDR2arXiv2503.14738v3 under a32MBlimit:12,175,089bytes, no truncation, PDFSHA`1e82f26e4cc3901b16168cd147f252bfa804f9c3caad3f4f7e3532640d237841`. `pdftotext` succeeded. Read modeldefinitions/Eq10,§IIdata/selection/pipeline,BAO/composite-tracer covariancecontext,TableVIcombined-data comparison and§IXconclusions. The source state is now selected-text, replacing the disclosedR1abstract-only limitation. The original8MBfailure remains in its ownreceipt; no retrospective claim that it was a fullreading.

Important distinction preserved: BAOalone is well fitted byflatLambdaCDM. Stronger evolving-w preference depends on addingCMBand particularsupernova compilations; the inspectedversion reports2.8/3.8/4.2sigma forPantheon+/Union3/DESY5combinations. DR1is a subsetofDR2; correlatedtracers cannot be counted as independentreplications. The paper explicitly says w(z) is indirectlyinferred,not directlyobservable. Its likelihood andsystematic calibration were not reproduced here.

DeeperGWreading is now contemporaryrather than assuming olderGWTC3is latest. Retrieved complete2026GWTC-5.0testsPDF(arXiv2607.19293v1,21July2026;SHA`4ab5df879daa2f4acd2d9fac32e64f5daf78d8fddd73ba5d76ecc5a2047ab101`) and2025GW250114spectroscopyPDF(arXiv2509.08099v1,9September2025;SHA`8514216587c4a21797b6ebe69643712395daf280a3646542cbe8b8824892f809`). Read actualselection,model/systematic andconclusion passages recorded in `round2-reading-ledger.json`. TheofficialGWOSCindex also independentlycontainsGWTC4.0/4.1/5.0metadata labels. That index is a datedsnapshot,not a guarantee that every possiblelatestpaper was surveyed.

The2026preprint reports seven selectedtests on a cumulative168events and no significantbeyond-GR evidence within those tests. It deliberatelyomits some tests forknownbiases orscope, and reports ringdown finite-catalogue/systematic limitations. The2025paper supplies a decisive inferencecounterexample: a constrained440modefrequency cannot byitself establishmodepresence when a full-signal template enforcescontinuity andnonzeroamplitudes. These are author-reportedresults, not localdetector-data analysis. EHTand2026entanglementrecords remainmetadata-only; no forcedupgrade or quantumgravitymeasurement claim was introduced.

## Mathematics/geometry peer review

Read currentmathcalculus/geometrycards. FTC,DCT,Fubini,Radon–Nikodym,Banach andlocalinverse hypotheses are substantially retained in conditions/variabledefinitions. The uniformfunctionsequence example correctly warns that convergence doesnot authorize derivativeexchange. Concrete defects sent to the mathematicsowner: defineGauss–Bonnet's Riemannianmetric,dA,chi andpi; declareStokes d andboundarysymbols; do not imply selectedHatcherhomology/Euler-characteristic pages verify geodesic or differential-geometric proofs. Riemanniangeodesics and theirLorentzianextension require distinctmetric/variational language; proper-timestationarity is not a globalminimum claim. The owner acknowledged these andretrieved moreappropriategeometrysources; no peer files were edited.

OwnGRcards gained explicitregularity/distribution limits forPoisson; the static photon-frequency card now distinguishes localemitted/receivedphotons fromcoordinateclocktickrates and requiresmetricmatter/clockcoupling plus timelikestaticobservers. The Riemannsign matches the declaredRicci/Einstein convention. Friedmann keeps epsilon asenergy density and dimensionlessa withk in inverse-squaremetres; no silent switch tomassdensity orunitcurvature. CPLcontinuityintegration now connects to the actualDESIEq10, with its additional densityvariables defined.

Independentfrequency specialist checked clock/ringdown/chirp conventions and numericalexamples; no scienceblocker found. Theirclarification about photonredshift versusidenticalclockcoordinate rates was applied. Shared model lineage and source dependence remain acknowledged; this is model-agentreview,not humanpeer review.

## Executed independent counterchecks

`python docs/field-atlas/sources/gravity/check-round2.py` passes. A flatpolarplane has nonzeroGamma but zeroRiemann; the opposite would be a coordinateartifact. Metricclock tickratio and photontransfer ratio are reciprocal. The integratedCPLdensity at a=.5,w0=-.8,wa=-.6 is1.07060443695times its presentvalue and its analyticlogderivative satisfies continuity. Theuniformbound forsin(nx)/n tends tozero while derivatives atpi alternate(-1)^n. Pointpotential is harmonic only off its singularsupport; its distributionalsource is not discarded. Theweak-fieldtrace check gives thecorrect4piG coefficient; dropping trace produces an erroneousfactor2.

`check-corpus.py` validates77topics,45formulas,20sources,12paperreviews,allparent/edge/citation IDs andall20capturehashes. Numeric/dimensionalspotchecks stillpass. These are analytic/algebraic controls and numerical spotchecks,not aCASproof of everytensorequation or empiricalreplication. R1frozenreceipt was preserved byte-for-byte; currentvalidator receipts now write toround2.

## Decision and round3 gates

Accept the R2source-depth andscope repairs. The chapter has approximately7865words and its currentreading labels are consistent with the updatedcatalogue. Finalintegrated review must verify served/book/graphexports use the latestJSON andchapterhashes, all formula variables/limits remain visible, and the new2026GWpreprint is not presented as exhaustiveSOTA or a universalverification ofGR. Source-specificmodel/datasetconditionality, EHT/entanglementunreadstates, metric/energy-densityconventions and absenceoflocalmeasurements must survive renderer/export integration. No further sourceexpansion is required before thesegates.

Current artifact hashes:

- `public/study-atlas/data/gravity.json`: `5f7dc550501117d05ee4ece6c225acade286dab0b1fe1b2025c7d2d2b563a15f`
- `public/study-atlas/chapters/gravity.md`: `bcff542d102fa028b8c8f9c056bc3de7a3fee982a5f55a6145ad78fff79c762f`
- `docs/field-atlas/sources/gravity/round2-reading-ledger.json`: `8cb8ba2f409a4b3362bb952f75ed2650a1367801c4b0d98c5b33fea0c505bd2c`
- `docs/field-atlas/round-2/gravity-checks.json`: `a5917784f9229586f2a066a389832c8728b32e010d30f04e1650bd40398c5ba3`
- `docs/field-atlas/round-2/gravity-counterchecks.json`: `5982e2dca1bdf15f76ca31fc9dfaa3867642bd72eacf5126da06248ea41ce0a0`
