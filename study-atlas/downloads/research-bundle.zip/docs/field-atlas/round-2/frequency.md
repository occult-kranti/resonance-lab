# Frequency specialist: adaptive round 2

Started from the six-role first-round freeze. This round responds to convention, source-depth and clock-interpretation objections; it does not pre-execute final acceptance. Owned frequency artifacts now contain **73 topics, 42 formulas, 18 sources, six primary-paper reviews and 246 edges**. The coherent chapter is **6,938 words** by the retained regex counter. No peer file, DSP, playback or deployment was changed.

## Corrections and deeper evidence

Independent electrostatics reviewer confirmed the forced-response sign, e^(iωt) convention, gamma=b/(2m), free/forced-frequency distinction and weak half-power Q scope. The reviewer identified exact legend gaps, now repaired: sampling f_max and theorem bandlimit B have local definitions; the convolution record defines h(t), x(t), the convolution integral and Fourier operator, with time-kernel and transfer-function units. The previously unused output variable was removed from that equation’s dictionary.

Added explicit one-sided PSD factors: double only real-data positive interior bins; preserve DC and the even-N Nyquist endpoint; odd N has no Nyquist endpoint bin. Added the full-width/half-width distinction and amplitude-versus-energy ring-down rates. Source-room and general theorem edges remain contextual/ingredient support, not claims that the checked text originally proved every atlas equation.

Deepened two **actually accessible existing full-XML sources**. Exact source bytes remain pinned; new named section records and actual body text are in `sources/frequency/body-review-r2.json`:

- **2026 thorium feedback clock:** read Clock operation, Clock performance and Prospects. The body distinguishes within-run Allan instability from about5×10⁻¹³ between-day reproducibility and reports crystal-position line-centre differences up to1.7kHz. Host strain is a proposed explanation, not an established new location interaction. Feedback integration and Allan averaging times are distinct. Future power/linewidth improvements remain projections. Source record, paper review and chapter now retain these limits instead of allowing a narrow-line/lock headline to imply validated absolute accuracy.
- **2026 continuous strontium interrogation:** read Clock spectroscopy with Fourier-limited resolution, Discussion and BBR shift. The reported1.2Hz line follows0.75s transit through12mm at16mm/s. The body identifies a rectangular-time Fourier profile, cooling-light/dephasing effects, finite response/transport-delay constraints, and approximate BBR weighting with later thermometry. It explicitly leaves closed-loop dead-time-free stabilization as future work. A narrow excitation spectrum is not a complete new clock-accuracy evaluation.

These findings motivate the 42nd formula: a rectangular coherent interaction produces normalized sinc-squared power and full half-power width≈0.885893/T. It cannot be substituted into the Lorentzian field-coherence relation1/(πτ_c). All symbols, sinc convention, weak-excitation/shape assumptions, derivation, example and failure cases are explicit. The two2024 thorium papers remain **abstract-only reviews**; no full-methods precision validation was inferred.

The current2022 CODATA registry was checked: h,c,e,k_B exact; mu₀ and epsilon₀ experimentally determined with uncertainty. A repeat NIST table request returned403. Rather than invent a successful retrieval, the new frequency source reuses the moderator’s byte-identical prior raw capture and original retrieval metadata; its SHA matches `data/constants.json`. The failed attempt and reuse boundary are recorded separately. The chapter now states why historical4π×10⁻⁷ is approximate for mu₀ after the SI revision.

## Executed independent controls

`python3 docs/field-atlas/sources/frequency/round2_checks.py`: **18 controls pass**, receipt `round2-checks.json`. Direct finite DFT sums independently verify two-sided/one-sided mean-square agreement for even and odd N, including a periodic window. DC and Nyquist pure signals explicitly reject blanket times-two conversion. A root search of the mechanical half-power denominator gives angular FWHM≈10.0002500 rad/s for gamma=5s⁻¹, consistent with the weak-damping2gamma limit while preserving the small correction. A separate sinc-squared half-power root gives coefficient0.8858929413789 and1.1811905885Hz for a0.75s rectangle.

Independent crest tracking and adjacent-wave phase differences give phase/group velocities6 and12m/s for the stated quadratic dispersion. This says nothing by itself about a causal signal front or superluminal messaging. Complex-tone alias controls and a family of reciprocal source/channel rescalings explicitly preserve identical sampled/output data, demonstrating nonunique inversion rather than merely asserting it.

The original16 arithmetic controls were rerun through a **round-two receipt**, together with ID/reference/parent-level, formula-field, all18 raw capture-hash and chapter-word checks. Original first-round `checks.json` was restored byte-for-byte from its frozen output, retaining its original hash; R2 uses separate `round2-schema.json` and output files. No earlier result was rewritten to imply it had tested the revised corpus.

## Gravity peer review

Read the first-round gravity chapter/formula records for proper time, static photon redshift, Schwarzschild lapse, inspiral phase/frequency, amplitude and ring-down. No sign or angular-frequency defect found in that scope. Independent substitutions give photon ratio0.9999989999995, chirp12.4873989244Hz/s and strain scale2.56095036×10⁻²³, consistent with the rounded examples. The e^(−iωt) convention with omega=2πf−i/τ decays correctly.

Sent the owner a clarity refinement: a static emitted/received photon-frequency ratio must remain distinct from identical local clock-transition frequencies and from coordinate proper-rate comparison. A higher static clock can run faster relative to coordinate time while a photon climbing out is received redshifted; those are different comparisons. The owner retains peer-file changes. No new Allan or spectral-likelihood claim was attributed to the gravity chapter where it did not make one.

## Supported result and final-round criteria

Accepted locally as a revised, internally linked, source-bounded learning corpus with executed counterexamples. It does not determine unknown instrument transfer functions, recover phases from magnitudes, make group speed into a causal-front measurement, establish a nuclear-clock systematic budget, or predict health outcomes.

Round3 should inspect the actual integrated book/graph and formula rendering: repaired local legends, PSD endpoint rules, linewidth/coherence distinctions, visible2024 abstract-only status, body-qualified2026 performance, CODATA exactness, citation targets and final artifact hashes. It should also ensure source labels remain reading-depth statements rather than automatic authority/causal edges. Full experimental uncertainty reanalysis, independent replication, complete transform/Floquet proofs and exhaustive current clock rankings remain finite limitations. No further source expansion is requested for that final round.
