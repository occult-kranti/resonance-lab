# Electrostatics round 2 — independent sign, ensemble and source-scope review

Reviewed 2026-11-25T06:51:11.320206+00:00 after the actual six-report round 1 freeze `2026-11-25T06:42:36.560728+00:00`. This is an AI software-agent review with shared model lineage, not human peer review, historical participation or a laboratory test. No peer dataset, root graph/document code, existing application or published site was edited. No new agent was spawned.

## Incoming evidence and peer criticism

Read the frozen magnetism/frequency reports and targeted current formula records. The magnetic B=mu0(H+M), free/bound current distinctions, vacuum Poynting and energy conditions, positive-gamma LLG convention and SI magnetoelectric coefficient were consistent in the inspected equations. A no-free-sheet interface with tangential H=100A/m and permeability doubling has B doubling: continuity of all components of B and H would be wrong. Magnetic gamma has units rad/(s*T), whereas the frequency chapter's damping gamma is an amplitude decay rate in1/s; matching glyphs are not matching physical quantities.

The frequency response uses e^(i*omega*t), has the correct viscous sign, distinguishes the displacement peak from the undamped frequency and keeps Q/half-power linewidth in its weak/narrow regime. An independent local Lorentzian check with omega0=1000/s and gamma=5/s gives full half-power width1.591549Hz and Q=100. Carrier, source, transfer channel and observed peak remain separate; no unique causal frequency was inferred.

Concrete dictionary defects were sent to the frequency owner: Nyquist used f_max/B without complete matching local definitions, and convolution used h(t),x(t),convolution/transform operators without their full time-domain/unit legend. The owner acknowledged and repaired those records. The magnetic owner was alerted to known source-pairing limits: a MuMax paper is not the original Curie theorem source, and a current moire paper is not a direct GL foundation. These are source-scope issues, not new evidence against the equations. No mathematical peer blocker was found in the targeted review.

## Independent executed controls

Reproduction: `python3 docs/field-atlas/sources/electrostatics/round2/counterchecks.py`. Exact/numerical receipt: `docs/field-atlas/round-2/electrostatics.checks.json`.

- Pure-Neumann Poisson: exact Fraction arithmetic on 8 cell-centred cells gives rank 7 and constant gauge kernel. rho=2, epsilon=1, outward g_left=g_right=−1 admits phi=x−x² shifted to mean zero. RHS sum is0. Changing the right flux to0 makes RHS sum 1/8 and augmented rank 8, proving inconsistency, not merely failure of an iterative solver.
- Single electric/TM zero-mode sector: independent quadrature of u*log(1−exp(−u)) on[0,40] at 40000 and 80000 intervals gives -1.2020568839053891, versus−zeta(3). Its planar prefactor produces -2.47627977526e-11J/m² at 300 K/2 micrometres, relative error -1.6e-08. Adding an ideal TE zero mode doubles it, deliberately failing the stated one-electric-sector model.
- Series negative capacitance: Cs=1nF,Cf=−2nF gives positive local total curvature and Ctot=2nF. Cf=−.5nF gives negative curvature. Local stabilization is not global-domain stability, leakage control or an experimental device claim.
- Plate force: independently differentiating G=U−VQ=−CV²/2 gives -3.98438451884e-07N at the declared geometry, while differentiating only U at fixedV gives the opposite sign. Source work -3.98438451846e-10J plus external mechanical work 1.99219225923e-10J equals field-energy change -1.99219225923e-10J.

These are declared analytic/discretized controls, not a proof of every continuum/model statement or physical measurements. The zero-mode computation tests the selected static sector, not the full retarded Casimir interaction.

## Repairs to owned electrostatics records

The Laplace uniqueness entry now states connected Lipschitz-domain, positive-permittivity, constant-epsilon versus heterogeneous-operator and gauge/compatibility qualifications. All-Neumann compatibility is required componentwise and cannot be hidden by pinning a numerical node. Fixed-voltage force now gives the Legendre transform and explicit source-port work, with G,U,epsilon and area defined. Landau curvature is labeled local, with global competing minima/domains and bounded-polynomial conditions separate. The zero-mode derivation now shows half-weight, transverse measure, substitution and zeta-series factor. Counterion Xi is derived from explicitly defined Bjerrum/Gouy lengths, rather than attributed as an original theorem of a 2026 context paper.

The 1991 Nonnenmacher–O’Boyle–Wickramasinghe KPFM paper was resolved through actual Crossref metadata and its deposited abstract, SHA `81cdb5ca9c5fd9c8bc8db111d031c89405cd75112ecd8aa86476eaaa62a16900`. Its public review is explicitly abstract/metadata-only. The source identifies an early imaging concept; the chapter's first-harmonic identity is independently derived from its declared force law, not falsely claimed as a checked original-paper equation. A guessed early strong-coupling DOI returned 404 and is retained only as a private failed attempt. Broader review searches timed out and were not counted as read sources.

## Deeper 2026 source reading

Actual selected-passages reading was expanded in the already-pinned full HTML captures. The cylindrical-capacitor Results subsection and Fig2 caption identify opposite curvature trends for reversed layer order; opening structural-method text was read, but full electrical extraction/supplements were not. The KS–PB Results opening and full Conclusions show Friedel oscillations absent in the orbital-free comparison, interface spillover/capacitance differences and dependence on functional/solution assumptions. Their laterally uniform 1D benchmark is not exact molecular electrochemistry or a universal functional ranking. Exact source paths/sections/depths are in private `round2/reading-notes.json` and public records. No quoted fabrication recipe, apparatus performance or independent replication was imported.

## Changed artifact, validation and round 3 gate

Current corpus: 78topics, 42formulas, 16sources, 7paper reviews; chapter 5977words. All source bytes/SHA and local ID/citation/edge references rechecked. KaTeX/book generation remains root's gate, not falsely claimed by this domain check.

- Revised JSON SHA-256 `56ee3d5f9915574cc2cb73a70de5b235cef7431db54df870a4fe0a3d73c436c6`.
- Revised chapter SHA-256 `dbbf71178e14ca79f5eeb7b4a0ad8e05d6c7c51800d479f8a444cbcb77054905`.
- Countercheck script SHA-256 `a799a9ea894ba21f085327ba5365706bf8c45373a57818512c85fb8642e6d3a2`.

Accept the revised conditional electrostatic identities and the stated reading-depth improvements. Round3 should inspect the changed combined appendix/graph for complete variable and source-type display, especially G versus U, the Neumann physical-flux minus sign, one zero-mode polarization, Xi as a model definition, and metadata-only KPFM context. Verify fixedV work/series stability and the finite-domain Neumann counterexample against the final hashes. Keep mapped lines, failed leads and untranslated context sources visibly separate from checked foundational equations. Do not certify every source theorem, material parameter, current paper or instrument from this selected corpus.
