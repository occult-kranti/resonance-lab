# Magnetism specialist — round2 actual repair and independent peer review

Input freeze: `docs/field-atlas/round-1/freeze.json`, six actual R1reports frozen06:42:36UTC. Role remains a contemporary software-agent specialist; no historical participation, human peer review or physical experiment. R1report unchanged. No source/publication outside the owned magnetism files was altered.

## Peer electrostatics review

Read the actual chapter and formula records es-f12/13(field/source energy),es-f21(series negative-capacitance stability),es-f23(Poisson–Boltzmann),es-f31–33(quantum/geometric capacitance),es-f35(fluctuation ensemble),es-f36(single static electric Casimirsector). No blocking sign, SI or stability defect found. Sent owner/root the recommendation to make G=U−VQ and VΔQexplicit; owner confirmed adding the full source-port derivation.

Independent controls in `magnetism-controls.json`: fixedVsource work9.8379864653e−12J splits into field storage4.9189932327e−12J and mechanical work4.9189932327e−12J, residual−6.46e−27J. FixedQand fixedVforces at the same initial state agree at−4.4270939094e−8N. The Cs=1nF,Cf=−2nFseries curvature is positive;Cf=−0.5nFmakes it negative. A40000-panel Simpson evaluation of the dimensionless static electric-sector integral gives−1.20205682614 versus−zeta(3)=−1.20205690316,error7.70e−8; the half-weight zero mode yields the existing16pi denominator. These are deterministic model tests, not device data. PB’s point-ion/mean-field/reservoir limits and the quantum-capacitance DOS/interaction restrictions remain explicit. No universal resonance, biological or energy-source bridge was admitted.

## Own source and model repairs

Magnetism now has90topics,43formula records,20actually retrieved sources and9paper reviews. Added direct primary teaching texts: David Tong statistical physics§5selected mean-field/validity/Landau passages; MIT6.763Lecture4London equations; MITLecture10supercurrent/fluxoid quantization. Public source notes identify equation-image/OCR limits. An HTTP200CERNantibot page was correctly rejected as substantive source text. Other exploratory404s are not counted as sources.

The previous weak GL→graphene ingredient pairing was removed. GLnow explicitly cites Landau/phase/flux ingredients and states that a direct original GL/Hc2source was not reviewed; the orbital expression remains a conditional explanatory linear-GL reconstruction. This limitation is retained rather than inventing a new reading claim. The classical Curie1/3factor is independently obtained from the orientation partition function; Tong’s Ising normalization is distinguished.

The2026RuO2source was deepened by actually retrieving `ruo2-2026-body.pdf`,SHA256`0e4faaee8ff19d1bfec961d42e81107906d137954fbd9842be415c5a1b689355`,and reading selected introduction,experimental-principle/sample and discussion/interface paragraphs. The record now says selected-text rather than abstract-only. No supplement/raw trace/model fit was reanalysed. The2025functional study additionally records selected Methods andground-state passages:elkFP-LAPW,9×9×13mesh,Liechtenstein+U/FLL,fixedJ=0.5eV andlocal-sphere moment definition. Material/channel/functional dependence remains, with no universal RuO2absence or MnTe-to-RuO2transfer asserted.

## Physical inverse witness and conventions

New `mag-f-inverse-witness` defines two fixed-position z-directed dipoles and a Bzobservation. The1×2matrix(c,c),c=1.2521980672e−8T/(A m²),hasrank1/nullity1and kernel(1,−1),despite its positive singular value. Three centred heights give a3×2matrix stillrank1/nullity1. Adding an off-axis channel creates a2×2matrix with determinant1.8688737689e−16[T/(A m²)]²andrecovers(2,1)toerrorbelow1e−12. Thezero-coupling exceptionh=a/sqrt2andthe distinction between injectivity andconditioning are explicit. This is a restricted forward-operator proof, not a continuum uniqueness claim.

Eight executed base-dimension controls cover B/H,exchange field,DMIenergy density,LLG rate,spin angular-momentum flux andmagnetoelectric cross derivatives. A finite-difference cycloid yieldsDq=9999.99999J/m³against10000J/m³. The spin Hall scalar now fixes axes and distinguishes conversion ratios from probabilities. MEconversion requires volumetric moment normalization,knownD(E)andpotentially a real layer thickness; no thickness was fabricated. Positive-gamma LLG remains explicitly different from the source’s plus-prefactor gamma_LLnotation, with R1’s independent norm/passivity controls retained.

## Frozen output and remaining questions

- Data SHA256: `b434b67c8b611677636552f40662969331587901d297ca9c93ecb58b3668fae3`.
- Chapter SHA256: `70a011891ea65fdf70fc09c37cdff02eddda7339b00f1e25b67ed003c8650d72`; 7920words.
- Controls SHA256: `3c3265e87f5eeef56e09a9f200c65b94a07495b1f6ebd4dcf2ff94d884034cab`.
- All20current capture hashes match; all43formula records have the required dictionaries/examples/limits; no dangling local edge/ID detected.

Adaptive next gate: root’s final integrated documents/graph should preserve the repaired source statuses and explicit GLsource gap, current43formula count, inverse rank/nullity distinctions and B/H/spin-current/MEunits. Abstract-only papers remain limited; no experimental replication, MuMax execution, DFT rerun, full-scope SOTA or legal certification is claimed. Only actual round2is frozen here; R3awaits root’s revised integrated artifact.
