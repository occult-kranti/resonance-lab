# Field Study Atlas: frequency specialist, round 1

Applied the resonance-research-advisor, opensync-audio-research and paired-physics-research skills. This is one contemporary software-agent contribution, not human peer review, historical participation or a laboratory result. Read the shared `CONTRACT.md` and used its exact field-study-domain/v1 shape. Only assigned new frequency files were edited; no core DSP, existing application, source selection, audio playback, push or publication changed.

## Delivered artifacts

- `public/study-atlas/chapters/frequency.md`: **6,501 words**, a coherent learner path through phase/time, units, dynamics, modes, propagation, transforms, sampling, local analysis, quantum spectroscopy, clocks, selected modern papers and inverse inference. The chapter is separate from the machine-readable technical appendix.
- `public/study-atlas/data/frequency.json`: **73 topic nodes** at levels 0–4, **41 formulas**, **17 source records**, **6 bounded primary-paper reviews**, **242 typed edges**, glossary and three explicit open questions. Reviewed formula-bearing topics, mapped specialties and source reading states are distinguished.
- Private retrieval receipts, raw captures, normalized text, generators and executed checks under `docs/field-atlas/sources/frequency/`. Public records contain original notes/links/hashes, not raw full-text redistribution.

Formula records identify symbols, SI or mathematical units, conditions, derivation steps, worked examples, limiting/null cases and pitfalls. Overloaded k (wave number versus bin), N (sample count versus noise transform), X(f)/X(s), wavelet scale units, peak/half-power and phase conventions are scoped. Feynman’s source damping gamma is explicitly translated: gamma_source=b/m=2 gamma_atlas, with atlas gamma=b/(2m). Exact transform-theorem statements have sufficient L1, L2, periodic-coefficient or sampling hypotheses rather than a claim that arbitrary signals satisfy them.

## Actual retrieval and reading

The 17 public source records point to captures whose SHA-256 bytes were verified. Foundations include the BIPM SI brochure, NIST SP1065, selected Feynman oscillator/resonance passages and official NumPy/SciPy/PyWavelets/SymPy conventions. Current documentation versions are recorded when visible; unknown revision dates are not invented.

Six primary-paper reviews cover the 2024 thorium laser-excitation and atomic/nuclear-ratio work, plus actually retrieved 2026 nuclear feedback, continuous strontium interrogation, comb ranging and Floquet-chirality papers. The 2024 Nature ratio page exposes only abstract/captions: the record says **abstract-only**, not full-text review. Tiedau 2024 is likewise a DOI/deposited-abstract review. The four 2026 XMLs were retrieved in full, but the actual selected sections read are individually named; a downloaded XML is not a claim to have audited its complete experimental methods or uncertainty budget. Projected future improvements and source-author claims remain qualified.

A guessed arXiv URL returned HTTP 200 with an unrelated adsorption paper. Title/content inspection caught the identity mismatch. It remains a private failed lead and has no public evidential edge; the verified DOI/deposited abstract replaced it. A later Crossref lookup for the 2024 optical-clock uncertainty title returned metadata without an abstract; it also remains private and is **not counted as a reviewed source or used for a performance inference**. Captures and hashes establish identity, not truth, completeness or independent replication.

## Executed checks

Command: `python3 docs/field-atlas/sources/frequency/checks.py`. Actual receipt: `checks.json` and `checks-output.txt`. Passed unique IDs, every topic-parent level, all formula/topic/source/paper/edge references, required formula fields/variable dictionaries, all 17 capture hashes, cutoff years and the 5–8k chapter-word gate.

Sixteen numerical/algebraic controls pass: period/angular conversion; forced-response peak versus an independent dense denominator scan; distinct damped/free/forced frequencies; cavity scale doubling; independently summed DFT of a known vector; Parseval; alias-equivalent tones; disappearing Nyquist sine; periodic-Hann coherent gain; beating sum/product identity; Planck/nuclear-energy unit conversions; Allan worked example; constant-bias Allan null; correlated-error cancellation; explicit source/channel non-uniqueness; and comb-index arithmetic. These finite controls neither prove the infinite-dimensional theorems nor reproduce the cited experiments.

## Supported result and objections for adaptive round 2

Accepted locally: this is a populated, internally linked selected frequency corpus with original explanatory prose, explicit source states and executed representative controls. It demonstrates why carrier, modulation, natural mode, forced-response maximum, measured channel spectrum and quantum transition are different notions. No inherent single frequency is assigned to a person, object, monument or image, and no healing or extraordinary-force claim follows from arithmetic.

The moderator should select the next round from real criticisms. Highest-value checks are independent formula-symbol/hypothesis review (especially wavelet units, loaded-Q linewidth and Floquet conventions), primary-source claim/read-depth review, and a cross-domain metrology check of covariance and gravitational clock comparison. A full modern clock ranking, detailed systematic-shift budgets, all wavelet/transform theorem proofs, a comprehensive 2026 literature search and independent experimental replications remain outside this first-round scope. Some source edges provide ingredient/context support rather than an exact transcription of a source equation; those relationships are labelled accordingly.

No round 2 or 3 has been pre-executed or inferred. Root retains selection of the next objections after all six first-round reports freeze.
