# Round 1 — AI-assisted mathematics evidence specialist

Delivered the domain dataset and 6,780-word chapter. The selected corpus has 45 topics, maximum depth 5 (root level 0), 20 claim records, 25 sources, five paper reviews, four mathematical/scoring entries and an explicit glossary/open-question register. All IDs use the ai- prefix. Raw captures remain under docs/field-atlas/sources/ai-mathematics; no other domain or core UI was modified.

## Retrieval and actual reading

Retrieved official OpenAI/Anthropic/DeepMind sitemaps and followed actual linked original manuscripts, First Proof statements/reviews, Epoch/arXiv records and source-code artifacts. Used urllib HTTP captures with exact SHA-256 and timestamps, a local HTML text extractor, and pdftotext for selected PDF sections. The current clock verified the November 25 2026 cutoff. Source records list precise sections and versions. Downloaded long proofs are not classified as fully read.

Key originals: Jang/Ryu arXiv2510.23513v2 (January19 2026), Sellke/Yin's learning-curve manuscript, February20 First Proof attempts and organizer statements, August6 ten-advances manuscript, and independent First Proof Third Batch Hexagon2610.00244v1 (October14 2026). Selected actual Lean declarations were inspected but no downloaded code, Lean build or Comparator command was executed.

Direct Erdős183 retrieval returned HTTP403 and remains an inaccessible lead. One guessed Navier–Stokes announcement path failed; it was not promoted into a source or solved-problem case. The current repository history's November24 linear-programming and matrix-exponent titles are explicitly announcement-only pending claims, not verified theorems.

## Findings supported by the retrieved record

- Nesterov point convergence is an AI-assisted human research collaboration with exact mathematical hypotheses and a concurrent-work qualification. The provider itself describes a decisive suggestion as incorrect as written; Jang and Ryu supplied mathematical development and authorship.
- Gaussian MLE learning-curve monotonicity has a precise forward-KL finiteness threshold. The original assistance statement distinguishes model-origin strategy from human verification/transcription and records a reverse-KL prior-art connection.
- OpenAI's February20 article explicitly withdraws its initial confidence in First Proof Problem2. Its favorable estimates for other internal-model attempts are provisional company assessments, not automatically the early organizer baseline's verdict.
- Independent third-batch report Table2 uses correctness threshold0.5: Astra7/10, Siege/Claude Opus5.5 3/10, ProofCouncil9/10. Siege's three include a minor-gaps0.5 result; five tasks had no submission. Correctness, exposition and attribution remain separate axes.
- A concrete Claude hyperfield counterexample is rated mathematically correct by all three referees, with criticism of attribution to existing constructions. This is documented research-problem solving, not established first discovery.
- August results have actual manuscript/Lean artifacts, but this atlas did not execute their checking tools or independently validate the major theorems. October history records three specific withdrawals after a sign error. A scholarly MathHelm guest essay says broad human review remains incomplete; it is not a verdict on every manuscript.
- IMO and FrontierMath entries are labeled competition/benchmark evidence, with tool/time/track limitations. No benchmark score becomes a new-theorem count.

## Executed validation and counterchecks

The source-owned validation.json records unique IDs, parent/level checks, no dangling edge endpoints, source-reference checks and 24 successful exact-byte capture-hash comparisons. Scalar checks independently recompute Gaussian forward-KL E4=0.3648185772692609 and E6=0.16208602321517862, Siege's threshold count3, and the two-by-two permanent10. A two-vertex PSD example is explained analytically. These checks do not validate the surrounding frontier proofs.

## Objections and Round 2 targets

The largest gaps are claim-specific independent reviews of August/October theorems, a clean kernel/axiom/statement-comparison receipt, the inaccessible Erdős database status, the original November24 manuscripts, and the concurrent NAG paper. The Darcy problem's formal dimension and its motivating discussion differ in the printed report; this inconsistency is preserved rather than silently repaired. Provider attribution and exact formal-statement fidelity remain separate from proof-source availability.

Round 1 admits this corpus as a substantial source-pinned claim audit, not a certified list of solved open problems. Root should target these objections after all six first-round reports freeze. No publication, push, claim of human peer review or additional panel round occurred.

Frozen artifact SHA-256: data `dedff13e3070da59b33a320d20fc713eb9821b20c9fb8d25da544975df2f377a`; chapter `f9511723d11c03a37dfd8a3bdd9f5ee2d755a18fa16c9ffb712673b18c451bf3`.
