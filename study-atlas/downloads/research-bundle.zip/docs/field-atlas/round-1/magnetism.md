# Magnetism specialist — round1 freeze

Role: contemporary software-agent magnetism specialist, not Tesla or another historical person's participation. Read resonance-research-advisor, paired-physics-research and the previously consulted Tesla mechanism/resonance skill and research reference. Raw source captures remain under the private domain source directory; no publication or push performed.

## Concrete deliverable

- `public/study-atlas/data/magnetism.json`:90meaningful topics, maximum level6 (including root0),42formula dictionaries,17actually retrieved sources,9primary/preprint review records,289typed edges,21glossary entries and7open questions.
- `public/study-atlas/chapters/magnetism.md`: 7946words, organized by physical scale/branch, with conditional derivations, worked cases, frontier comparisons and explicit non-uniqueness/source-status limits.
- Data SHA256: `2464933b3c7e0c7c7f5a07027dc32cb00e4fa13f26410fe700638ac8315b8b09`.
- Chapter SHA256: `615a220321934116660e5529550b73fa16d2ce37d4ee1831d5140ba0a86231a9`.
- Actual reading statuses: {'selected-text': 12, 'abstract-only': 5}. Selected text is not full-paper review. Abstract-only reviews explicitly say so and were not promoted to full methods/result validation.

The taxonomy covers steady fields/B versus H/free versus bound currents, induction/displacement current, Poynting/passivity, ferro/AFM/ferrimagnetic response, frustration and quantum states,2D/moiré/valley materials, altermagnetism/RuO2 controversy,spin torques/skyrmions/magnonics,superconducting Meissner/fluxoid/GL response,magnetoelectric convention,magnetometry/inverse problems and micromagnetic numerics. Each formula has explicit symbols/units/types, conditions, explanatory derivation, worked inputs/steps/results, limiting cases, pitfalls and source context. These are known models applied/explained here, not scientific novelty claims.

## Actual source work

HTTP retrieval used Python standard-library urllib with saved byte captures and SHA256, arXiv primary HTML/abstract pages, official MIT textbook pages, NIST CODATA and JCGM GUM. Crossref discovery hit429limits and produced some irrelevant broad hits; those discovery results were rejected as substantive sources. Feynman/OOMMF endpoints returned403/404 and are not counted among the17retrieved sources. The failed Tong PDF endpoint is also not a source. Search attempts/retries do not count as panel rounds.

Current papers include a2024twisted-CrI3 observation,2024/2025versioned inverse-magnetization work,2025RuO2 functional dependence,2025ultrafast torque/skyrmion/quantum-state/magnetoelectric reports, and November2026RuO2 channel analysis and graphene pairing constraints. Exact arXiv version strings/capture identities are retained; no inferred journal-publication status. Sources with only an inspected abstract stay abstract-only. Manuscript typeset dates can differ from submission/version dates and do not overwrite captured version identities. Copyrighted full text is not copied into the public dataset.

## Executed controls

`magnetism-checks.json` records all17sourcehashes rechecked, complete ID uniqueness, valid topic levels, formula field presence and zero dangling edge endpoints. Independent elementary controls: loop/dipole asymptotic ratio at100radii=0.9998500187478128; exchange length=5.685802302209394nm; correlated two-channel difference uncertainty=0.4472135954999579microtesla.100deterministic random unit-vector LLG states preserve norm derivative to 1.39e-16 and all tested static-energy derivatives are nonpositive (largest=-0.00054181 in normalized illustrative units). These are software/algebra controls, not measured materials or laboratory experiments. No MuMax/OOMMF hardware/device run is claimed.

## Specific objections for adaptive round2

1. Independently audit every B/H and gyromagnetic sign convention. The MuMax selected source prints a plus-prefactor gamma_LL form; this dictionary explicitly chooses positive gamma with a minus sign. Wrong-sign damping must fail a vector-energy test rather than be hidden by notation.
2. Challenge the source sufficiency of the London/GL/Curie/mean-field foundation entries. Their explanatory derivations are standard conditional models, but the selected primary corpus is stronger for micromagnetics, field energy and current papers than for every superconducting/statistical-mechanics derivation. Additional direct foundational text would improve the audit trail.
3. Construct a concrete magnetic inverse null-space witness with a declared forward operator, dimensions and rank. The current Fourier attenuation discussion and NV paper do not prove universal reconstruction uniqueness; even a good fitted field does not identify every vector magnetization.
4. Check whether the selected DMI, spin-current and magnetoelectric conventions match each individual source rather than merely share a symbol. In particular, the bilayer displacement-field/layer response is not silently the bulk SI E,H tensor.
5. Expand selected-text review of abstract-only recent papers before making stronger material/mechanism claims. Do not equate MnTe evidence, RuO2 transport, a DFT bulk-ground-state calculation and a proposed magnon pairing scenario.

Only round1 has been executed/frozen by this specialist. Root selects round2 from actual cross-domain objections; no later round is preclaimed.
