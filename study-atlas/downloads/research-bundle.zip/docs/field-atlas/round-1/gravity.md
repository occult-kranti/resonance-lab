# Gravity specialist — round1

This was one contemporary software-agent research/build task, not participation by historical scientists, human peer review or empirical replication. Applied the historical-physics-panel and resonance-research-advisor skills and measurement/lens references already read in this session, plus paired-physics-research for model/observable and forward/reverse scope. Read the current Field Study Atlas contract. No accepted energy roadmap or unrelated repository was modified.

## Concrete result

Built `public/study-atlas/data/gravity.json` and `public/study-atlas/chapters/gravity.md`:77topics through level5,45formula cards,18source records,10paper reviews,typed edges,glossary and6explicit openquestions. The chapter has7616 whitespace-delimited words, combining source-bounded frontier discussion and guided worked routes. Formula cards define units/types,assumptions,derivation steps,examples,limits and counterchecks. Signature(-,+,+,+),x0=ct and Riemann/Ricci signs are explicit. The Friedmann branch uses energy densityepsilon and normalizeddimensionlessa with curvaturek in m^-2; coordinate-dependent metric units are disclosed.

## Sources and actual depth

Retrieved official CODATAG and GWOSCcatalogue pages, PDG2025gravity-tests PDF, Carrolllecture PDF, primary research abstracts and selected dark-energy supporting-paper PDF passages. Source captures and exact hashes remain private in `docs/field-atlas/sources/gravity/`; public notes are paraphrases, not copyrighted fullpapers. The primaryDESIDR2abstract reports dataset-dependent evidence for evolvingdarkenergy; no independent likelihood reanalysis was run. The related supportingpaper’s introduction andconclusions were read, including the explicit dependence on parameterizations anddata combinations.

Retained and rejected real failures: guessedEHTarXiv2401.12709 is an unrelatedviscoelasticpaper and is never cited as EHT evidence. Correct2025EHTDOI10.1051/0004-6361/202451296 was identified viaCrossref; PDF403 leaves it metadata-only. Two2026gravity-entanglement paperidentities are metadata-only afterIOP200errorpage and guessedAPSroute404. Crossrefquery forGW250114returned429. DESIDR2PDF was capped at8MB and failedpdftotext; its catalogue status was corrected to abstract-only and source identity points to the validabstractHTML. FailedDESIdatareleaseURLguesses404 are retained, not inventedas accessible datasets. No unread2026paper is presented as a resolvedexperimentalresult.

## Executed checks

`python docs/field-atlas/sources/gravity/check-corpus.py` executed:unique IDs,parent-levelincrements,no danglingtopic/formula/source/edgeIDs,all18sourcecapturehashes,nonemptyformula conditions/derivations/examples/limits andvariable unit/type fields. Independently evaluated escape/circularsqrt2,Earthorbital speed,tidaltracezero,equal-masschirpfactor,energy/masscritical-densityconversion,chirprate,strainamplitude,solarHawkingtemperature andPlancklength. Verified Einstein coupling dimensions yield inverse-squarelength. Results and scope are retained in `gravity-checks.json`; these are spotchecks,not proofs of all tensor equations or reproductions of observations. The chirp example was corrected from a loose12.6 estimate to12.49Hz/s after independent calculation12.4873989.

## Accepted narrow result and round2 objections

Accept the source-bounded teaching map and established/approximate model dictionary as a first draft. No novelphysicaldiscovery,universalgravitysignature,gravity-mediatedentanglement experiment,quantumgravitycompletion or exhaustive2026SOTAclaim is made.

The next critic should independently audit metric/curvature/chart-unit conventions,source-versus-detector-frame binary quantities,the domain of weak-field approximations,the normalization/autocorrelation convention inHellings–Downs,and source-depth labels. EHTand2026frontierleads remain unread and should not receive an inferredpaperresult. NonlinearGRderivations andobservationalstatistics are outlined rather than fully reconstructed. Figures/graphlayouts do not create newphysics. Numericalworkedexamples need the same assumedinputs as their symbols; no arithmeticprecision should be interpreted as measurementuncertainty.

Artifact hashes at handoff:

- `public/study-atlas/data/gravity.json`: `fa6b17ec4b887f0568fae62f014fcee4534872b500b4b9706266145830f9e5ea`
- `public/study-atlas/chapters/gravity.md`: `88bdcc4550c3b37aea179b220e4bf7993c435c65ae35e426b8e0001702ae5313`
- `docs/field-atlas/round-1/gravity-checks.json`: `34bdc9b6f28a271a76236246b2fb711ff70b435eefd351ca078a42eae1f9904c`

- `docs/field-atlas/sources/gravity/check-corpus.py`: `05aa8c018c68f48c61cba8838b6673f6f35dbf94d3d77ed85f8831fea086a70a`
