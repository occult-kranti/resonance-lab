# Electrostatics round 3 — integrated artifact acceptance

Reviewed 2026-11-25T07:21:52.076712+00:00 against the actual integrated atlas at http://127.0.0.1:4200/study-atlas/ and the round 3 input freeze. Contemporary software-agent review, not historical participation, human peer review, exhaustive SOTA assessment or laboratory validation. No electrostatics product source, peer code, prior freeze or deployment was changed. This is the third and final requested round.

## Exact registry and document checks

All 42 electrostatics formula IDs occur in the final HTML, Word and extracted PDF text. The HTML contains 42 native MathML objects; DOCX has 42 native Office math objects. The per-domain GraphML contains 149 nodes/315 edges including exactly 42 formula nodes. Its formula metadata retains the complete variables, conditions and worked examples exactly as in the domain JSON, and all edge endpoints resolve. All 14 actual source captures were rehashed; the two inaccessible leads retain null capture/SHA and explicit failure status. The 1991 KPFM record retains abstract-and-metadata-only status; selected 2026 paper readings remain selected sections rather than full methods or replication.

The dataset and chapter match the accepted round 2 byte hashes, so the independently reconstructed force, Neumann compatibility, one-electric-sector fluctuation and series-curvature controls apply to the same source records. No new coefficient or hidden material assumption was introduced by integration. Static receipt: `electrostatics.validation.json`.

The PDF has 77 pages, nominal A4 with actual pagebox 209.888667×297.010667mm; both deviations are below the agreed 0.2 mm rounding allowance. Pages 27 and 43 were rasterized and visually inspected. Fixed-voltage force/G=U−VQ and the longer Bjerrum/Xi/Gouy-length equation are readable and fit the page width; the symbol/type/unit tables are legible. Extracted text also contains the zero-frequency expression and Neumann minus-sign explanation. This is a targeted visual audit, not a claim that every page or assistive-technology path was inspected. Evidence: `electrostatics.page27.png` and `.page43.png`.

## Executed graph/browser and real download gates

The hosted electrostatics formula filter lists 42 records. Selecting es-f13 renders its force and Legendre relations in KaTeX without fallback and exposes G/U/epsilon/area units. Selecting the original KPFM source through the actual source controls preserves its partial-reading status and explicitly unread original methods. These are actual UI actions, not conclusions inferred solely from a build result.

Direct file:// navigation was blocked by managed Chromium with ERR_BLOCKED_BY_ADMINISTRATOR. That environment restriction is retained rather than called a successful file-open. The exact standalone HTML bytes were instead executed with setContent while HTTP(S) requests were blocked. Selecting electrostatics/es-f36 rendered its equation and single-classical-electric-sector scope with zero HTTP requests and no page errors. This supports self-contained execution of the bundled graph; direct file navigation itself was not verified in this environment.

Actual served downloads matched local final bytes:

- `http://127.0.0.1:4200/study-atlas/downloads/electrostatics.pdf`: 1829365 bytes, SHA-256 `c039367e39089ba767a071aee2c77da1804df5e29f77ecd3426aaf62533ea892`.
- `http://127.0.0.1:4200/study-atlas/downloads/electrostatics.docx`: 73697 bytes, SHA-256 `e275c0c63e21f4e3226d043c81c5d27c405d9e699fdab7608f7767a64b6730cc`.
- `http://127.0.0.1:4200/study-atlas/downloads/electrostatics.html`: 229465 bytes, SHA-256 `667c84a0fbb491fe6f05eb763752cc90ecc5befcd1558798333d2a9fdb8eca21`.

Browser receipt: `electrostatics.browser.json`. Early test-harness attempts incorrectly assumed hash-only navigation reinitialized the app, and direct file navigation hit the environment policy; they were corrected to use the UI's actual source-selection controls and the disclosed network-blocked standalone execution. These checks are not extra research rounds.

## Scientific acceptance and limits

Fixed-V force uses the source-inclusive potential G=U−VQ; fixed-Q force differentiates isolated field energy. The source-port work identity remains explicit. Neumann g=epsilon*partial_n(phi) remains minus outward D flux, with charge/flux compatibility and a gauge reference separate. Landau/series negative-capacitance curvature is local whole-system stability, not a blanket device or global-domain claim. The fluctuation formula retains only one static electric/TM zero-frequency sector:−zeta(3)kBT/(16pi*a²) for ideal electric reflectors, not an unqualified complete Casimir force. No scalar measured frequency is assigned causally to a person, image or arbitrary structure.

Round2 exact/numerical controls remain bound to these unchanged records: the 8-cell Neumann matrix has rank 7 and its incompatible augmented system rank 8; static zero-mode quadrature differed from the analytic coefficient by -1.6e-08 relative; fixed-V field-energy-only differentiation gave the deliberately wrong force sign; positive/negative total series-curvature cases discriminate local stability. Independent peer magnetic-sector checks agreed with the plate source-work and one-sector coefficient. These are conditional calculations, not material calibration, force measurements or proof of every cited theorem.

One nonblocking metadata limitation was reported to root: aggregate GraphML uses kind=source for its node category, overwriting the original source-kind field in that aggregate record. Original textbook/primary-paper/metadata kind remains in the domain JSON; status, version, author, reading depth and capture metadata remain available. No stronger reading claim is inferred from the graph category.

Accept the bounded teaching corpus and its documented downloads/graph within these limits. No critical missing symbol, force sign, prefactor, evidence-status promotion or mathematical contradiction was found in the inspected paths. Do not describe this selected corpus as all electrostatics, all current papers or an experimentally validated apparatus. No fourth round or new feature is proposed.

## Final artifact hashes

- `public/study-atlas/data/electrostatics.json`: `56ee3d5f9915574cc2cb73a70de5b235cef7431db54df870a4fe0a3d73c436c6`
- `public/study-atlas/downloads/electrostatics.pdf`: `c039367e39089ba767a071aee2c77da1804df5e29f77ecd3426aaf62533ea892`
- `public/study-atlas/downloads/electrostatics.docx`: `e275c0c63e21f4e3226d043c81c5d27c405d9e699fdab7608f7767a64b6730cc`
- `public/study-atlas/downloads/electrostatics.html`: `667c84a0fbb491fe6f05eb763752cc90ecc5befcd1558798333d2a9fdb8eca21`
- `public/study-atlas/graphs/electrostatics.graphml`: `5c96b2c73b9418b5741c5a248b00871fe43d60ecc6f57581459659035f965d5c`
