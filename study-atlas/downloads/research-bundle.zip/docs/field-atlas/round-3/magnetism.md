# Magnetism specialist — final round3 acceptance

Accepted the actual revised atlas at `http://127.0.0.1:4200/study-atlas/` and its magnetism/complete-book outputs within the selected educational/research scope. No blocking magnetic formula, source-status, export or graph defect remained. This is the third and final requested round; no corpus/source expansion or nonblocking polish was performed, and no publication was initiated.

## Exact reviewed identity

Input freeze: `docs/field-atlas/round-3/input.json`, prepared07:11:25UTC. Integrated atlas SHA256`c80998253df75e164a6b6a3b9f436bbbfb4fc382b487bda2b4d16469f41b7b65`.

- Magnetism domain SHA256: `b434b67c8b611677636552f40662969331587901d297ca9c93ecb58b3668fae3`.
- Magnetism chapter SHA256: `70a011891ea65fdf70fc09c37cdff02eddda7339b00f1e25b67ed003c8650d72`. Both match R2freeze.
-87page magnetism PDF SHA256: `4123d865fc7857269dab6ec77c4698faf9c0ee706817ab55206c43f1b7ab2d2c`.
- Word SHA256: `9812c7c00b239bdb3ab82a8199f4cad0a242c7ffe9403ab2627dfbb8dc7cfd9c`.
- HTML SHA256: `26bb3be8400de562f00b1942276aeb2cfd8da09dd51a70e6a57d4390acfe8f63`.
- Field GraphML SHA256: `6d4297ee3874ba5155aafc7c706b6bf9add51f6093e055483a38f9cf33b9a4c6`.

Six actual served files were compared byte-for-byte by SHA256 against the reviewed local outputs, including corpus,PDF,DOCX,HTML,GraphML and standalone network HTML. This checks served artifacts, not just a generator’s success field.

## Documents and scientific conventions

The magnetism HTML contains43MathML expressions without a KaTeXerror. Word contains43OMML math objects and all43formula IDs. Selected underlying OMML retains the LLGminus sign/gamma/alpha,magnetoelectric mu0 factor,and inverse-kernel expression. All20source hashes and the explicit GLfoundation limitation occur in Word. All43formula IDs occur in the87page PDF. The complete-study PDF has491pages and includes all43magnetism IDs; complete Word includes them and has237math objects across the full atlas. This does not mean every page was independently visually reviewed.

Actual PDF pages13,46–47,49–50,59–61and65were selected for narrative/dictionary and formula inspection. The rendered LLGexplicitly uses positive gamma with a minus sign and documents the source-convention warning. DMIretains J/m²and the in-plane-gradient/chirality conditions. The magnetoelectric expression uses alpha in s/m and mu0M=alphaE,with volumetric-versus-layer normalization caveats. The GLsource gap remains visible rather than being hidden behind the graphene citation. The inverse page gives the matrix,kernel,units,conditions and numerical example. Numeric tables/math remain readable on inspected pages; some entries continue across pages, with their dictionaries retained.

All87pages are nominalA4within0.2mm of210×297mm; the first is209.888653×297.010661mm. This is ordinary Chrome print rounding, not a patent-sheet measurement/certification claim. Text/math rendering and complete symbol dictionaries are accepted; no paper/legal/physical certification follows.

## Live graph and source records

Real Chromium selected all43magnetism formula records through the text-list alternative. Every formula typeset successfully and displayed exactly its declared number of symbol/unit/type entries. The inverse rank/nullity qualifications and direct originalGL/Hc2source gap were visibly present. Selected20source capture hashes match their actual private files. The current RuO22026record visibly says selected-text with the newly inspectedPDFscope; the newest graphenepreprint remains abstract-only. London’s selected slide reading limit is visible. The browser records zero page errors or failed local resources.

At390px the page has no horizontal document overflow. The long magnetoelectric expression uses its own horizontal scrolling region(client312px,content334px;scrollLeft advances22px),while the complete symbol dictionary remains visible. This is equation panning, not a cropped/missing term. Desktop/mobile receipts accompany the report.

The exported magnetism GraphML contains169nodes and359edges. All20source nodes preserve full reading-depth/status/hash metadata; all43formula nodes preserve exact equations,variables and conditions. Every edge preserves named type,label and evidence-source metadata. All24cross-domain links are explicitly marked editorial/didactic with scope; their endpoints exist and are not asserted as new physical forces or measurements.

## Independent scientific replay and remaining limits

The actual corpus inverse entry was replayed from the vacuum dipole kernel:1×2rank1/nullity1with(1,−1)kernel;three symmetric heights remain rank1;the off-axis2×2determinant remains1.868873768931e-16[T/(A m²)]². The specified zero-coupling exception evaluates to-8.06e-24T/(A m²),consistent with floating zero. This is a restricted known-position/orientation model, not a continuum magnetization uniqueness theorem. The R1/R2passivity,SI,DMI and source-port controls remain the accepted executed records; no hardware,DFT,MuMaxor experimental replication is invented by this final rendering check.

Remaining scientific boundaries are substantive: a direct originalGL/Hc2source was not inspected; several currentpapers are abstract-only;material/interface and measurement-channel alternatives remain;finite model inverse uniqueness does not identify arbitrary sources. The documents and graph preserve these distinctions. No universal frequency,occult-force,source-free-energy or clinical conclusion is admitted.

Receipts:`magnetism-artifact-checks.json`,`magnetism-browser-checks.json`,`magnetism-docx-checks.json`,`magnetism-complete-book-checks.json`,`magnetism-mobile-math.json`,`magnetism-controls.json`and inspected page/browserPNGs in this round directory. R1andR2reports remain unchanged. Three actual rounds are complete for this specialist; stopping here.
