# Field Study Atlas — research and delivery contract

Cutoff: 2026-11-25, confirmed against the clock. Six contemporary software-agent specialists; three adaptive rounds. Shared model lineage, no historical participation, human peer review or laboratory validation. Root moderates and produces the integrated documents, graphs, validation and downloads. All nine repositories remain available for context, with preexisting patches, accepted studies and published deployments preserved. No remote publication is required for this new research deliverable.

## Finite deliverable

Six substantial chapters: electrostatics, magnetism, gravity, frequency, mathematics and AI-assisted mathematics. The four physics fields receive nested maps through research specialties, formula dictionaries, derivations and examples, modern primary-source reviews and open questions. Mathematics includes independently browsable algebra, geometry and calculus/analysis branches. The AI chapter audits concrete Claude/Anthropic and OpenAI problem-solving claims through exact statements, provenance, contributor roles and verification. A searchable interactive network, standalone graph exports, complete book and per-domain documents, machine-readable corpus and source-linked coverage register accompany the narrative.

This is a dated, selected and expandable corpus. “Mapped”, “reviewed” and “unread lead” are distinct. A complete package of the selected corpus is not an exhaustive survey of every paper or all mathematics. State exactly which paper sections were read. Do not fill graph nodes with invented papers or treat inaccessible metadata as a read result.

## Ownership and rounds

Agent domain ownership: architecture→electrostatics; devices→magnetism; research→gravity; audio→frequency; discourse→mathematics; curator_ui→AI-assisted mathematics. Do not spawn more agents while all six specialists occupy the seven available slots. Files owned per domain: `public/study-atlas/data/<id>.json`, `chapters/<id>.md`, private `docs/field-atlas/sources/<id>/`, and that domain’s report in each round. Root owns shared schema, generator, graph app, combined files and validation.

Round 1 independently retrieves sources, maps coverage and builds derivations. After all six reports freeze, root selects cross-domain criticisms for round 2. Round 2 corrects those identified deficiencies and executes independent counterexamples. Round 3 evaluates the changed integrated documents and graph, citation/paper states, notation/units and calculations. Reports contain actual artifact hashes, commands/reading records, supported results, objections and decisions; searches/builds/retries do not count as extra research rounds.

## Exact JSON shape

All files use UTF-8 JSON. Domain IDs: `electrostatics`, `magnetism`, `gravity`, `frequency`, `mathematics`, `ai-mathematics`. Prefix every local ID with respectively `es-`, `mag-`, `grav-`, `freq-`, `math-`, `ai-`. Cross-domain prerequisites may be added by root after comparison. Required root keys:

```json
{
  "schema": "field-study-domain/v1",
  "id": "electrostatics",
  "title": "Electrostatics",
  "cutoff": "2026-11-25",
  "summary": "Readable domain summary.",
  "scope": "Exact included branches and unreviewed boundaries.",
  "topics": [],
  "formulas": [],
  "sources": [],
  "papers": [],
  "edges": [],
  "glossary": [],
  "openQuestions": []
}
```

Topic: `{id,title,parentId,level,summary,coverage,sourceIds,prerequisites,formulaIds}`. A root has `parentId:null,level:0`. Each child level is parent level+1. At least five levels (0–4) in meaningful branches; do not manufacture depth by renaming the same subject. Coverage values: `reviewed`, `mapped`, `lead`. Prerequisites are topic IDs. Formula IDs reference actual records.

Formula/theorem: `{id,topicId,title,latex,plain,variables,conditions,derivation,workedExample,limitingCases,pitfalls,sourceIds,status}`. Variables: `[{symbol,meaning,unit,kind}]`, where kind names scalar/vector/tensor/operator/coordinate/state/coupling/constant or the appropriate mathematical object. Unit is SI, `dimensionless`, or an explicit nondimensional mathematical convention. Conditions, derivation, limitingCases and pitfalls are nonempty string arrays. Worked example is `{inputs,steps,result,units}`: inputs may be a string or object, steps is a string array, result is a readable string or numeric value, units are explicit. An analytic counterexample or finite algebra example is appropriate for an abstract theorem. Status: `established-model`, `theorem`, `conditional-result`, `approximation`, `conjecture`, `research-proposal`. Do not give a conjecture a proof.

Source: `{id,title,url,authors,year,version,kind,status,readDepth,sectionsRead,claim,limitations,passageKind,note,capture,sha256,retrievedAt}`. Authors may be string or string array. Year may be number or null where unavailable. DOI optional. Kind distinguishes textbook/primary-paper/preprint/official-data/official-announcement/problem-record/independent-review/metadata. Status distinguishes full/selected text, abstract or metadata only, inaccessible lead. SectionsRead is a string array. Claim and limitations are readable strings. PassageKind is `verbatim-excerpt` only for an actually verified quote; otherwise `research-note`. Note is bounded attributed excerpt or paraphrase. Capture is a workspace-relative path to actual private capture; SHA-256 is its exact bytes, or null with reason for an inaccessible lead. Never fabricate retrieval metadata. Public records can refer to private captures without redistributing copyrighted full text.

Paper review: `{id,sourceId,topicIds,question,method,result,whatIsNew,limitations,status,equationsUsed,replication,nextQuestions}`. TopicIds and equationsUsed are ID arrays. NextQuestions string array; other fields readable strings. An abstract-only paper’s record must say abstract-only in status and limit its claims accordingly. “What is new” describes the source authors’ contribution and inspected evidence, not a novelty certification.

Edge: `{source,target,type,label,evidenceSourceIds}`. Endpoints reference actual IDs (topics, formulas, sources, papers, open questions or claims). Allowed types: `contains`, `requires`, `derives-from`, `applies-to`, `limits-to`, `measures`, `supported-by`, `reviews`, `compares`, `disputes`, `unresolved`. Direction: a child may require a prerequisite (child→prerequisite); containment parent→child; formulas derive from prior formulas/theorems; a record is supported-by a source. Typed edges are intellectual/documentary relationships, not automatically causal forces. Use an explicit label and evidential scope.

Glossary: `[{term,definition}]`. Explain every introduced technical acronym and overloaded convention. Open question: `{id,question,status,neededEvidence,sourceIds}`. AI domain additionally supplies claims `[{id,provider,model,problemStatement,claimedDate,priorStatus,AIContribution,verificationStatus,independentEvidence,sourceIds,limitations}]`; string fields except sourceIds. Distinguish a competition solution, benchmark score, new proof, rediscovery, author-checked preprint, independent assessment and machine proof under a declared trusted kernel.

## Scientific gates

All formulas identify domain, sign conventions, boundary/initial conditions, mathematical hypotheses, units and limit of applicability. Worked examples are illustrative calculations with explicit assumptions, not physical data. Preserve source-specific notation and disclose conflicts. Require dimensional consistency and meaningful null/limit/counterexample checks for representative mechanisms; root executes selected independent symbolic/numerical controls. Distinguish a carrier, modulation, natural mode and measured transfer peak. Ordinary electromagnetic, gravitational and quantum formulas do not establish universal frequency healing or an occult force. Keep the channels distinct.

Source discovery will use real HTTP retrieval, official records and scholarly APIs available in this environment. Document errors, versions and actual reading depth. Raw captures stay private; public notes, citations, hashes and links provide provenance. Preserve current SOTA uncertainty, disputed materials, preprint status and independent replication gaps. Dates beyond the verified cutoff are excluded or marked inconsistent. Do not use institutional custody, patents, company announcements or a graph edge as proof of a physical or mathematical result.

## Completion gates

All six substantive chapters and datasets; five-level topic maps; variables and hypotheses explained for every included formula; explicit source reading depths; traceable modern paper reviews; exact AI-claim audit with independent-evidence status; no dangling graph/citation IDs; visible coverage gaps; selected executed scientific counterchecks; three actual six-agent review freezes; working searchable accessible graphs with text alternative; inspected complete book/per-domain documents and standalone downloads. No invented “percent of physics/mathematics solved”.
