"""Independent representative controls, not a proof audit of every cited research paper."""
from pathlib import Path
import json,hashlib,math
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp,simpson
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def record(name,passed,evidence,scope):
 checks.append({'name':name,'passed':bool(passed),'evidence':evidence,'scope':scope})
 if not passed:raise AssertionError(name)
x,y,z,r,G,M,c,epsilon,rho,B,q=sp.symbols('x y z r G M c epsilon rho B q',positive=True,real=True)
variables=(x,y,z);phi=-(rho/(6*epsilon))*(x*x+y*y+z*z)
E=sp.Matrix([-sp.diff(phi,v) for v in variables]);divE=sum(sp.diff(E[i],variables[i]) for i in range(3))
record('Poisson/Gauss sign and source',sp.simplify(divE-rho/epsilon)==0,{'potential':str(phi),'divergence':str(divE)},'Uniform-source analytic example in an unbounded coordinate patch; boundary data must be specified for a physical region.')
curlE=sp.Matrix([sp.diff(E[2],y)-sp.diff(E[1],z),sp.diff(E[0],z)-sp.diff(E[2],x),sp.diff(E[1],x)-sp.diff(E[0],y)])
record('Electrostatic curl null',curlE==sp.zeros(3,1),{'curl':str(curlE)},'Differentiable scalar potential; not arbitrary time-dependent electromagnetic fields.')
Q,V,C0,a=sp.symbols('Q V C0 a',positive=True,real=True);cap=C0/(1-a*x)
fixedQ=-sp.diff(Q**2/(2*cap),x);fixedV=sp.diff(cap,x)*V**2/2
record('Fixed-voltage source work changes the mechanical potential',sp.simplify(fixedQ.subs(Q,cap*V)-fixedV)==0,{'fixedQForce':str(fixedQ),'fixedVForce':str(fixedV),'wrongFieldEnergyGradientHasOppositeSign':str(-sp.diff(cap*V**2/2,x))},'Ideal quasistatic capacitor coordinate; fixed charge and fixed voltage are different controlled systems.')
A=sp.Matrix([-B*y/2,B*x/2,0]);curlA=sp.Matrix([sp.diff(A[2],y)-sp.diff(A[1],z),sp.diff(A[0],z)-sp.diff(A[2],x),sp.diff(A[1],x)-sp.diff(A[0],y)])
record('Vector-potential curl and magnetic divergence',curlA==sp.Matrix([0,0,B]) and sum(sp.diff(curlA[i],variables[i]) for i in range(3))==0,{'A':str(A),'curlA':str(curlA)},'Uniform static B in a simply connected coordinate example; gauge representation is not unique.')
vx,vy,vz,bx,by,bz=sp.symbols('vx vy vz bx by bz',real=True);velocity=sp.Matrix([vx,vy,vz]);field=sp.Matrix([bx,by,bz]);power=sp.expand(velocity.dot(q*velocity.cross(field)))
record('Magnetic Lorentz force does no instantaneous work',power==0,{'vDotForce':str(power)},'Magnetic q v×B term only; an induced electric field can do work.')
potential=-G*M/sp.sqrt(x*x+y*y+z*z);laplace=sp.simplify(sum(sp.diff(potential,v,2) for v in variables))
record('Newtonian exterior vacuum Laplacian',laplace==0,{'laplacian':str(laplace),'pointSourceExcluded':'r=0'},'Identity outside the point source; the distributional delta source must not be discarded at the origin.')
u=sp.symbols('u',positive=True);ratio=sp.sqrt(1-2*u)
record('Weak-field redshift expansion',sp.series(ratio,u,0,3).removeO()==1-u-u*u/2,{'expansion':str(sp.series(ratio,u,0,3)),'u':'GM/(r c^2)'},'Static Schwarzschild clock relative to infinity, weak field; coordinate time and proper time are distinct.')
zc=sp.symbols('zeta',positive=True);free=sp.sqrt(1-zc**2);forced=sp.sqrt(1-2*zc**2)
record('Damped pole differs from forced displacement peak',float(free.subs(zc,.5))!=float(forced.subs(zc,.5)),{'dampedFreeOmegaOverOmega0':float(free.subs(zc,.5)),'forcedPeakOverOmega0':float(forced.subs(zc,.5)),'forcedPeakInteriorDomain':'0<zeta<1/sqrt(2)'},'Viscous single-degree-of-freedom displacement response; response channel and loading matter.')
sampleRate=4096;count=4096;n=np.arange(count);f=300
wave=np.cos(2*np.pi*f*n/sampleRate);alias=np.cos(2*np.pi*(f+sampleRate)*n/sampleRate);difference=float(np.max(np.abs(wave-alias)))
record('Finite sampling admits indistinguishable aliases',difference<2e-11,{'maxSampleDifference':difference,'frequencyHz':f,'aliasHz':f+sampleRate,'sampleRateHz':sampleRate},'Uniform ideal samples; anti-alias filtering and input-band assumptions are extra premises.')
spectrum=np.fft.fft(wave);timeEnergy=float(np.sum(wave**2));frequencyEnergy=float(np.sum(np.abs(spectrum)**2)/count)
record('DFT Parseval normalization',abs(timeEnergy-frequencyEnergy)<1e-9,{'sampleEnergy':timeEnergy,'FFTenergyDividedByN':frequencyEnergy,'N':count},'NumPy forward DFT has no 1/N factor, inverse has 1/N; other conventions move the normalization.')
omegaCut=2.0;waveSpeed=3.0;k=.8;omega=math.sqrt(omegaCut**2+waveSpeed**2*k*k);phase=omega/k;group=waveSpeed**2*k/omega
record('Dispersive phase and group speeds differ',phase>waveSpeed and group<waveSpeed and abs(phase*group-waveSpeed**2)<1e-12,{'phaseSpeed':phase,'groupSpeed':group,'asymptoticWaveSpeed':waveSpeed},'Ideal waveguide-like dispersion omega²=omegaCut²+c²k²; a phase speed is not a signal-front speed.')
matrix=np.array([[1.,1.]]);singular=np.linalg.svd(matrix,compute_uv=False);kernel=np.array([1.,-1.]);rank=int(np.linalg.matrix_rank(matrix))
record('Positive returned singular values do not imply an injective rectangular map',rank==1 and np.linalg.norm(matrix@kernel)==0,{'matrix':matrix.tolist(),'returnedSingularValues':singular.tolist(),'domainDimension':2,'rank':rank,'nullity':2-rank,'kernelWitness':kernel.tolist()},'The SVD return array has min(m,n) values; inverse identifiability needs the full domain dimension.')
record('Uniform convergence does not justify differentiating the limit',1/1000<.002 and math.cos(1000*0)==1,{'sequence':'sin(n*x)/n converges uniformly to0','derivativeAtZero':'cos(n*0)=1 for every n','derivativeOfLimit':0},'A counterexample to interchanging a limit and derivative without additional hypotheses.')
lam1,lam2=1.,-2.;sampleMatrices=[np.diag([lam1,lam2]),np.array([[1.,3.],[0.,-2.]])]
record('An invariant spectrum does not preserve all coordinate norms',np.allclose(np.sort(np.linalg.eigvals(sampleMatrices[0])),np.sort(np.linalg.eigvals(sampleMatrices[1]))) and not np.isclose(np.linalg.norm(sampleMatrices[0],2),np.linalg.norm(sampleMatrices[1],2)),{'operatorNorms':[float(np.linalg.norm(v,2)) for v in sampleMatrices]},'Similarity preserves eigenvalues, while Euclidean operator norm requires an appropriate unitary/isometric change of representation.')
# Independent trajectory integration plus separate quadrature of source work and loss.
L=.01;C=.0001;R=20.;amplitude=.15;driveHz=159.15;duration=.03
def rhs(t,state):charge,current=state;return[current,(amplitude*math.sin(2*math.pi*driveHz*t)-R*current-charge/C)/L]
solution=solve_ivp(rhs,[0,duration],[0,0],rtol=2e-11,atol=2e-13,dense_output=True)
energies=[]
for panels in [4000,8000]:
 t=np.linspace(0,duration,panels+1);charge,current=solution.sol(t);source=amplitude*np.sin(2*np.pi*driveHz*t)
 work=float(simpson(source*current,x=t));loss=float(simpson(R*current**2,x=t));stored=float(.5*L*current[-1]**2+.5*charge[-1]**2/C);energies.append({'panels':panels,'sourceWorkJ':work,'lossJ':loss,'storedChangeJ':stored,'residualJ':work-loss-stored})
record('Passive source/load/storage budget with independent refined quadrature',solution.success and all(abs(v['residualJ'])<1e-12 for v in energies),{'quadrature':energies,'solver':'SciPy solve_ivp trajectory; independent Simpson work/loss quadrature'},'Ideal driven RLC from zero state; numerical integration checks this declared model, not a built resonator or source-free energy claim.')
units={'charge':(0,0,1,1),'force':(1,1,-2,0),'epsilon':(-1,-3,4,2),'mu':(1,1,-2,-2),'B':(1,0,-2,-1),'G':(-1,3,-2,0),'energy':(1,2,-2,0),'h':(1,2,-1,0)}
add=lambda *vectors:tuple(sum(v[j] for v in vectors) for j in range(4));mul=lambda v,a:tuple(a*x for x in v)
derived={'CoulombForce':add(mul(units['charge'],2),mul(units['epsilon'],-1),(0,-2,0,0)),'LorentzForce':add(units['charge'],(0,1,-1,0),units['B']),'NewtonForce':add(units['G'],(2,-2,0,0)),'PhotonEnergy':add(units['h'],(0,0,-1,0))}
record('Representative SI dimension audit',all(derived[k]==units['energy' if k=='PhotonEnergy' else 'force'] for k in derived),{'baseOrder':['kg','m','s','A'],'derivedVectors':derived},'Dimensions are necessary consistency checks, not sufficient evidence that a physical law or source claim is correct.')
report={'schema':'field-study-scientific-controls/v1','scope':'Representative independent symbolic/numerical counterchecks. Not a complete proof audit of the selected formula corpus or the cited frontier papers.','sourceSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'passed':all(c['passed'] for c in checks),'count':len(checks),'versions':{'numpy':np.__version__,'sympy':sp.__version__}}
(ROOT/'docs/field-atlas/validation').mkdir(parents=True,exist_ok=True)
(ROOT/'docs/field-atlas/validation/scientific-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'controls':len(checks)}))
