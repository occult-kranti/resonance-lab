"""Build a readable orientation guide and flat inspectable research registers."""
from pathlib import Path
import json,csv,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'public/study-atlas';atlas=json.loads((OUT/'data/atlas.json').read_text());c=atlas['counts']
text=f'''# Study guide: Fields, Frequency and Mathematics

Research cutoff: 25 November 2026.

The selected atlas contains **{c['topic']} topic records, {c['formula']} formula/theorem records, {c['source']} source records, {c['paper']} paper reviews and {c['claim']} AI-assisted mathematics claim records**. The six narrative chapters contain about45,000words before formula, source and evidence appendices. Every count describes this finite package, not the fraction of a scientific field or theorem solved.

## What the four physics areas describe

- **Electrostatics:** stationary-charge fields, material response and boundary-value inference. Begin with charge, force, potential and units; move through Gauss/Poisson, conductors, dielectric interfaces and capacitance to screening, quantum capacitance, fluctuation forces and inverse measurements.
- **Magnetism:** magnetic fields and the collective behaviour of matter. Start with vector products, currents, B versus H and flux; continue through Maxwell energy/induction, dipoles and magnetic materials to spin dynamics, low-dimensional systems, altermagnetism, skyrmions, superconductivity and inverse magnetometry.
- **Gravity:** mass-energy, motion and spacetime geometry. Start with Newtonian potential, orbits and tidal fields, then learn metrics, proper time, connections and curvature before Einstein equations, gravitational waves, cosmology, precision tests and qualified quantum-gravity proposals.
- **Frequency:** a quantity and a family of mathematical methods used across physical theories. Separate frequency from angular frequency, phase, damping, carrier, modulation and a response peak. Proceed through oscillators, Fourier/Laplace analysis, sampling and uncertainty to dispersion, inverse spectra and optical/nuclear time metrology.

These areas connect through mathematical structures. Sharing a differential equation or a spectral representation does not establish identical physical sources, coupling constants or a new force. The graph labels such connections as learning prerequisites, comparisons or model relationships.

## Mathematics learning ladder

1. **Algebra:** arithmetic and units; equations and functions; vectors, matrices and rank; abstract groups, rings and fields; representations, tensor products, homological and category methods.
2. **Geometry:** Euclidean constructions and trigonometry; topology and manifolds; metric, connection, curvature and geodesics; symplectic and algebraic geometry; carefully scoped frontier theorems.
3. **Calculus and analysis:** limits and continuity; derivatives and integrals with hypotheses; multivariable calculus and Stokes; measure, convergence and functional analysis; ODE/PDE, spectral, variational and numerical methods.
4. **Proof literacy:** specify a theorem's domain and quantifiers, check each premise, distinguish an example from a proof, and inspect what a formal certificate assumes and which trusted components have actually executed.

The mathematics chapter has61 formula/theorem records. Six have a directly checked source statement or explicitly checked corollary pairing;55 remain clearly labeled teaching reconstructions without an independently checked exact theorem-to-source passage. Those source-audit labels remain in the documents and interactive details. This distinction does not turn a standard theorem into a new result.

## How to read one equation

Read the **plain-language meaning** first. Then inspect every symbol's type and unit, the domain and hypotheses, the derivation/proof guide, a worked example, limiting cases and the listed failure modes. Follow its source records and actual reading depth. A correct dimensional check is necessary but does not prove an equation physically applies. A numerical example is not an experiment or a complete proof of a frontier claim.

Watch for fixed-charge versus fixed-voltage conditions, gauge constants and boundary compatibility; free versus bound currents and B/H conventions; mass versus energy density and coordinate conventions; ordinary versus angular frequency and spectrum normalization. Reusing a letter between records does not make it the same quantity.

## Selected frontier lessons from the review rounds

- **Electrostatics:** fixed-voltage mechanical force requires source work; negative differential capacitance needs a stable combined system and domain qualification. A named electrostatic Casimir sector carries its own zero-mode factor, rather than an automatic sum over all electromagnetic sectors.
- **Magnetism:** a magnetic inverse map can retain an explicit kernel even after several measurements. Material, geometry, sample and temperature conditions matter when comparing altermagnetic claims and null observations. Magnetic field energy and omitted loading cannot be replaced by resonance rhetoric.
- **Gravity:** the selected DESI result depends on combined datasets and supernova choices; BAO-alone consistency and a joint evolving-dark-energy preference are distinct findings. Current gravitational-wave tests have named data/model limits; a spectral constraint alone does not establish a mode's physical presence.
- **Frequency:** an interrogation-window width is not automatically a lifetime linewidth; within-run clock stability is distinct from between-day reproducibility. Frequencies inferred through an instrument require its transfer function, sampling/window conventions and uncertainty model.
- **Mathematics:** a three-dimensional Kakeya dimension result has a different target from the maximal-function conjecture. A selected geometric-Langlands paper is one part of a multi-paper construction. Moving-sofa optimality has a precise admissible class, and kinetic/fluid limits retain solution, scaling and time hypotheses.

These are supported only at the source versions and reading depths recorded in the atlas. The individual research cards explain the methods, source-reported result and unresolved verification; the package is not a claim of exhaustive current literature coverage.

## Claude, OpenAI and mathematics claims

The twenty case records distinguish competition answers, benchmark grading, research manuscripts, independent review, formal artifacts and withdrawals. For the reviewed First Proof batch, “accepted at a published threshold” and “strict correctness” use different counts: the record gives3 versus2 for the named Claude model and7 versus5 for the named OpenAI model. Exact model names, grading definitions and source versions are in the original case records. A fraction of benchmark problems is not a percentage of mathematics solved.

The official manuscript catalogue contains730 indexed PDF records, all marked **unread-indexed**. Its header declares375 families; the parser observed373 numbered family sections and preserves that difference as a parsing observation, without asserting that the repository is wrong. Multiple manuscript versions do not establish multiple solved problems. Three named withdrawals and recent ambitious LP/matrix-multiplication claims keep their correction or pending-review status. Retrieved Lean text is an artifact; this atlas does not claim the external Lean certificate was executed.

## Use the graphs and registers

Open `network-atlas.html` for the self-contained interactive graph. Choose one field, record type and topic depth; select an item to read its complete meaning, source scope and named relations. A text record list provides an alternative to the visual layout. The global graph and each domain are also exported as GraphML; nine standalone SVG maps include the three mathematics branches. Graph position is illustrative.

The flat CSV registers expose all formulas, papers, topics, glossary entries and sources without hiding fields in a picture. The complete JSON corpus preserves full structured records. The full book and six domain studies are available as PDF, Word, HTML and Markdown. Original copyright-protected source captures remain private; this bundle supplies citations, bounded notes, inspected sections and exact capture hashes.

## Reproducibility and limits

Six model-agent specialists completed successive production and skeptical review rounds. Representative independent symbolic/numerical checks cover electrostatic signs and work, magnetic power, Newtonian limits/redshift, spectral conventions and aliasing, inverse-map kernels, convergence counterexamples and a passive source/storage/loss budget. Such checks audit stated models and selected statements, not every proof in every referenced paper. No new laboratory or clinical observations are produced by this project.
'''
text=text.replace('about45,000words','about 45,000 words').replace('has61','has 61').replace('pairing;55','pairing; 55').replace('gives3 versus2','gives 3 versus 2').replace('and7 versus5','and 7 versus 5').replace('contains730','contains 730').replace('declares375','declares 375').replace('observed373','observed 373')
md=OUT/'downloads/summary.md';md.write_text(text)
for fmt in ['html','docx']:
 command=['pandoc',str(md),'--standalone','--toc','--metadata','title=Study guide: Fields, Frequency and Mathematics','--output='+str(OUT/'downloads'/('summary.'+fmt))]
 if fmt=='html':command+=['--to=html5','--css=../book.css']
 else:command+=['--reference-doc='+str(ROOT/'docs/field-atlas/validation/reference.docx')]
 subprocess.run(command,check=True,capture_output=True,text=True)
def flat(name,fields,rows):
 with (OUT/'downloads'/name).open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
  for row in rows:writer.writerow({key:(json.dumps(row.get(key),ensure_ascii=False) if isinstance(row.get(key),(list,dict)) else row.get(key,'')) for key in fields})
formulas=[];papers=[];topics=[];sources=[];glossary=[]
for d in atlas['domains']:
 for target,key in [(formulas,'formulas'),(papers,'papers'),(topics,'topics'),(sources,'sources'),(glossary,'glossary')]:target.extend({'domain':d['id'],**record} for record in d[key])
flat('formula-register.csv',['domain','id','title','latex','plain','status','variables','conditions','derivation','workedExample','limitingCases','pitfalls','sourceIds','sourceAudit'],formulas)
flat('paper-register.csv',['domain','id','sourceId','topicIds','question','method','result','whatIsNew','status','limitations','replication','nextQuestions'],papers)
flat('topic-register.csv',['domain','id','title','parentId','level','coverage','summary','prerequisites','formulaIds','sourceIds'],topics)
flat('source-register.csv',['domain','id','title','url','authors','year','version','kind','status','readDepth','sectionsRead','claim','limitations','passageKind','note','sha256','retrievedAt'],sources)
flat('glossary.csv',['domain','term','definition'],glossary)
print(json.dumps({'summaryWords':len(text.split()),'formulaRows':len(formulas),'sourceRows':len(sources)}))
