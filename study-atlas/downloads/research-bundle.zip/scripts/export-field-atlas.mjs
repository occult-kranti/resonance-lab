/** Render prepared HTML/MathML documents as tagged PDFs and package the selected corpus. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from 'playwright';
const root=path.dirname(path.dirname(new URL(import.meta.url).pathname)),out=path.join(root,'public/study-atlas');
const base=process.env.ATLAS_BASE_URL||'http://127.0.0.1:4200/study-atlas/';
const names=['electrostatics','magnetism','gravity','frequency','mathematics','ai-mathematics','complete-study','summary'];
const browser=await chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const receipts=[];
try{
 for(const name of names){
  const page=await browser.newPage({viewport:{width:794,height:1123}});
  await page.goto(base+'downloads/'+name+'.html',{waitUntil:'networkidle',timeout:120000});
  await page.emulateMedia({media:'print'});await page.evaluate(()=>document.fonts.ready);
  const layout=await page.evaluate(()=>{
   const width=(210-20-18)*96/25.4;document.body.style.width=width+'px';
   const changed=[];
   for(const span of document.querySelectorAll('.math.display, math[display="block"]')){
    let size=parseFloat(getComputedStyle(span).fontSize),attempt=0;
    while(span.scrollWidth>width+1&&attempt<5){size*=Math.min(.95,width/span.scrollWidth);span.style.fontSize=size+'px';attempt++;}
    if(attempt)changed.push({equation:span.textContent.slice(0,170),fontSizePx:size,width:span.scrollWidth});
   }
   return{mathElements:document.querySelectorAll('math').length,displayEquations:document.querySelectorAll('math[display="block"]').length,legacyRawMath:document.querySelectorAll('.math.display:not(:has(math))').length,layoutScales:changed,bodyWidth:document.body.scrollWidth,availableWidth:width};
  });
  if(layout.legacyRawMath)throw Error(`${name}: ${layout.legacyRawMath} display equations failed native typesetting`);
  const file=path.join(out,'downloads',name+'.pdf');
  await page.pdf({path:file,format:'A4',preferCSSPageSize:true,printBackground:false,tagged:true,outline:true,displayHeaderFooter:true,headerTemplate:'<div></div>',footerTemplate:'<div style="font-size:8px;width:100%;margin:0 18mm 0 20mm;color:#526359;display:flex;justify-content:space-between"><span>RESONANCE · Fields, Frequency & Mathematics · 25 Nov 2026</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>'});
  const bytes=await fs.readFile(file);receipts.push({name,path:'downloads/'+name+'.pdf',bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),layout});await page.close();
 }
}finally{await browser.close();}
await fs.writeFile(path.join(root,'docs/field-atlas/validation/pdf-rendering.json'),JSON.stringify({base,browser:browser.version(),documents:receipts},null,2)+'\n');
await fs.writeFile(path.join(out,'downloads/pdf-manifest.json'),JSON.stringify(receipts.map(({layout,...rest})=>rest),null,2)+'\n');
console.log(JSON.stringify({pdfs:receipts.length,totalBytes:receipts.reduce((n,r)=>n+r.bytes,0)}));
