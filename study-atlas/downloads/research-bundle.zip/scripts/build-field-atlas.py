"""Validate the six owned research datasets and build source-linked documents/graphs."""
from pathlib import Path
import json,hashlib,html,subprocess,re,datetime,sys,base64,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'public/study-atlas'
DOMAINS=['electrostatics','magnetism','gravity','frequency','mathematics','ai-mathematics']
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def escape(value):return html.escape(str(value))
def sequence(value):return value if isinstance(value,list) else [value]
def prose(value):return '\n'.join(map(str,value)) if isinstance(value,list) else str(value)
TYPOGRAPHY=[]
def portable_tex(tex):
 """Equivalent presentation syntax for pandoc/Office Math; original JSON stays intact."""
 def normalize_group(text):
  built='';i=0
  while i<len(text):
   if text[i]=='{' and (i==0 or text[i-1]!='\\'):
    depth=1;j=i+1
    while j<len(text) and depth:
     if text[j] in '{}' and text[j-1]!='\\':depth+=1 if text[j]=='{' else -1
     j+=1
    if depth:built+=text[i:];break
    built+='{'+normalize_group(text[i+1:j-1])+'}';i=j
   else:built+=text[i];i+=1
  depth=0;split=None
  for j,ch in enumerate(built):
   if ch=='{' and (j==0 or built[j-1]!='\\'):depth+=1
   elif ch=='}' and (j==0 or built[j-1]!='\\'):depth-=1
   if depth==0 and built[j:j+5]=='\\over' and (j+5==len(built) or not built[j+5].isalpha()):split=j;break
  if split is not None:return '\\frac{'+built[:split].strip()+'}{'+built[split+5:].strip()+'}'
  for old,new in [('rm','mathrm'),('bf','mathbf'),('cal','mathcal'),('it','mathit'),('sf','mathsf')]:
   match=re.match(r'^\s*\\'+old+r'(?![A-Za-z])(.*)$',built,re.S)
   if match:return '\\'+new+'{'+match.group(1).strip()+'}'
  return built
 result=normalize_group(tex)
 if result!=tex:TYPOGRAPHY.append({'original':tex,'rendered':result,'scope':'Equivalent legacy TeX fraction/font syntax only; original domain JSON preserved.'})
 return result
def portable_markdown(text):
 pattern=r'(\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)|(?<!\$)\$(?!\$)[^\n$]+\$(?!\$))'
 def convert(match):
  value=match.group(0);size=2 if value.startswith(('$$','\\[','\\(')) else 1
  return value[:size]+portable_tex(value[size:-size])+value[-size:]
 return re.sub(pattern,convert,text)
def run():
 datasets=[];errors=[];nodes=[];edges=[];ids={};all_sources={};source_checks=[]
 for domain in DOMAINS:
  file=OUT/'data'/f'{domain}.json'
  if not file.exists():errors.append(f'Missing domain {domain}');continue
  try:d=json.loads(file.read_text())
  except Exception as error:errors.append(f'{domain}: {error}');continue
  datasets.append(d)
  if d.get('schema')!='field-study-domain/v1' or d.get('id')!=domain:errors.append(f'{domain}: schema/id mismatch')
  for key in ['topics','formulas','sources','papers','edges','glossary','openQuestions']:
   if not isinstance(d.get(key),list):errors.append(f'{domain}: {key} must be an array')
  for kind,key in [('topic','topics'),('formula','formulas'),('source','sources'),('paper','papers'),('question','openQuestions'),('claim','claims')]:
   for item in d.get(key,[]):
    identifier=item.get('id')
    if not isinstance(identifier,str) or identifier in ids:errors.append(f'{domain}: missing/duplicate ID {identifier}');continue
    title=item.get('title') or (all_sources.get(item.get('sourceId'),{}).get('title') if kind=='paper' else None) or item.get('question') or item.get('problemStatement') or identifier
    node={**item,'id':identifier,'title':title,'kind':kind,'domain':domain}
    if 'kind' in item:node['recordKind']=item['kind']
    if kind=='source':node['sourceKind']=item.get('kind','unspecified')
    ids[identifier]=node;nodes.append(node)
    if kind=='source':all_sources[identifier]=item
  topics={t['id']:t for t in d.get('topics',[])}
  for t in d.get('topics',[]):
   if t.get('coverage') not in ['reviewed','mapped','lead']:errors.append(f"{t['id']}: invalid coverage")
   p=t.get('parentId')
   if p is not None:
    if p not in topics:errors.append(f"{t['id']}: missing parent {p}")
    elif t.get('level')!=topics[p].get('level',-99)+1:errors.append(f"{t['id']}: incorrect hierarchy level")
    edges.append({'source':p,'target':t['id'],'type':'contains','label':'Documented topic hierarchy','evidenceSourceIds':t.get('sourceIds',[])})
   elif t.get('level')!=0:errors.append(f"{t['id']}: root level is not zero")
   seen={t['id']};cursor=p
   while cursor in topics:
    if cursor in seen:errors.append(f"{t['id']}: taxonomy cycle");break
    seen.add(cursor);cursor=topics[cursor].get('parentId')
   for pre in t.get('prerequisites',[]):edges.append({'source':t['id'],'target':pre,'type':'requires','label':'Learning prerequisite','evidenceSourceIds':t.get('sourceIds',[])})
   for fid in t.get('formulaIds',[]):
    if fid not in ids:errors.append(f"{t['id']}: missing formula {fid}")
  for f in d.get('formulas',[]):
   for key in ['title','latex','plain','variables','conditions','derivation','workedExample','limitingCases','pitfalls','sourceIds','status']:
    if not f.get(key):errors.append(f"{f['id']}: missing/empty {key}")
   for v in f.get('variables',[]):
    for key in ['symbol','meaning','unit','kind']:
     if not v.get(key):errors.append(f"{f['id']}: incomplete variable {key}")
   ex=f.get('workedExample',{})
   if not isinstance(ex,dict) or not all(k in ex for k in ['inputs','steps','result','units']):errors.append(f"{f['id']}: incomplete worked example")
   edges.append({'source':f['topicId'],'target':f['id'],'type':'contains','label':'Formula/theorem used by this topic','evidenceSourceIds':f.get('sourceIds',[])})
  for item in d.get('topics',[])+d.get('formulas',[])+d.get('openQuestions',[])+d.get('claims',[]):
   contextual=str(item.get('sourceAudit','')).lower().startswith('non-source-audited')
   for sid in item.get('sourceIds',[]):edges.append({'source':item['id'],'target':sid,'type':'compares' if contextual else 'supported-by','label':'Related context; exact theorem-to-source pairing not independently checked' if contextual else 'Read the source status and limitations','evidenceSourceIds':[sid]})
  for p in d.get('papers',[]):
   if not p.get('sourceId'):errors.append(f"{p['id']}: missing paper source")
   edges.append({'source':p['id'],'target':p.get('sourceId'),'type':'reviews','label':'Selected paper review; reading depth recorded','evidenceSourceIds':[p.get('sourceId')]})
   for tid in p.get('topicIds',[]):edges.append({'source':p['id'],'target':tid,'type':'applies-to','label':'Research topic reviewed','evidenceSourceIds':[p.get('sourceId')]})
  edges.extend(d.get('edges',[]))
  for s in d.get('sources',[]):
   for key in ['url','title','status','readDepth','sectionsRead','claim','limitations','passageKind','note','retrievedAt']:
    if key not in s:errors.append(f"{s['id']}: missing source field {key}")
   if s.get('passageKind') not in ['verbatim-excerpt','research-note']:errors.append(f"{s['id']}: unclassified quote/note")
   capture=s.get('capture');expected=s.get('sha256')
   if capture and expected:
    file=ROOT/capture
    if not file.exists():errors.append(f"{s['id']}: missing capture {capture}")
    elif digest(file)!=expected:errors.append(f"{s['id']}: source hash mismatch")
    else:source_checks.append({'id':s['id'],'capture':capture,'sha256':expected})
   elif not any(word in str(s.get('status','')).lower() for word in ['lead','inaccessible','unavailable','blocked']):errors.append(f"{s['id']}: unread source lacks explicit unavailable status")
 if (OUT/'data/crosslinks.json').exists():edges.extend(json.loads((OUT/'data/crosslinks.json').read_text()))
 unique=[];edgekeys=set()
 for e in edges:
  if e.get('source') not in ids or e.get('target') not in ids:errors.append(f"Dangling edge {e.get('source')} → {e.get('target')}")
  for sid in e.get('evidenceSourceIds',[]):
   if sid not in all_sources:errors.append(f'Unknown edge evidence {sid}')
  key=(e.get('source'),e.get('target'),e.get('type'))
  if key not in edgekeys:unique.append(e);edgekeys.add(key)
 report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'domains':len(datasets),'nodes':len(nodes),'edges':len(unique),'sourceHashesChecked':len(source_checks),'errors':sorted(set(errors))}
 (ROOT/'docs/field-atlas/validation/schema.json').write_text(json.dumps(report,indent=2)+'\n')
 if errors:print(json.dumps(report,indent=2));raise SystemExit(1)
 if '--validate-only' in sys.argv:print(json.dumps(report,indent=2));return
 counts={k:sum(n['kind']==k for n in nodes) for k in ['topic','formula','source','paper','question','claim']}
 corpus={'schema':'field-study-atlas/v1','cutoff':'2026-11-25','generatedAt':report['at'],'title':'Fields, Frequency and Mathematics','scope':'A dated selected corpus with explicit coverage and reading depth; not an exhaustive enumeration of all research.','domains':datasets,'nodes':nodes,'edges':unique,'counts':counts,'sourceChecks':source_checks}
 (OUT/'data/atlas.json').write_text(json.dumps(corpus,ensure_ascii=False,indent=2)+'\n')
 (OUT/'downloads/atlas.json').write_text(json.dumps(corpus,ensure_ascii=False,indent=2)+'\n')
 graphml(corpus,OUT/'downloads/atlas.graphml')
 for d in datasets:
  build_document(d);export_graph(d)
  own={n['id'] for n in nodes if n['domain']==d['id']}
  graphml({'nodes':[n for n in nodes if n['id'] in own],'edges':[e for e in unique if e['source'] in own and e['target'] in own]},OUT/'graphs'/f'{d["id"]}.graphml')
  if d['id']=='mathematics':
   for root_id,label in [('math-algebra','Algebra'),('math-geometry','Geometry'),('math-calculus','Calculus and analysis')]:
    keep={root_id};changed=True
    while changed:
     addition={t['id'] for t in d['topics'] if t.get('parentId') in keep}-keep;changed=bool(addition);keep|=addition
    export_graph({**d,'id':'mathematics-'+root_id.replace('math-',''),'title':label,'topics':[t for t in d['topics'] if t['id'] in keep]})
 build_document(None,datasets)
 standalone_network(corpus)
 (ROOT/'docs/field-atlas/validation/typography-normalization.json').write_text(json.dumps(TYPOGRAPHY,ensure_ascii=False,indent=2)+'\n')
 (OUT/'data/manifest.json').write_text(json.dumps({'schema':'field-study-manifest/v1','cutoff':corpus['cutoff'],'counts':counts,'domains':[{'id':d['id'],'title':d['title'],'topics':len(d['topics']),'formulas':len(d['formulas']),'sources':len(d['sources']),'papers':len(d['papers']),'claims':len(d.get('claims',[]))} for d in datasets],'atlasSHA256':digest(OUT/'data/atlas.json')},indent=2)+'\n')
 print(json.dumps({**report,'counts':counts}))
def graphml(corpus,file):
 ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns);root=ET.Element('{'+ns+'}graphml')
 for k in ['title','kind','domain','relation','label','status','metadata']:ET.SubElement(root,'{'+ns+'}key',{'id':k,'for':'all','attr.name':k,'attr.type':'string'})
 g=ET.SubElement(root,'{'+ns+'}graph',{'id':'field-atlas','edgedefault':'directed'})
 for n in corpus['nodes']:
  e=ET.SubElement(g,'{'+ns+'}node',{'id':n['id']})
  for k in ['title','kind','domain']:ET.SubElement(e,'{'+ns+'}data',{'key':k}).text=str(n.get(k,''))
  ET.SubElement(e,'{'+ns+'}data',{'key':'status'}).text=str(n.get('coverage') or n.get('verificationStatus') or n.get('status') or '')
  ET.SubElement(e,'{'+ns+'}data',{'key':'metadata'}).text=json.dumps(n,ensure_ascii=False)
 for i,e in enumerate(corpus['edges']):
  item=ET.SubElement(g,'{'+ns+'}edge',{'id':'edge-'+str(i),'source':e['source'],'target':e['target']})
  for key,value in [('relation',e['type']),('label',e.get('label',''))]:ET.SubElement(item,'{'+ns+'}data',{'key':key}).text=str(value)
  ET.SubElement(item,'{'+ns+'}data',{'key':'metadata'}).text=json.dumps(e,ensure_ascii=False)
 ET.ElementTree(root).write(file,encoding='utf-8',xml_declaration=True)
def formula_markdown(f):
 cell=lambda value:str(value).replace('|','\\|').replace('\n',' ')
 variables='\n'.join('| `'+cell(v['symbol']).replace('`','')+'` | '+cell(v['meaning'])+' | '+cell(v['unit'])+' | '+cell(v['kind'])+' |' for v in f['variables'])
 ex=f['workedExample'];inputs=ex['inputs'] if isinstance(ex['inputs'],str) else json.dumps(ex['inputs'],ensure_ascii=False)
 return f"\n### {f['title']} — `{f['id']}`\n\nStatus: {f['status']}.\n\n"+('**Source pairing audit:** '+prose(f['sourceAudit'])+'\n\n' if f.get('sourceAudit') else '')+f"$$\n{f['latex']}\n$$\n\n{f['plain']}\n\n| Symbol | Meaning | Unit / convention | Object type |\n|---|---|---|---|\n{variables}\n\n**Conditions and domain**\n\n"+'\n'.join('- '+str(v) for v in f['conditions'])+'\n\n**Derivation or proof guide**\n\n'+'\n'.join(str(i+1)+'. '+str(v) for i,v in enumerate(f['derivation']))+'\n\n**Worked example**\n\nInputs: '+str(inputs)+'\n\n'+'\n'.join(str(i+1)+'. '+str(v) for i,v in enumerate(sequence(ex['steps'])))+'\n\nResult: '+str(ex['result'])+'; units: '+str(ex['units'])+'\n\n**Limits and counterchecks**\n\n'+'\n'.join('- '+str(v) for v in f['limitingCases'])+'\n\n**Common mistakes**\n\n'+'\n'.join('- '+str(v) for v in f['pitfalls'])+'\n\nSource records: '+', '.join('`'+s+'`' for s in f['sourceIds'])+'.\n'
def domain_markdown(d):
 chapter=(OUT/'chapters'/f"{d['id']}.md").read_text()
 text=chapter+'\n\n## Complete formula and theorem register\n\n'+''.join(formula_markdown(f) for f in d['formulas'])
 text+='\n\n## Research paper evidence cards\n\n'
 for p in d['papers']:
  text+='\n### '+str(p['id'])+'\n\n'
  for k in ['sourceId','status','question','method','result','whatIsNew','limitations','replication','nextQuestions']:text+='**'+k+'**: '+prose(p.get(k,''))+'\n\n'
 if d.get('claims'):
  text+='\n## AI-assisted mathematics claim ledger\n\n'
  for c in d['claims']:
   text+='\n### '+c['id']+'\n\n'
   for k,v in c.items():
    if k!='id':text+='**'+k+'**: '+prose(v)+'\n\n'
 text+='\n## Nested coverage map\n\n'
 for t in d['topics']:text+='  '*int(t['level'])+'- **'+t['title']+'** (`'+t['id']+'`; '+t['coverage']+'): '+t['summary']+'\n'
 text+='\n## Glossary\n\n'+'\n\n'.join('**'+g['term']+'** — '+g['definition'] for g in d['glossary'])
 text+='\n\n## Open questions and missing evidence\n\n'
 for q in d['openQuestions']:text+='### '+q['question']+'\n\nStatus: '+q['status']+'. '+q['neededEvidence']+'\n\n'
 text+='\n## Source records and reading depth\n\n'
 for s in d['sources']:
  text+='\n### '+s['id']+' — '+s['title']+'\n\n'+prose(s.get('authors',''))+'; '+str(s.get('year',''))+'; '+str(s.get('version',''))+'\n\n'+s['url']+'\n\n**Source class**: '+str(s.get('kind','unspecified'))+'\n\n**Status / reading depth**: '+s['status']+'; '+s['readDepth']+'\n\n**Sections inspected**: '+prose(s['sectionsRead'])+'\n\n**Supported claim**: '+s['claim']+'\n\n**Limitations**: '+prose(s['limitations'])+'\n\n**'+s['passageKind']+'**: '+s['note']+'\n\nCapture SHA-256: `'+str(s.get('sha256'))+'`; captured '+str(s.get('retrievedAt'))+'. Raw full text remains a private research capture; this package supplies bounded notes and original-source links.\n'
 return text
def build_document(domain,datasets=None):
 title=domain['title'] if domain else 'Fields, Frequency and Mathematics — Complete Study Atlas'
 name=domain['id'] if domain else 'complete-study'
 preface=f'# {title}\n\nResearch cutoff: 25 November 2026.\n\nThis is a source-linked selected corpus, with reviewed, mapped and lead coverage states. Formulas retain their hypotheses, units and derivations. Contemporary software-agent reviews do not constitute human peer review or physical validation. Statements about AI mathematics distinguish an announced result, a benchmark answer, independent mathematical review and formal verification.\n\nSymbol dictionaries preserve the exact locally scoped identifiers. A TeX identifier beginning with a backslash names the rendered symbol in the equation. The same letter can represent different quantities in different records; units, object type and the accompanying definition determine its meaning. Legacy TeX fraction/font syntax is translated only for equivalent document typesetting; original formula strings remain in the JSON corpus.\n\n'
 constants=json.loads((OUT/'data/constants.json').read_text())
 preface+='## SI constants and uncertainty\n\nSource: '+constants['sourceURL']+'; '+constants['sourceVersion']+'.\n\n| Symbol | Quantity | Value | Standard uncertainty | Unit |\n|---|---|---|---|---|\n'+'\n'.join('| '+v['symbol']+' | '+v['name']+' | '+v['valueText']+' | '+v['standardUncertaintyText']+' | '+v['unit']+' |' for v in constants['constants'])+'\n\n'+'\n'.join('- '+v for v in constants['cautions'])+'\n\nThe notation e-12 means multiplication by ten to the power minus twelve. A standard uncertainty is not automatically a confidence interval. Defined exact constants differ from uncertain instrument realizations.\n\n'
 text=preface+('\n\n'.join(domain_markdown(d) for d in datasets) if datasets is not None else domain_markdown(domain))
 text=portable_markdown(text)
 md=OUT/'downloads'/f'{name}.md';md.write_text(text)
 htmlfile=OUT/'downloads'/f'{name}.html'
 command=['pandoc',str(md),'--from=markdown+tex_math_dollars+tex_math_single_backslash+autolink_bare_uris-raw_html','--to=html5','--standalone','--toc','--toc-depth=2','--mathml','--metadata','title='+title,'--css=../book.css','--output='+str(htmlfile)]
 result=subprocess.run(command,capture_output=True,text=True)
 (ROOT/'docs/field-atlas/validation'/f'pandoc-{name}.log').write_text(result.stderr)
 if result.returncode:raise RuntimeError(result.stderr)
 # Native Word equations are generated by pandoc/texmath rather than raster screenshots.
 reference=ROOT/'docs/field-atlas/validation/reference.docx'
 if not reference.exists():
  from docx import Document
  from docx.shared import Mm,Pt
  template=subprocess.run(['pandoc','--print-default-data-file','reference.docx'],capture_output=True,check=True).stdout
  reference.write_bytes(template);document=Document(reference)
  for section in document.sections:section.page_width=Mm(210);section.page_height=Mm(297);section.left_margin=Mm(20);section.right_margin=Mm(18);section.top_margin=Mm(20);section.bottom_margin=Mm(20)
  document.styles['Normal'].font.size=Pt(11);document.save(reference)
 result=subprocess.run(['pandoc',str(md),'--from=markdown+tex_math_dollars+tex_math_single_backslash+autolink_bare_uris-raw_html','--to=docx','--reference-doc='+str(reference),'--toc','--metadata','title='+title,'--output='+str(OUT/'downloads'/f'{name}.docx')],capture_output=True,text=True)
 (ROOT/'docs/field-atlas/validation'/f'docx-{name}.log').write_text(result.stderr)
 if result.returncode:raise RuntimeError(result.stderr)
def export_graph(d):
 topics=d['topics'];children={t['id']:[] for t in topics};mapping={t['id']:t for t in topics}
 for t in topics:
  if t['parentId'] in children:children[t['parentId']].append(t['id'])
 positions={};cursor=[70]
 def place(identifier):
  t=mapping[identifier]
  if children[identifier]:
   ys=[place(c) for c in children[identifier]];y=sum(ys)/len(ys)
  else:y=cursor[0];cursor[0]+=64
  positions[identifier]=(35+t['level']*305,y);return y
 for t in topics:
  if t['parentId'] is None:place(t['id'])
 width=350+305*max(t['level'] for t in topics);height=max(200,cursor[0]+30);parts=[]
 for t in topics:
  if t['parentId'] in positions:
   x1,y1=positions[t['parentId']];x2,y2=positions[t['id']];parts.append(f'<path d="M{x1+265} {y1} C{x1+290} {y1},{x2-25} {y2},{x2} {y2}"/>')
 boxes=[]
 for t in topics:
  x,y=positions[t['id']];label=t['title'];words=label.split();lines=['']
  for word in words:
   if len(lines[-1])+len(word)>32:lines.append(word)
   else:lines[-1]+=(' ' if lines[-1] else '')+word
  lines=lines[:2];boxes.append(f'<g><title>{escape(t["title"])} — {t["coverage"]}</title><rect x="{x}" y="{y-22}" width="265" height="46" rx="4" fill="'+('#e7efe6' if t['coverage']=='reviewed' else '#faf6ed')+'" stroke="#718577"/>'+''.join(f'<text x="{x+9}" y="{y-3+i*16}" font-size="12">{escape(line)}</text>' for i,line in enumerate(lines))+'</g>')
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img"><title>{escape(d["title"])} — nested field map</title><desc>Nested topic hierarchy through research specialties. Colour indicates reviewed versus mapped/lead status, not truth or completion of the field. Full labels and sources are in the companion JSON and interactive atlas.</desc><rect width="100%" height="100%" fill="#f8f6ef"/><g fill="none" stroke="#a0afa1">'+''.join(parts)+'</g><g font-family="DejaVu Sans,system-ui,sans-serif" fill="#203c32">'+''.join(boxes)+'</g></svg>'
 (OUT/'graphs'/f'{d["id"]}.svg').write_text(svg)
 graphml({'nodes':[{**t,'kind':'topic','domain':d['id']} for t in topics],'edges':[{'source':t['parentId'],'target':t['id'],'type':'contains','label':'Topic hierarchy'} for t in topics if t['parentId']]},OUT/'graphs'/f'{d["id"]}.graphml')
def standalone_network(corpus):
 page=(OUT/'index.html').read_text();page=page.replace('<head>','<head><base href="../">',1)
 css=(OUT/'vendor/katex/katex.min.css').read_text()
 def font(match):
  raw=match.group(1).strip('"\'');file=OUT/'vendor/katex'/raw
  if not file.exists():return match.group(0)
  kind='font/woff2' if file.suffix=='.woff2' else 'font/woff' if file.suffix=='.woff' else 'font/ttf'
  return 'url(data:'+kind+';base64,'+base64.b64encode(file.read_bytes()).decode()+')'
 css=re.sub(r'url\(([^)]+)\)',font,css)
 page=page.replace('<link rel="stylesheet" href="vendor/katex/katex.min.css">','<style>'+css+'</style>').replace('<link rel="stylesheet" href="atlas.css">','<style>'+(OUT/'atlas.css').read_text()+'</style>')
 for src in ['vendor/d3/d3.min.js','vendor/katex/katex.min.js','atlas.js']:page=page.replace('<script defer src="'+src+'"></script>','')
 payload=json.dumps(corpus,ensure_ascii=False).replace('<','\\u003c')
 licenses={name:(OUT/'vendor'/name/'LICENSE').read_text() for name in ['d3','katex']}
 scripts='<script type="application/json" id="vendor-licenses">'+json.dumps(licenses).replace('<','\\u003c')+'</script><script type="application/json" id="atlas-data">'+payload+'</script>'
 for src in ['vendor/d3/d3.min.js','vendor/katex/katex.min.js','atlas.js']:scripts+='<script>'+(OUT/src).read_text().replace('</script','<\\/script')+'</script>'
 page=page.replace('</body>',scripts+'</body>')
 page=page.replace('<section class="intro">','<section class="intro"><p class="summary">Standalone graph: records, mathematical typesetting and network code are embedded. Companion document links work inside the complete research bundle. Source links open their original websites.</p>',1)
 (OUT/'downloads/network-atlas.html').write_text(page)
if __name__=='__main__':run()
