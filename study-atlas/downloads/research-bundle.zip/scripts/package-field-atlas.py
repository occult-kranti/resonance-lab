"""Inspect document structure, preserve reproducible metadata, and build the complete ZIP."""
from pathlib import Path
import hashlib,json,zipfile,re,datetime
import fitz
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'public/study-atlas'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
atlas=json.loads((OUT/'data/atlas.json').read_text());names=[d['id'] for d in atlas['domains']]+['complete-study','summary']
checks=[]
for name in names:
 pdf=OUT/'downloads'/f'{name}.pdf';doc=fitz.open(pdf);text='\n'.join(p.get_text() for p in doc);compact=re.sub(r'\s+','',text)
 formulas=[f for d in atlas['domains'] if name=='complete-study' or d['id']==name for f in d['formulas']]
 missing=[f['id'] for f in formulas if re.sub(r'\s+','',f['id']) not in compact]
 if missing:raise ValueError('Missing PDF formula identifiers '+str(missing))
 with zipfile.ZipFile(OUT/'downloads'/f'{name}.docx') as z:
  if z.testzip():raise ValueError('DOCX CRC failure')
  xml=z.read('word/document.xml');tree=ET.fromstring(xml);mathCount=len(tree.findall('.//{http://schemas.openxmlformats.org/officeDocument/2006/math}oMath'))
  if mathCount<len(formulas):raise ValueError('Word equation count too low for '+name)
  section=tree.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}sectPr/{http://schemas.openxmlformats.org/wordprocessingml/2006/main}pgSz')
  wordSize=[int(section.attrib['{http://schemas.openxmlformats.org/wordprocessingml/2006/main}w'])*25.4/1440,int(section.attrib['{http://schemas.openxmlformats.org/wordprocessingml/2006/main}h'])*25.4/1440] if section is not None else None
  if wordSize is None or abs(wordSize[0]-210)>.2 or abs(wordSize[1]-297)>.2:raise ValueError('Word explicit A4 page size missing for '+name)
 checks.append({'document':name,'pages':len(doc),'bytes':pdf.stat().st_size,'sha256':sha(pdf),'formulaIdentifiersVerified':len(formulas),'wordNativeMathObjects':mathCount,'wordPageSizeMm':wordSize,'nominalA4ToleranceMm':.2,'pageSizeMm':[doc[0].rect.width*25.4/72,doc[0].rect.height*25.4/72],'allA4':all(abs(p.rect.width-595.2756)*25.4/72<.2 and abs(p.rect.height-841.8898)*25.4/72<.2 for p in doc)})
 if not checks[-1]['allA4']:raise ValueError('PDF page size mismatch')
source_capture_notice='''This bundle contains authored explanations, selected short source notes, source URLs and hashes. Full publisher/author source captures remain private workspace records. Reading depth and source-audit status are part of every claim. Company announcements, benchmark scores, manuscript counts, formal-proof files and independently checked theorems are separate categories.
The 730-item AI manuscript index is unread-indexed metadata, not 730 verified solutions.
Vendor code retains its license: KaTeX MIT; D3 ISC. Source materials retain their individual licenses.
Rebuild in the authoring repository with its public/study-atlas layout and private source-capture cache: python scripts/validate-field-atlas-science.py; python scripts/build-field-atlas.py; python scripts/summarize-field-atlas.py; serve public on port4200; node scripts/export-field-atlas.mjs; python scripts/package-field-atlas.py.
For reading this bundle, open index.html or downloads/network-atlas.html. All graph data/code/fonts are embedded. The managed test browser forbids direct file navigation; the self-contained page was verified over HTTP with every follow-up request blocked. A browser permitting local HTML or a normal static HTTP server can display it. Source captures must be reacquired separately for a new source-audited document rebuild.
'''
(OUT/'README.txt').write_text(source_capture_notice)
files=[p for p in OUT.rglob('*') if p.is_file() and p.name!='research-bundle.zip' and p!=OUT/'data/downloads.json' and not p.name.endswith('.map')]
bundle=OUT/'downloads/research-bundle.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):
  if p==OUT/'index.html':z.writestr('index.html',(OUT/'downloads/network-atlas.html').read_text().replace('<base href="../">',''))
  else:z.write(p,str(p.relative_to(OUT)))
 for roundNumber in range(1,4):
  directory=ROOT/f'docs/field-atlas/round-{roundNumber}'
  for p in sorted(directory.glob('*.md')):z.write(p,str(p.relative_to(ROOT)))
  freeze=directory/'freeze.json'
  if freeze.exists():z.write(freeze,str(freeze.relative_to(ROOT)))
 for p in [ROOT/'docs/field-atlas/CONTRACT.md',ROOT/'scripts/build-field-atlas.py',ROOT/'scripts/summarize-field-atlas.py',ROOT/'scripts/validate-field-atlas-science.py',ROOT/'scripts/export-field-atlas.mjs',ROOT/'scripts/package-field-atlas.py']:
  z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(bundle) as z:
 if z.testzip():raise ValueError('Research ZIP CRC failure')
receipt={'schema':'field-study-downloads/v1','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'documents':checks,'bundle':{'path':'downloads/research-bundle.zip','bytes':bundle.stat().st_size,'sha256':sha(bundle)},'corpusSHA256':sha(OUT/'data/atlas.json'),'scope':'Selected corpus and recorded review rounds; no raw copyrighted source captures are included.'}
(OUT/'data/downloads.json').write_text(json.dumps(receipt,indent=2)+'\n')
(ROOT/'docs/field-atlas/validation/document-integrity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'pdfs':len(checks),'completeBookPages':next(c['pages'] for c in checks if c['document']=='complete-study'),'bundleBytes':bundle.stat().st_size}))
