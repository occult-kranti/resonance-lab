# Patent-style documentation: source-led standards profile

Research completed from actual official responses on 17 November 2026 UTC. This document supplies a technical documentation checklist, not certified filing compliance, a patentability conclusion, a manufacturing drawing approval or an enablement finding. The European Patent Office (EPO) is not the European Union; EPC/EPO requirements are not a claim about every European national office.

Machine-readable evidence is in `public/data/patent-standards.json`. Eighteen HTML responses, extracted text and a retrieval ledger with original URL, redirected URL, HTTP status, time, byte count and SHA-256 are retained under `docs/patent-standard/evidence/`. Each source entry states precisely which operative sections were read. HTTP 200 alone was not treated as legal/current-status evidence.

## Important current-law correction

The official EPC Rule46 page says **deleted**, effective 1 February 2023, by CA/D10/22. Its historical drawing text remains displayed. The current Rule49(2) delegates presentation requirements to the President of the EPO. The current page points to the **7 July 2025 President decision, OJ EPO2025A49**, effective 1 October 2025. That decision's Article6 expressly supersedes the 2022 decision A113.

Current EPO A49 Article1(2)(a) permits colour or greyscale drawings when filed electronically, subject to durability, contrast and suitability for clear display at 300dpi. Notice OJ2025A57 distinguishes Euro-direct, PCT international phase and Euro-PCT transition conditions. Thus monochrome is our conservative common-profile choice; it is **not** a claim that the EPO currently forbids all colour. PCT international-phase colour remains inadmissible under Rule11.13; US utility colour involves its own exception/petition conditions. Electronic filing-channel requirements, including the separate 2026 electronic-filing decision referenced by Rule49, were not exhaustively audited.

## Mechanical drawing-sheet checklist

Use A4 portrait 210×297mm for a common profile. The US also allows 216×279mm Letter; the EPO normally requires A4, and PCT's receiving-office sheet-size exception still requires an A4 record copy. Drawing margins are at least top25mm, left25mm, right15mm and bottom10mm, leaving a maximum170×262mm A4 sight. Do not draw a border around that sight.

Drawing numbers/letters/reference characters must be at least **3.2mm** high under US §1.84(p)(3), current EPO A49 Art1(2)(g) and PCT11.13(h). This is not the EPO description-text2.1mm minimum or the PCT ordinary-text2.8mm minimum. SVG font-size is not necessarily actual glyph/capital height; a rescaled1200-unit diagram can fail even when its surrounding A4 frame/margins pass. Measure actual reference geometry or rendered glyph bounds at the physical output size, and inspect the real two-thirds reduction. A numeric check alone cannot establish semantic legibility.

Use durable, well-defined high-contrast black lines for the common profile, with distinguishable hatch/leader strokes. The sources do not prescribe a universal0.25mm line width: that is an engineering choice, not a legal threshold. When a section exists, use hatching that does not obscure leaders/references. Avoid inventing sections, unseen materials or missing geometry. Preserve proportions unless a stated clarity exception is necessary; US drawings cannot rely on “actual size” or “scale1/2”. EPO/PCT exceptional scale indications use a graphic scale.

Keep reference signs consistent across views and the description. US lead lines normally originate near the character and extend to the feature without crossing other leaders; specific surface/section exceptions have their own underline treatment. Use enough separate views to convey the subject, not overlapping/projected views that imply missing source information. Long teaching prose, complete definitions, product tables and explanations belong in the separate description/reference packet; drawing words are limited to indispensable short terms where applicable.

## US / EPO / PCT distinctions

| Topic | US utility drawings | EPO current A49 | PCT international application |
|---|---|---|---|
| Main drawing authority | 37CFR1.84; selected MPEP608.02 guidance | Rule49(2) plus President decision2025A49; former Rule46 deleted | Rule11, especially11.6/11.11/11.13 |
| Sheet size | A4 or Letter | A4 | A4 record copy, with receiving-office exception described in11.5 |
| Common margins |25/25/15/10mm |25/25/15/10mm |25/25/15/10mm |
| Drawing character height |≥3.2mm |≥3.2mm |≥3.2mm |
| Colour |Black/white normal; utility colour petition exception |Electronic colour/greyscale permitted with contrast/300dpi suitability; paper rule differs |Colour inadmissible for international processing/publication; do not transfer EPO permission |
| Scan targets |§1.84(g) says **should**, on **two catercorner margin corners** |No equivalent common marker mandate in A49 |No equivalent mandate in selectedRule11 provisions; margins generally blank |
| Figure numbers |Sequential FIG.n for multi-view applications; **single-view US application has no number and no FIG.** |Arabic figures independent of page numbering |Arabic figures independent of sheet numbering |
| Sheet numbers |If present, within sight, sheet/total format, larger than reference signs; §1.84(t) |Consecutive top-centred numbers, not in top margin |Consecutive numbers top or bottom-centred, not in margin |
| Reference signs in claims |Case-specific US claim practice not exhaustively covered here |Rule43(7): parenthesised signs where helpful, not limiting claims |Not converted into an EPO-only assumption |

The “common” figure exporter assumes a multiple-figure explanatory set. It cannot silently certify a single-view US filing. US scan targets are a recommendation, not a mandatory four-marker rule; the initial preliminary assumption was corrected against the actual §1.84(g) wording.

## Separate description, claims and sufficiency checks

1. **Description structure:** EPC Rule42 asks for technical field, useful known background, the technical problem/solution and effects, brief description of figures, at least one detailed way of carrying out, and industrial applicability when not obvious. US §1.71 asks for full, clear, concise and exact making/using information. Reference signs must connect to actual features described.
2. **Definitions and educational explanation:** complete units, variable meanings, source-specific peak/RMS conventions, operating assumptions, interfaces and source hierarchy are this product's explanatory extension. They are not all independently prescribed legal typography rules.
3. **Claims and support:** EPC Art84 and Rule43 require clear, concise, description-supported technical features and coherent dependencies. A claim cannot generally substitute “as shown in figure…” for its technical definition. No claim, novelty or inventive-step opinion is generated merely by numbering references.
4. **Enablement/sufficiency:** US MPEP2164 and EPC Art83/F-III1 address the skilled person and sufficient making/using information without undue experimentation/burden. An educational “from scratch” guide may go beyond that legal audience, but missing essential turns, ratings, coupling data, tolerances, calibration or demonstrated effects remain gaps. Attractive sheets and the list of terms do not fill them. Do not claim a proposed apparatus is enabled, buildable or proven solely because its mechanical sheet checks pass.
5. **Version/new matter:** MPEP608.02 quotes35USC113/37CFR1.81(d): later drawings cannot cure insufficient original enabling disclosure or supplement original claim scope. EPC Art123(2) bars extending beyond content as filed, and(3) concerns extending granted protection. New authored explanatory geometry must be labelled as later material, not silently presented as an earlier application's original disclosure.
6. **Proposed versus operated:** retain separate statuses for source assertions, hypothetical setup protocols, deterministic model outputs and measured apparatus. A reproducible software experiment is not a built product, calibrated measurement or office acceptance.

The scratch-setup packet should list known tools/components/interfaces, unit conventions, prerequisite skill, a measurement/calibration plan, controls and explicit missing specifications. This is a documentation design choice. Products/SOTA papers require separate source review and should not be treated as standards-law evidence.

## Evidence limitations

The study read selected operative provisions and guidance passages, not all prosecution rules, national law, filing interfaces or later case law. Official pages may show deleted/struck historical wording alongside current text; current provisions were cross-checked against the operative2025 decision. A4/page/reference mechanics can be checked by software, while rendered legibility, sufficient technical disclosure, whole-claim support, patentability and filing acceptance require separate review. No compliance or certification badge follows from this catalogue.
