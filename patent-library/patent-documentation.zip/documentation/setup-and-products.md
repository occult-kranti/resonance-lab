# From source drawing to a testable setup

The seven staged guides in `public/data/blueprint-build-guides.json` account for all eleven current setup/view records. They provide starting prerequisites, a desk-model stage, a specification stage, commissioning controls, measurable quantities, rival explanations and explicit stop gates. They are proposed study plans, not eleven certified designs, a procurement list, a report of new measurements or an exhaustive state-of-the-art review.

## Family coverage and real gaps

| Guide | Records covered | What must be resolved before a physical build |
| --- | --- | --- |
| Coupled resonator | `nt:coupled-coils` | Actual coil turns, wire/core, measured L/M/R, component ratings, source impedance and simultaneous calibrated voltage/current readout |
| Witness calibration | `nt:environmental-witness` | Raw-pickup conversion, complex transfer, signal leakage, drift and calibration uncertainty |
| Prism study | `nt:newton-prism` | Actual manufacturer geometry and glass dispersion, controlled illumination and optical calibration; attempted product specifications were inaccessible |
| Sound monitor | Four phone/dual-channel plan and 3D views | Source/room/microphone/recorder contributions, mixed-channel identifiability and optional monitor calibration |
| Series RLC | `atlas:v4-electric-energy` | Actual passive ratings, initial state, source/probe transfer and independently integrated work |
| Ordinary magnetic force | Two magnetic-force plan/3D views | Balance magnetic susceptibility, field/force geometry, support reactions and repeatability |
| Variable-inductance work | `atlas:v4-magnetic-work` | Measured L(z), actuator and controller work, friction, electrical/mechanical ratings and calibrated force/position |

Original model values remain separate from product choice. For example, R1's 10 mH / 40 mH coils, 3 mH mutual inductance and 1 V peak source do not specify winding construction or a commercial part. The separate host 0.15 V RMS example is not substituted into that fixture. Representative products illustrate a role and a selection question; they are not asserted compatible drop-in parts.

## Primary manufacturer documents actually inspected

- **Vishay WSL**, document 30100, revision 23 November 2023: first-page electrical specifications, current-sense role and derating note inspected. WSL2512 is a low-value current-sense family; it is not a recommendation for the source's 20 Ω useful load. Its value/package/power limits require actual selection.
- **WIMA MKP10**: official product-page construction, capacitance/voltage ranges and electrical overview read. A family range does not verify a particular 10 µF or 2.5 µF stock code, AC rating, ripple capability or availability.
- **Focusrite Scarlett 2i2, fourth generation**: current manufacturer technical specifications read. It has two physical audio inputs. The advertised simultaneous I/O count includes loopback; it must not be presented as four physical measurement inputs or an isolated electrical power analyzer.
- **miniDSP UMIK-1**: manufacturer calibration and feature sections read. A serial-specific microphone calibration is useful but does not synchronize two USB devices, remove room/source effects or establish intrinsic material damping.
- **Texas Instruments DRV5055**, SBAS640C, revised **June 2026**: first-page features, supply, variant sensitivity, orientation and bandwidth read. This is a ratiometric magnetic-flux-density sensor, not a force or gravity sensor. Actual variant, reference and calibration remain implementation choices.
- **Adam Equipment Luna**: current manufacturer model/readability and calibration sections read. LPB223e is a 220 g / 0.001 g readability example. Readability is not accuracy, force calibration or magnetic immunity.

Where `documentKind` says manufacturer product specifications, `datasheetURL` leads to that official product-specification page rather than falsely claiming an archived PDF. Actual PDF datasheets are identified as such. All prices, stock, procurement and fitted performance remain unverified as of the UTC retrieval timestamps in the data.

## Modern research, historical patent and evidence boundaries

The actual HTML of **ABRACADABRA-10 cm, arXiv:2102.06722v1 (2021)** was retrieved. The abstract, selected magnet-off/environmental-veto discussion and Supplementary III detector calibration were read. Its end-to-end conversion and known-injection controls motivate a complete calibration account. The paper reports no significant evidence for axions. No detector sensitivity, cryogenic apparatus design, axion coupling or statistical significance is borrowed for this workbench. The paper's RMS/peak-to-peak convention is specific to its chain and must not be silently transplanted.

The **2025 two-Hindu-temple acoustic paper** is retained at abstract-reading depth. It supports distinguishing an identified room impulse response and decay analysis from a photograph or a single material-frequency claim; its full field protocol and response files were not inspected or imported.

**Tesla US1119732A** was retrieved as historical patent provenance. Selected apparatus-description paragraphs describe coupled/tuned circuits. The complete claim set was not legally analyzed, and a patent is not evidence of tested efficiency, safety, energy creation or present construction readiness. No high-voltage patent reproduction is proposed by these guides.

These selected sources do not establish that all modern patents, products or papers were searched or that the proposed fixtures are novel inventions. Proposed improvements stay distinct from frozen source values and physical results.

## Negative access and buildability status

Digilent/Pico instrument pages and Newport/Edmund optical pages returned 403. A Thorlabs PS911 route returned a short web-app shell without readable product specifications; a SCHOTT candidate returned 404. These observations are retained, not converted into claims of source reading or product compatibility. No optical part specification was invented to close the gap.

The desk/simulation stages can proceed from the pinned contracts. Physical commissioning remains conditional where ratings, materials, calibration or source identity are missing. Each stage names checks and stop conditions; completing a screen does not mark hardware as built.

## Reproducibility

Actual request URLs/times, response statuses, source bodies, selected read excerpts and hashes are retained in `docs/patent-standard/sources/`. `setup-source-ledger.json` gives exact reading depth and limitations. `setup-capture-manifest.json` binds captured bytes. `setup-guide-checks.json` verifies one-to-one coverage of all eleven records by seven guides, populated stage gates and unverified product price/availability labels.

No purchases, provider messages, hardware operation, remote publication or new physical measurements were performed. Other historical artifacts outside the current eleven-record registry remain separate inventory work; this guide does not claim they were all converted.

## Bounded follow-up: product gaps and two proposed research branches

A second short manufacturer-source pass did not verify the missing optical/instrument specifications. Pico's candidate PDF URL returned 404; SCHOTT's candidate PDF returned 503; an Edmund LED page returned 403. A Thorlabs legacy route redirected to a penta-prism web-app shell without readable specifications. A purported Keysight PDF address redirected to an HTML search page. HTTP 200 in either case is not a datasheet read. These semantic failures are retained in `sources/followup-retrievals.json`; no part, safe optical-output rating or input-isolation specification was invented from them.

The two retained modern primary papers in `patent-literature.json` were independently checked against their actual captured text:

- **“Maximizing wireless power transfer efficiency at exceptional points” (2025)**: read the abstract, selected gain/loss Results, inverter/controller description and Conclusions. The active parity-time system includes a gain element, receiver losses and a converter/controller architecture; it is not the passive R1/R2 circuit. A useful incremental test is to preserve the existing passive load/coupling sweep unchanged, then predefine a separate adaptive-load branch under comparable source/load conditions. Include all converters, controllers, auxiliary supplies, losses and endpoint storage in its work budget. Compare held-out conditions and uncertainty. Do not adopt the paper's efficiency, exceptional-point setting or circuit values as workbench results.
- **“Deep room impulse response completion” (2025)**: read the abstract, stated 50 ms / 48 kHz encoder input, Discussion and Conclusion. DECOR predicts a late tail; the Discussion explicitly reports a substantial loss of performance on an unseen dataset. A useful incremental test would keep measured responses and the deterministic seven-path model intact, then evaluate an optional licensed completion model on entire held-out rooms, comparing frequency-dependent decay and waveform/energy diagnostics. A synthetic tail cannot authenticate monument geometry, historical sound, intrinsic damping or the response of an unrecorded object. No model, training data or claimed paper performance was installed or adopted.

These are proposed research improvements, separately named in the relevant guide fields. The frozen source model, original numerical values and current buildability gates remain unchanged. The source ledger now contains eleven qualified records: the original nine plus these two independently inspected proposal sources. This is still a bounded selection, not an exhaustive SOTA, novelty, patentability or freedom-to-operate search.
