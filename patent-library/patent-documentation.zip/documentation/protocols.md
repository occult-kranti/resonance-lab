# Complete selected proposal and protocol disclosure worksheets

Every selected activeproposalID13 and declaredhostprotocol4 has a source-bound disclosure worksheet. This is not all historical artifacts converted, all controls executed, patent filing readiness or legal compliance.

Generated 2026-11-17T05:00:10.382Z.

Coverage: **17 worksheets** =13 active proposal IDs +4 actual host protocols. **6** have explicit current-catalogue proposalIds relations (editorial where stated by the registry); **11** have no declared apparatus and are blocked from invented physical drawings.

The original11 blueprint dossiers do not cover every historical source artifact. The separate overlay register links26 exact source representations while preserving the2,429 broad candidates as unconverted/unassessed. Logos, plots, illustrations and research/UI documents are not silently reclassified as engineering drawings.

US/EPO template fields are populated from source values only. No formal claims, completed working examples, measured results or enablement are invented. Every row retains source status and blockers.

## NT-H01 — Coupled coils exchange and dissipate supplied energy
Kind: active-proposal. Upstream status: **selected_model_question**. Apparatus: **linked-proposed-drawings-not-physically-validated**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: nt:coupled-coils, atlas:v4-electric-energy

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H01" | Stable source identifier | identifier, not a physical unit |
| category | "electricity" | Source classification of the question | classification, not a quantity |
| title | "Coupled coils exchange and dissipate supplied energy" | Source-provided research title | plain-language label |
| priority | 1 | Source editorial ordering | ordinal index, not probability |
| prediction | "Changing secondary loading changes both receiver output and transmitter response under a passive coupled-circuit model." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Apparent excess is an omitted source, stored energy, mutual-energy term or voltage/current phase error." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Signed input power; primary/secondary currents; stored-field energy; load and copper loss." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Source-off/zero-state","Zero coupling","Known load change","Independent work integration"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Python simulation","Optional current-limited low-voltage two-coil circuit"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "Energy closure fails outside declared numerical or measurement uncertainty after every term is retained." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "selected_model_question" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["TESLA-1892","NT-TESLA-TRANSMISSION","ATLAS-V4-R3"] | Upstream citation identifiers | reference IDs |
| tags | ["free-energy","Tesla","resonance"] | Source search/index labels | keywords, not evidence |
| novelty | "Established model; new project application and adversarial controls, not a new conservation law." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- Linked drawings are proposed/conceptual source records, not validated construction specifications.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: existing-source-proposed-views-only.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H02 — Receiver loading can help localize a drive
Kind: active-proposal. Upstream status: **proposed_extension**. Apparatus: **linked-proposed-drawings-not-physically-validated**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: nt:coupled-coils

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H02" | Stable source identifier | identifier, not a physical unit |
| category | "electricity" | Source classification of the question | classification, not a quantity |
| title | "Receiver loading can help localize a drive" | Source-provided research title | plain-language label |
| priority | 2 | Source editorial ordering | ordinal index, not probability |
| prediction | "Complex responses across deliberately changed loads can distinguish drives at different ports when the transfer columns are independent." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Unknown coupling, distributed pickup or gain can reproduce a source-location signature." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Amplitude and phase at two ports across loads and frequencies; conditioning of the inference map." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Known injection at each port","Fit one load and predict another","Near-degenerate ports","Unknown gain adversary"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Synthetic multiport circuit","Optional low-voltage generator and synchronous readout"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "A rival drive/gain pair reproduces every selected observable or a held-out load defeats the inferred source." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "proposed_extension" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["TESLA-1892","NT-DMRADIO-CORE2026","NT-ABRA2021"] | Upstream citation identifiers | reference IDs |
| tags | ["free-energy","identifiability"] | Source search/index labels | keywords, not evidence |
| novelty | "Potentially useful apparatus-specific inference experiment; novelty not established." | Source novelty statement | unverified attributed assessment |
| executionBoundary | "The across-load prediction is a future extension. Frozen R2 tests a coherent two-current inversion at one frequency and nominal load, with parameter and phase uncertainty; it does not execute a load scan." | Explicit boundary on what source work executed | textual scope restriction |

### Unresolved disclosure and physical-build gates

- Linked drawings are proposed/conceptual source records, not validated construction specifications.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: existing-source-proposed-views-only.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H03 — A dark-matter-like narrow line needs environmental witnesses
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **linked-proposed-drawings-not-physically-validated**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: nt:environmental-witness

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H03" | Stable source identifier | identifier, not a physical unit |
| category | "gravity" | Source classification of the question | classification, not a quantity |
| title | "A dark-matter-like narrow line needs environmental witnesses" | Source-provided research title | plain-language label |
| priority | 3 | Source editorial ordering | ordinal index, not probability |
| prediction | "A specified hypothetical signal response must survive appropriate source-field and environmental-control comparisons with retained sensitivity." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Mains harmonics, moving spectral lines, gain drift or magnetic vibration make similar peaks." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Calibrated transfer function, line evolution and witness cross-response; no cosmological identification from peak shape alone." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Signal injection","Source-field-off condition","Witness signal leakage test","Held-out nuisance settings"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Synthetic signal and receiver model"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "A supposed identifying statistic can be reproduced by an ordinary nuisance or rejects injected signals." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-ABRA2021","NT-DMRADIO-CORE2026"] | Upstream citation identifiers | reference IDs |
| tags | ["dark-matter","magnetic-receiver"] | Source search/index labels | keywords, not evidence |
| novelty | "Control-design exercise; not an axion search or a claim of achieved particle sensitivity." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- Linked drawings are proposed/conceptual source records, not validated construction specifications.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: existing-source-proposed-views-only.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H04 — Readout sensitivity has an optimum that need not maximize signal amplitude
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **linked-proposed-drawings-not-physically-validated**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: nt:coupled-coils, nt:environmental-witness

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H04" | Stable source identifier | identifier, not a physical unit |
| category | "magnetism" | Source classification of the question | classification, not a quantity |
| title | "Readout sensitivity has an optimum that need not maximize signal amplitude" | Source-provided research title | plain-language label |
| priority | 4 | Source editorial ordering | ordinal index, not probability |
| prediction | "In a stated noisy receiver model, stronger coupling alters loading and input-referred noise as well as gain." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Ranking designs by peak voltage hides backaction, bandwidth loss or added inductance." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Signal-to-noise metric and transfer bandwidth under fixed source/noise assumptions." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Uncoupled readout","Independent noise terms","Noise correlation counterexample","Bandwidth-integrated metric"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Python model"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "The purported optimum changes when omitted noise/bandwidth is included or fails held-out parameter tests." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-SQUID-NOISE2025"] | Upstream citation identifiers | reference IDs |
| tags | ["magnetism","noise"] | Source search/index labels | keywords, not evidence |
| novelty | "Classical analogue only unless quantum/SQUID assumptions are explicitly implemented." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- Linked drawings are proposed/conceptual source records, not validated construction specifications.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: existing-source-proposed-views-only.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H05 — A scale signal is not automatically a change in gravity
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **linked-proposed-drawings-not-physically-validated**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: atlas:v4-magnetic-force-plan, atlas:v4-magnetic-force-3d, atlas:v4-magnetic-work

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H05" | Stable source identifier | identifier, not a physical unit |
| category | "gravity" | Source classification of the question | classification, not a quantity |
| title | "A scale signal is not automatically a change in gravity" | Source-provided research title | plain-language label |
| priority | 5 | Source editorial ordering | ordinal index, not probability |
| prediction | "Ordinary electromagnetic lift changes a sample support force and produces a reaction elsewhere in the apparatus." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Lead forces, susceptibility, electrostatic attraction, heating or source support outside the weighed boundary." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Sample and source reaction; field gradient; separately characterized reference." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Whole-system boundary","Source versus sample displacement","Matched heating","Current reversal with even-force rival"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Simulation","Later magnet/coil, stand and force/position sensors"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "The signal follows material/field geometry or cancels with source reaction; remaining unexplained residual does not identify gravity." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-TAJMAR2024","NT-GRAPHITE2024","NT-NASA-CAPACITOR2004"] | Upstream citation identifiers | reference IDs |
| tags | ["antigravity","force-metrology"] | Source search/index labels | keywords, not evidence |
| novelty | "Known physical alternatives; no bench gravity result." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- Linked drawings are proposed/conceptual source records, not validated construction specifications.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: existing-source-proposed-views-only.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H06 — Prism geometry can distinguish dispersion from a single-index optical model
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **linked-proposed-drawings-not-physically-validated**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: nt:newton-prism

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H06" | Stable source identifier | identifier, not a physical unit |
| category | "history" | Source classification of the question | classification, not a quantity |
| title | "Prism geometry can distinguish dispersion from a single-index optical model" | Source-provided research title | plain-language label |
| priority | 6 | Source editorial ordering | ordinal index, not probability |
| prediction | "With stipulated wavelength-dependent indices, a two-prism ray model predicts different emergent angles for selected spectral rays." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Single-index model, aperture extent or geometry misalignment explains an apparent spread." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Ray intersection positions and angular separations under declared indices and geometry." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Single-index limit","Reversed second prism","Aperture/incident-angle sweep","Ray geometry check"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Python ray trace","Optional prism, diffuse white light and screen"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "The variable-index model fails its own geometric constraints or a competing calibrated model fits the chosen observations." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-NEWTON-LIGHT1672","NT-NEWTON-ANALYSIS"] | Upstream citation identifiers | reference IDs |
| tags | ["Newton","optics"] | Source search/index labels | keywords, not evidence |
| novelty | "Modern illustrative reconstruction; stipulated colors/indices are not historical measurements." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- Linked drawings are proposed/conceptual source records, not validated construction specifications.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: existing-source-proposed-views-only.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H07 — Orbital periods identify force scaling only under stated geometry
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H07" | Stable source identifier | identifier, not a physical unit |
| category | "gravity" | Source classification of the question | classification, not a quantity |
| title | "Orbital periods identify force scaling only under stated geometry" | Source-provided research title | plain-language label |
| priority | 7 | Source editorial ordering | ordinal index, not probability |
| prediction | "For circular trajectories, T² proportional to r³ implies centripetal acceleration proportional to r^-2." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Different orbit geometry, period definition or an unmodeled central distribution changes the inverse interpretation." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Period-radius log slope and forward trajectory agreement." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Circular limit","Perturbed law","Eccentric-orbit counterexample","Dimension check"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Python or algebra only"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "A claimed general force law cannot reproduce held-out trajectories, or multiple laws remain observationally indistinguishable." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-NEWTON-MOTION"] | Upstream citation identifiers | reference IDs |
| tags | ["Newton","physical-prediction","dark-matter"] | Source search/index labels | keywords, not evidence |
| novelty | "Established reconstruction; no inference of dark matter from a toy orbit." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H08 — A chymical name and color do not uniquely identify an element
Kind: active-proposal. Upstream status: **historical_analysis**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H08" | Stable source identifier | identifier, not a physical unit |
| category | "history" | Source classification of the question | classification, not a quantity |
| title | "A chymical name and color do not uniquely identify an element" | Source-provided research title | plain-language label |
| priority | 8 | Source editorial ordering | ordinal index, not probability |
| prediction | "Context and independent composition/phase information narrow a set of plausible modern substances more than the symbol alone." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Literal universal substitution of every planetary name by one pure element." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Candidate-set size and contradictions against source context." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Literal/disguised paired examples","Compound versus element","Known mixed-sample counterexample"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Text collation","Reference data; no preparation of historical mixtures"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "A proposed unique identification fails another occurrence or an independent assay; unresolved candidates remain plural." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "historical_analysis" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-NEWTON-CHYMISTRY","NT-CHYMISTRY-GLOSSARY"] | Upstream citation identifiers | reference IDs |
| tags | ["alchemy","Newton"] | Source search/index labels | keywords, not evidence |
| novelty | "Source-bound classification, not transmutation or a measured historical composition." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H09 — Collected radiant energy must be traced to an external flux or initial storage
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H09" | Stable source identifier | identifier, not a physical unit |
| category | "electricity" | Source classification of the question | classification, not a quantity |
| title | "Collected radiant energy must be traced to an external flux or initial storage" | Source-provided research title | plain-language label |
| priority | 9 | Source editorial ordering | ordinal index, not probability |
| prediction | "A powered/light-driven charging analogue supplies output only through tracked input and stored energy." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Uncounted light, auxiliary supply or charged capacitor is called source-free output." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Incident-input proxy, charging history, delivered joules and endpoint storage." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Dark/source-off","Discharged initial state","Load change","Auxiliary source ledger"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Simulation","Optional low-voltage photovoltaic/capacitor analogue"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "Output attributed to a novel source disappears when external/initial energy is counted; an anomaly requires an uncertainty-bounded physical budget." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-TESLA-RADIANT","TESLA-1892"] | Upstream citation identifiers | reference IDs |
| tags | ["Tesla","free-energy"] | Source search/index labels | keywords, not evidence |
| novelty | "Conceptual analogue, not replication of Tesla radiation hardware." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H10 — Static diamagnetic lift has a geometric restoring-force signature
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H10" | Stable source identifier | identifier, not a physical unit |
| category | "magnetism" | Source classification of the question | classification, not a quantity |
| title | "Static diamagnetic lift has a geometric restoring-force signature" | Source-provided research title | plain-language label |
| priority | 10 | Source editorial ordering | ordinal index, not probability |
| prediction | "A declared diamagnetic model predicts an equilibrium where magnetic force balances weight and a geometry-dependent local stiffness." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Optical parallax, airflow, supports, unmodeled susceptibility anisotropy or finite-magnet geometry." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Equilibrium gap, displacement response and stiffness." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Geometry variation","Optical scale","Field-gradient limit","Independent source support"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Simulation","Later contained magnets and pre-cut graphite"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "The model misses held-out equilibria or stability within its declared approximation error." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-GRAPHITE2024"] | Upstream citation identifiers | reference IDs |
| tags | ["magnetism","levitation"] | Source search/index labels | keywords, not evidence |
| novelty | "Magnetic support, not gravity shielding; no claim of free mechanical work." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H11 — Internal moving masses require a complete center-of-mass test
Kind: active-proposal. Upstream status: **candidate**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H11" | Stable source identifier | identifier, not a physical unit |
| category | "gravity" | Source classification of the question | classification, not a quantity |
| title | "Internal moving masses require a complete center-of-mass test" | Source-provided research title | plain-language label |
| priority | 11 | Source editorial ordering | ordinal index, not probability |
| prediction | "In an isolated Newtonian model, cyclic internal actuation preserves total momentum; supported devices may move through environmental reactions." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Tracking the housing while omitting moving masses, friction, cables or expelled material creates apparent reactionless motion." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Center-of-mass trajectory of housing plus every moving mass and source." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["No external force","Add explicit friction","Complete versus housing-only tracking","Reverse cycle"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Multibody simulation"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "An asserted isolated translation vanishes with the complete boundary, or model momentum fails numerical convergence." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "candidate" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-PROPULSION-PATENT2026","NT-NASA-BPP2005"] | Upstream citation identifiers | reference IDs |
| tags | ["antigravity","current-patent"] | Source search/index labels | keywords, not evidence |
| novelty | "A new patent motivates a standard conservation audit; no hardware performance validated." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H12 — Asymmetric electrostatic pressure must close the force boundary
Kind: active-proposal. Upstream status: **held**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H12" | Stable source identifier | identifier, not a physical unit |
| category | "gravity" | Source classification of the question | classification, not a quantity |
| title | "Asymmetric electrostatic pressure must close the force boundary" | Source-provided research title | plain-language label |
| priority | 12 | Source editorial ordering | ordinal index, not probability |
| prediction | "A declared static apparatus model includes all electrodes, source and external boundaries in its force integral." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Partial surface integration, chamber attraction, gas momentum or leakage is interpreted as a self-force." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Closed/partial stress integral and dependence on boundary placement." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Boundary enlargement","Return electrode","Gas nuisance","Geometry reversal"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Electrostatic simulation/document study only"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "The alleged closed-system thrust disappears with omitted surfaces or environmental exchange; a residual alone is not inertial-mass reduction." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "held" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-BUHLER-PATENT","NT-NAVY-PAIS-PATENT","NT-NASA-CAPACITOR2004","NT-TAJMAR2024"] | Upstream citation identifiers | reference IDs |
| tags | ["antigravity","patents"] | Source search/index labels | keywords, not evidence |
| novelty | "No independently validated exotic mechanism selected; no high-voltage build." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## NT-H14 — A Hermetic correspondence becomes physics only after a testable map is specified
Kind: active-proposal. Upstream status: **historical_analysis**. Apparatus: **blocked-no-apparatus-declared**.
Source: newton-tesla-research-lab/data/hypotheses.json; SHA-256 2e20de76497493752eaadedd5bed90ca86ae26ccac413ad2c5bdee899c3a1874; upstream-source-pin-retained.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "NT-H14" | Stable source identifier | identifier, not a physical unit |
| category | "history" | Source classification of the question | classification, not a quantity |
| title | "A Hermetic correspondence becomes physics only after a testable map is specified" | Source-provided research title | plain-language label |
| priority | 14 | Source editorial ordering | ordinal index, not probability |
| prediction | "If two models are claimed equivalent, an explicit state/observable map must preserve the declared dynamics within a bounded error." | Source-declared expected relation to test | Units/channels must be read from the observable and future acquisition contract |
| rival | "Visual similarity or an above/below metaphor substitutes for units, boundary conditions and an identifying prediction." | Ordinary competing explanation retained from source | textual alternative |
| observable | "Mapped trajectories or conserved quantities, plus residual error over a declared domain." | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| controls | ["Scale change","Boundary change","Counterexample with similar appearance but different dynamics"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| materials | ["Algebra or two small simulations"] | Source proposed resources | source inventory, not validated quantities/ratings/BOM |
| falsifier | "A map fails a held-out boundary or cannot be defined; retain the idea as interpretation rather than a physical law." | Source-declared observation that would challenge the proposal | Source rejection rule |
| status | "historical_analysis" | Attributed upstream execution/planning label | status string, not measurement |
| sourceIds | ["NT-NEWTON-HERMES","NT-NEWTON-ANALYSIS"] | Upstream citation identifiers | reference IDs |
| tags | ["alchemy","occult"] | Source search/index labels | keywords, not evidence |
| novelty | "Modern methodological reconstruction, not a theorem attributed to Newton or Hermes." | Source novelty statement | unverified attributed assessment |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: source-provided.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## HOST:image-match-null — Does this image beat a matched visual control?
Kind: host-research-protocol. Upstream status: **proposed computational experiment**. Apparatus: **blocked-no-apparatus-declared**.
Source: resonance-lab/docs/research/experiment-protocols.json; SHA-256 c387616f66b02bfd0dd07174bc6e121e39ea1cd1ddb96f61cddd4218729ec883; working-host-source-not-present-at-baseline-HEAD.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "image-match-null" | Stable source identifier | identifier, not a physical unit |
| title | "Does this image beat a matched visual control?" | Source-provided research title | plain-language label |
| status | "proposed computational experiment" | Attributed upstream execution/planning label | status string, not measurement |
| question | "Does one preregistered crop-image representation match a fixed plate-mode family more closely than matched radial and shuffled controls?" | Exact research question | not itself a measured quantity |
| observable | "Held-out normalized image-similarity score, unitless" | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| inputs | ["rights-cleared image","fixed crop/threshold/registration","declared plate model and parameter range","control-generation seed"] | Inputs required by source protocol | Exact input list; no inferred measurements |
| controls | ["blank image","equal-density radial pattern","phase-shuffled image","alternative plate family","nearby candidate frequencies"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| acceptance | "Report all candidates and controls. Calibrate any claimed superiority against the full candidate search; use held-out images for any learned settings." | Source outcome acceptance criterion | Source decision criterion; not automatic legal/scientific approval |
| falsifier | "Control families yield comparable best-match scores or the ranking fails after the frozen registration changes." | Source-declared observation that would challenge the proposal | Source rejection rule |
| limit | "Even a robust match identifies geometric compatibility under a chosen model, not physical excitation, historical intent or alien origin." | Source interpretation and applicability limit | textual scope restriction |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: worksheet-classification.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## HOST:room-sensitivity — How stable is a chamber-mode estimate?
Kind: host-research-protocol. Upstream status: **proposed computational experiment**. Apparatus: **blocked-no-apparatus-declared**.
Source: resonance-lab/docs/research/experiment-protocols.json; SHA-256 c387616f66b02bfd0dd07174bc6e121e39ea1cd1ddb96f61cddd4218729ec883; working-host-source-not-present-at-baseline-HEAD.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "room-sensitivity" | Stable source identifier | identifier, not a physical unit |
| title | "How stable is a chamber-mode estimate?" | Source-provided research title | plain-language label |
| status | "proposed computational experiment" | Attributed upstream execution/planning label | status string, not measurement |
| question | "How much do ideal rectangular-room mode estimates vary under dimension and sound-speed uncertainty?" | Exact research question | not itself a measured quantity |
| observable | "Candidate acoustic mode frequencies in Hz and sensitivity intervals" | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| inputs | ["three internal dimensions in metres","sound-speed assumption in m/s","dimension uncertainty","finite mode-index bounds"] | Inputs required by source protocol | Exact input list; no inferred measurements |
| controls | ["double all dimensions","change sound speed by a stated amount","compare axial, tangential and oblique index classes"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| acceptance | "All modes scale inversely with uniform length scaling and directly with sound speed. Export assumed rigid-boundary conditions." | Source outcome acceptance criterion | Source decision criterion; not automatic legal/scientific approval |
| falsifier | "The implementation fails analytic scaling controls or reports a real-site measurement without recorded data." | Source-declared observation that would challenge the proposal | Source rejection rule |
| limit | "An ideal box is not a calibrated chamber reconstruction; openings, absorption and irregular geometry alter response." | Source interpretation and applicability limit | textual scope restriction |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: worksheet-classification.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## HOST:heritage-impulse-response — Listen through a measured acoustic space
Kind: host-research-protocol. Upstream status: **proposed recording-analysis experiment**. Apparatus: **blocked-no-apparatus-declared**.
Source: resonance-lab/docs/research/experiment-protocols.json; SHA-256 c387616f66b02bfd0dd07174bc6e121e39ea1cd1ddb96f61cddd4218729ec883; working-host-source-not-present-at-baseline-HEAD.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "heritage-impulse-response" | Stable source identifier | identifier, not a physical unit |
| title | "Listen through a measured acoustic space" | Source-provided research title | plain-language label |
| status | "proposed recording-analysis experiment" | Attributed upstream execution/planning label | status string, not measurement |
| question | "Does an authorized room impulse response reproducibly predict held-out recordings at declared positions?" | Exact research question | not itself a measured quantity |
| observable | "Frequency-band decay, early/late energy and prediction error" | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| inputs | ["rights-cleared RIR with acquisition metadata","sample rate","source/receiver positions","background/noise recording","repeat acquisitions"] | Inputs required by source protocol | Exact input list; no inferred measurements |
| controls | ["anechoic or dry reference","repeat at fixed positions","alternate receiver location","signal-level and clipping checks"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| acceptance | "No clipping; sufficient noise separation; repeatability within a predeclared band-dependent tolerance; dry and convolved audio remain separately labeled." | Source outcome acceptance criterion | Source decision criterion; not automatic legal/scientific approval |
| falsifier | "Response is dominated by recording artifacts, source spectrum, or inconsistent positions rather than the declared space." | Source-declared observation that would challenge the proposal | Source rejection rule |
| limit | "No heritage site access, hardware measurement or physical recording was performed in this task." | Source interpretation and applicability limit | textual scope restriction |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: worksheet-classification.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## HOST:mantra-recording — Separate performed pitch from textual meaning
Kind: host-research-protocol. Upstream status: **proposed recording-analysis experiment**. Apparatus: **blocked-no-apparatus-declared**.
Source: resonance-lab/docs/research/experiment-protocols.json; SHA-256 c387616f66b02bfd0dd07174bc6e121e39ea1cd1ddb96f61cddd4218729ec883; working-host-source-not-present-at-baseline-HEAD.
Related dossiers: None declared; no apparatus inferred.

### Exact source fields and meanings

| Source field | Raw value | Meaning | Unit / convention |
|---|---|---|---|
| id | "mantra-recording" | Stable source identifier | identifier, not a physical unit |
| title | "Separate performed pitch from textual meaning" | Source-provided research title | plain-language label |
| status | "proposed recording-analysis experiment" | Attributed upstream execution/planning label | status string, not measurement |
| question | "How do fundamental pitch, formants and spectral envelopes vary across authorized performances of the same syllable?" | Exact research question | not itself a measured quantity |
| observable | "Time-varying fundamental frequency and spectrum; uncertainty and unvoiced regions retained" | Declared quantity/channel and observation map | Source text retained verbatim; unstated units/calibration remain missing |
| inputs | ["consented recording","performer-supplied language and lineage context","declared tonic","microphone/sample-rate metadata"] | Inputs required by source protocol | Exact input list; no inferred measurements |
| controls | ["same performer at another tonic","different vowels at a common tonic","synthetic reference","unvoiced control"] | Declared discriminating/null/sensitivity conditions | protocol conditions; not measured values |
| acceptance | "Separate fundamental and harmonics; retain octave errors/unvoiced uncertainty; do not infer health or universal-frequency effects." | Source outcome acceptance criterion | Source decision criterion; not automatic legal/scientific approval |
| falsifier | "An allegedly fixed pitch changes with the deliberately changed tonic or fundamental tracking disagrees with independent spectrum inspection." | Source-declared observation that would challenge the proposal | Source rejection rule |
| limit | "No new human study or ritual-performance recording was performed in this task." | Source interpretation and applicability limit | textual scope restriction |

### Unresolved disclosure and physical-build gates

- No genuine existing apparatus/drawing relation is declared for this proposal; physical apparatus/drawing completion is blocked.
- No formal claims or full claim-scope support map has been drafted or legally assessed.
- No new physical execution, uncertainty budget, calibration or performance result is supplied by this worksheet.
- Actual chosen components/materials/ratings and a reproducible connection/acquisition contract remain necessary before hardware.

### Required description structure

- **title**: source-provided.
- **technicalField**: worksheet-classification.
- **backgroundAndClosestSource**: attributed-source-context-not-exhaustive-prior-art.
- **problemAndQuestion**: source-question-not-result.
- **summaryOfProposedMethod**: declared-controls-not-executed.
- **briefDescriptionOfDrawings**: blocked-no-drawing-invented.
- **detailedDescription**: source-transcription-with-explicit-gaps-not-enabled-complete-embodiment.
- **workingExamplesAndResults**: not-added; source execution label preserved separately.
- **claimsAndSupport**: requires-human-claim-drafting-and-support-review.
- **abstract**: provisional-question-summary-not-a-verified-patent-abstract.
- **industrialApplicability**: not assessed.
- **requiredBeforePhysicalBuild**: blocking-evidence-gaps.

## Scope exclusions

- NT-H13: Newton’s 2060 date depends on an interpretive chronology — Calendars, chronology and astrological chart validation are outside the user-selected scope.
- NT-H15: Astronomical calculation and astrological prediction need separate validation — Calendars, chronology and astrological chart validation are outside the user-selected scope.

## Source-original and host-overlay policy

New/modified host overlays only; preserved historical originals keep original status.
- shared US/currentEPO rule-informed mechanical preflight
- description/symbol/control/outcome/source identity worksheet
- explicit unresolved enablement/components/calibration and proposed-vs-measured labels
- reviewed source reading depth and no new matter/claimed scope inference

No original was rewritten, no claimed invention was legally assessed and no apparatus was built by this generator. Exact raw records, fields, source paths, statuses and standards requirements are in public/data/patent-protocols.json. Source-file/overlay relations are in public/data/patent-overlays.json.
