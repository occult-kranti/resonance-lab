# Sphere panel, round 1: acoustic force and frequency evidence

Actual role: acoustic/biological-evidence implementation specialist, working as a software agent. No human or historical expert participation is claimed. Applied the `opensync-audio-research` and `resonance-research-advisor` skills. Scope is two deterministic educational calculations, with source receipts and independent controls. No apparatus was built and no biological outcome was simulated.

## Implemented artifact

`src/workbench/sphere-acoustics.ts` exports `acousticLevitation(input)`, `beatingSignal(input)`, their input/result types, equations, limits and a portable parameter-help array. The existing board, renderer, signal engine, transport and prior studies are untouched. There is no autoplay or playback UI.

The levitation model requires acoustic frequency, **peak antinode pressure**, homogeneous particle radius and density, host-fluid density and sound speed. Acoustic contrast must either be explicitly assumed with a written basis or computed from particle compressibility and the density contrast. It is not silently assigned to copper, and Φ here is not the golden ratio. Position defaults to an antinode at x=0 and increases upward; g defaults to 9.80665 m/s².

With p(x,t)=p_peak cos(kx)cos(ωt), the model uses:

- k=2πf/c (rad/m), λ=c/f (m), V=4πa³/3 (m³), κ₀=1/(ρ₀c²) (Pa⁻¹).
- f₀=1−κₚ/κ₀, f₁=2(ρₚ−ρ₀)/(2ρₚ+ρ₀), Φ=f₀/3+f₁/2, all dimensionless.
- E_ac=p_peak²/(4ρ₀c²) (J/m³), F_rad=4πa³kE_acΦ sin(2kx) (N).
- W_eff=(ρₚ−ρ₀)Vg (N), accounting separately for weight and buoyancy.

These follow by differentiating U=V E_ac[f₀ cos²(kx)−(3/2)f₁ sin²(kx)]. Time-averaged p² and fluid-velocity² each contain the sinusoidal factor 1/2; this fixes the peak/RMS factor. The independently simplified test equation is |F|max=πa³k p_peak²|Φ|/(ρ₀c²). Positive Φ attracts toward pressure nodes; negative Φ reverses that direction.

`validity.applicable` requires ka≤0.1 and p_peak/(ρ₀c²)≤0.01. These are deliberately conservative implementation gates, not universal error guarantees. Outside either gate, `forces` is **null** rather than an extrapolation. A hypothetical required support pressure is also withheld if it would exceed the linear-pressure gate, with `thresholdStatus` explaining why. A force/weight ratio is null when effective weight is zero. Model predictions remain conditional on a homogeneous small sphere, ideal stationary 1D field and inviscid/linear assumptions. Streaming, deformation, viscothermal corrections, shell scattering, lateral stability, transducer efficiency and the electrical energy budget are not solved. A force ratio ≥1 is only a necessary ideal 1D balance condition.

In particular, a 44.45 mm radius copper sphere at 40 kHz fails ka by orders of magnitude and receives no force prediction. The volume cancellation in the ideal force/weight ratio does not license scaling a small-particle result to an arbitrary object. Acoustic radiation transfers momentum from an externally supplied field; it is not antigravity or an energy source.

`beatingSignal` synthesizes a **monaural** sum of equal tones at f_c−Δf/2 and f_c+Δf/2. Its signed envelope is cos(πΔft); the magnitude envelope repeats at Δf. Carrier pitch, tone separation and envelope rate have separate metadata. Duration is bounded to 0.05–6 s, allocation to at most 576,000 samples, component frequencies strictly below Nyquist, and sample rate to integral 8–96 kHz. Master amplitude is 10^(−24/20), both ends taper to zero, and returned `metadata` is portable separately from the Float32Array. This is a digital sample-peak ceiling, not measured sound pressure or true-peak calibration. It is not dichotic/binaural stimulation, EEG or a treatment model.

## Sources actually retrieved and read

Exact receipts, canonical/retrieval URLs, XML hashes, passages, reading depth and limits are in `docs/sphere-panel/sources/audio-ledger.json`; raw XML and normalized text sit beside it. XML text extraction loses image-rendered equations in one paper, which is disclosed rather than treated as a transcription. The implementation is an independent standard-equation calculation, not a replication of these authors’ apparatus or data.

1. Argyri et al., **Contact-free magnetic resonance imaging and spectroscopy with acoustic levitation**, Nature Communications (2025), DOI [10.1038/s41467-025-58949-2](https://doi.org/10.1038/s41467-025-58949-2). Read abstract, introduction, apparatus results, discussion and methods. Their specific 40 kHz multi-transducer system levitates 0.5–5 μL droplets for MR studies. The text explicitly discusses deformation, streaming and rotation artifacts. It does not calibrate this ideal force model or establish large-shell or human levitation.
2. Akbarzadeh et al., **Sparse identification of nonlinear dynamics applied to the acoustic levitation of acoustically large objects**, Scientific Reports (2025), DOI [10.1038/s41598-025-24666-5](https://doi.org/10.1038/s41598-025-24666-5). Read abstract, introduction, small-object methodology and experimental setup. The authors distinguish synthetic Gor’kov benchmarks from experimental larger-object identification, explicitly describing small-object limits and amplitude-dependent coefficients. This is evidence against casually extending the small-sphere law; no experimental coefficient or success claim was imported.
3. Ingendoh et al., **Binaural beats to entrain the brain?**, PLOS ONE (2023), DOI [10.1371/journal.pone.0286023](https://doi.org/10.1371/journal.pone.0286023). Read abstract, inclusion/selection criteria, Results overview, Discussion, Limitations and Conclusion. The 14-study systematic review reports inconsistent EEG findings and substantial heterogeneity, precluding pooled effect sizes. Abstract/discussion summarize five supportive, eight contradictory and one mixed; Results uses overlapping supportive/mixed categories. No vote-count probability was manufactured. The review is not an assessment of every music intervention, and its selected healthy-adult evidence cannot establish disease treatment. This was a bounded retrieval, not an exhaustive 2026 review search.

An acoustic beat is a mathematical signal feature. A scalp EEG response, clinical improvement and a mechanism explaining that improvement are distinct empirical questions. The existence of an acoustic pressure force or a numerical beat does not answer them.

## Executed controls and acceptance

Six native tests pass (`audio-tests.txt`); focused ESLint also passes. Checks include independent simplified force and gravity/buoyancy expressions; zero-pressure and density/compressibility-matched fluid nulls; pressure², radius³ and frequency scaling; small-particle threshold reconstruction and out-of-gate threshold withholding; large-sphere/nonlinear-pressure rejection; independent sum-to-product identity and zero-beat sine control; determinism, taper, amplitude ceiling, finite samples, duration and Nyquist rejection. Returned force records and signal metadata serialize as finite JSON.

The first test run exposed that doubling the initial pressure crossed the model’s own linear gate, and that a relative-only comparison at an exact beat null was inappropriate. Scaling comparisons were moved inside the gate, the null uses an absolute numerical tolerance, and the required-pressure result gained its separate domain guard. These failures were not interpreted as physical discoveries.

## Falsifier and next objections

The conditional force model would fail a controlled comparison if, after calibrating field pressure, particle contrast and geometry within its scope, force did not scale as pressure², reverse with the predicted position/contrast sign, or vanish with the matched-contrast/zero-pressure controls beyond declared uncertainty. A real apparatus needs separate field mapping, 3D stability, thermal/streaming, mounting and loss characterization. No casual high-intensity exposure protocol is proposed here.

Round 2 should independently check the peak/RMS factor and sign, require every UI force to be withheld on invalid input, inspect the supplied contrast basis, and check that no returned beat/sample quantity is presented as health evidence. The present gates do not prove viscous or thermal corrections negligible; the next numerical extension should be justified by a concrete scale/uncertainty requirement rather than by adding complexity.
