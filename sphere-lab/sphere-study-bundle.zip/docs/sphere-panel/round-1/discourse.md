# Sphere panel — round 1 skeptical quantum/inverse review

Contemporary agent review using paired-physics, historical-physics-panel/lens guide, and Newton hidden-causes references. This is not participation or endorsement by a historical scientist or human peer review. Selected primary source reading is pinned in `../sources/quantum-source-ledger.json`; network failures are retained in `quantum-retrieval.json`.

## Implemented, exact within the stated model

`teleportQubit({thetaRad,phiRad,visibility})` constructs a pure input qubit on the Bloch sphere, with θ∈[0,π], φ∈[0,2π] radians and an assumed Bell-resource visibility v∈[0,1]. The resource is v|Φ+⟩⟨Φ+|+(1−v)I₄/4: an isotropic Bell resource locally equivalent to the two-qubit Werner singlet family. It is not an inferred state of a copper sphere.

All four Bell branches have probability 1/4, with classical bits explicitly ordered phase-bit/bit-flip-bit and corrections I,Z,X,XZ. The corrected channel is vρ+(1−v)I₂/2. Every pure input has fidelity (1+v)/2, so its uniform-pure-input average has the same value. The 2/3 comparator is specifically deterministic single-copy measure-and-prepare for uniformly distributed unknown pure qubits without shared entanglement. A known input, restricted ensemble or selected detection sample needs its own benchmark; the UI must display this scope beside any advantage claim. The exact threshold v>1/3 is a model comparison, not a statistical significance result.

Before receiving Alice's message, the receiver's unconditioned state is I₂/2 for every input and v. Correlations conditional on a Bell outcome are not an accessible faster-than-light message. The ideal model assumes an available entangled resource and complete Bell measurement. It contains no propagation times, photon losses, detector noise, heralding efficiency, finite sample confidence or physical optical design. No matter is transported.

`membraneScaleAmbiguity` supplies two explicit inverse counterexamples in a declared circular-membrane model f=χc/(2πR). Doubling R at fixed wave speed preserves normalized geometry while halving Hz. Doubling both R and c leaves Hz unchanged with different parameters. An image/sigil alone identifies neither R nor c, material, tension or support. This does not model copper-sphere elastic modes or assign any artifact a frequency.

## Executed controls and acceptance

Seven native tests pass. An independent test implementation forms the three-qubit pure-component mixture, explicitly projects onto each Bell vector, and compares density matrices/probabilities with production's closed form on 64 state/resource combinations. Independent weighted branch sums give I₂/2 for orthogonal and complex inputs. Separate complex matrix multiplication applies each named Pauli correction. Ideal/depolarized endpoints and the 1/3 threshold pass. The wrong-model control omits corrections and fails recovery in three branches for a generic input. Invalid/nonfinite state/resource controls reject. Standalone TypeScript and targeted ESLint pass.

Acceptance gates: preserve the ensemble condition beside 2/3; label all parameters assumed, not measured; show the unconditioned receiver beside conditioned outcomes; never infer entanglement, quantum transfer or a physical artifact frequency from classical waveform/image similarity. Hardware claims require independently calibrated state preparation, resource characterization, Bell detection, classical feed-forward/postprocessing, tomography, losses/success-rate reporting and appropriate non-postselected or explicitly conditioned benchmarks.

## Source and scene objections

The captured Sphere about page explicitly says no measurements/results, no teleportation, and a proposed mechanical carrier mode above230kHz rather than a validated threshold. Its home-page explainer transcript says “frequency shift above230kHz” indicates intrinsic location. Those sentences leave carrier frequency versus measured Δf ambiguous and assert causality beyond a possible residual. A location result must instead survive temperature, geometry/support, calibration, drift, apparatus-position and reference-channel controls. A residual alone would not establish intrinsic location or teleportation.

Reviewed actual `public/sphere-lab/scene-manifest.json` quantum scene metadata: geometry is assumed in metres, quantum hardware/optical path are explicitly unimplemented, and source/crystal/analyzer/detector placeholders disclose missing preparation, heralding, noise calibration and complete Bell analysis. Bob's legend requires the classical result and Pauli correction and excludes superluminal/matter claims. This is acceptable as an educational layout concept, not an executable optical blueprint. Final render images and final scene hashes were not yet inspected by this reviewer at round1 cutoff.

The recent Thomas etal2024 preprint's abstract/introduction/section2/Fig.1 were actually read: polarization photons, entangled resource, Bell measurement, classical correction and fourfold coincidence evaluation are explicit. Its optical-fiber experiment is not reproduced by this educational model. Publisher challenge responses remain unread article attempts. No broad literature completeness or 2026 novelty claim is made.
