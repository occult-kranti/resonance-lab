# Sphere panel round 1 — experimental design and metrology

Reviewed 2026-11-17T06:33:54.920278+00:00. This is one independent AI model-agent task using a Newtonian analysis/synthesis lens, not Newton's participation, a human expert panel or independent empirical replication. Shared model authorship and shared supplied source captures remain correlated. Skills read: resonance-research-advisor plus measurement contracts; historical-physics-panel plus lenses/evidence; newton-analysis-synthesis plus its research reference. PRODUCT.md, DESIGN.md and the OpenSync repository instructions were read. No new historical primary-text retrieval is claimed.

## Accepted bounded question

What does the current Location Spectrum recreation actually compute, and how does that differ from the dated Sphere proposal and registered LOC-1 record? Its ideal sphere frequency is in Hz; A/B positions are dimensionless x/L; its forced displacement response is m/N. These are synthetic results, not observations from an LDV, VNA, reference sphere or calibrated clock.

Three findings drove the implementation:

1. The default thin-shell breathing example is about 23.318 kHz, below the proposed mechanical-mode band above 230 kHz. That does not refute the proposal, identify the project's intended mode, or justify silently changing the breathing-mode equation to reach a target band. A different mode family/specimen needs its own identified model and calibration.
2. The local display uses B-minus-A absolute frequency in Hz. The directly read registered metadata specifies r=f_T/f_R and Delta_ppb=10^9*(mean(r_A)-mean(r_B)): a reference-ratio A-minus-B contrast. Sign, estimator and units differ. The app's normalized positions do not reproduce the registered 0.40 m offset, and its illustrative 12-ABBA-block pilot is not the registered 80 placements, 40 per position, 10 blocks of 8 with default 30-minute settling.
3. Documentation stages differ from measurement stages. Public registration pd3st exists and is not withdrawn; it is a plan, with has_data=false. The public protocol's four-object simultaneous acquisition is still labeled a proposed amendment. Shared frequency reference does not by itself establish aligned sample clocks or verified trigger delays. A candidate residual does not identify an intrinsic location variable, let alone directed motion or teleportation.

## Source receipts and actual reading depth

The initial pass read the three archived public pages below. During round1 the research agent resolved the actual registration; I then directly read its API flags and registered_meta entries 344-2,38,40,47,51,55,58,62,66,71,77,79. The UI's initial “registration not independently read” wording was upgraded accordingly, with a separate inspectable JSON receipt. The attached whitepaper's text was not read by this agent and its contents are not represented as verified here.

| URL | Actual depth | Raw HTML SHA-256 | Extracted-text SHA-256 |
|---|---|---|---|
| https://spheredesci.org/about/ | Full extracted public-page text | `61488b44b54a7c3d34ae70643c4474cd30a3d20969bba1f4730f5f564394c8b9` | `ef7136ef48f55b6aebd7eccca1f3d715da5eaa12b08034e818e45dbb29e0843c` |
| https://spheredesci.org/ | Full extracted public-page text | `2920f2be4a4d36c8398fd59a1d39986f8a9f9c4abd39194aded44abda8be54d0` | `cb86f6f30a40309a3fe18d5fc34eb068dcdc7f10133881506a75fe0e0eb88623` |
| https://spheredesci.org/protocol/ | Full extracted public-page text | `82d39e1d0b6cd8db0d215d9e7a81d1050f5d74802438b17e00a4351f6e618f06` | `138c634d82f7a9520a9f4d358f3a90e544857a93643612ac8b8d9ba2b22bcac2` |

OSF API capture: `https://api.osf.io/v2/nodes/5b6mj/registrations/`, `data[0].id=pd3st`, JSON SHA-256 `f31cf900ac8f710f91ac82769d6a6196538e6b03234c895bea2f7d075c42c08e`. The exact bytes are copied to the recreation's `research/sphere-osf-registration.json` and available through its built app. Verified flags: registration=true, public=true, withdrawn=false, has_data=false; date_registered 2026-10-23T03:12:22.719799. The parent project 5b6mj is not itself the registration; its registered child is pd3st.

The registered_meta passages specify two spheres, stationary reference, 80 placements 40 A/40 B, 10×8 balanced blocks, 0.40 m separation and default 30-minute settling, with blinding, covariance-aware analysis, mixed-effects/block structure and TOST. They refer equivalence bounds to qualification; no numeric smallest effect/ppb equivalence margin was manufactured. Source terms such as “registered” or “has_data=false” describe the archived metadata at capture, not a fresh continuous status check.

## Concrete deliverable

Added a dated Protocol-tab comparison, source HTML/text/JSON SHA receipts, current modeled-mode/band comparison, exact scope differences, controls and a host Sphere handoff. Managed `/apps/…` uses the same origin `/#sphere`; a standalone checkout uses only an explicitly configured validated workbench URL. No published host URL or automatic external fetch was introduced. The new host link and disclosure meet 44px target height, and source hashes wrap at 390px width. Existing dashboard patches were preserved.

No scientific equation or engine was changed. `src/models.mjs` and `src/acquisition.mjs` retain their prior byte hashes. Existing engine research date/model version remains distinct from the newly dated comparison. Code/source hashes at handoff:

- `src/models.mjs`: `2371578a26dba7cdb580940c8cd64b7fa361a3ec2ee2d52581a6fa8fba2445fe`
- `src/acquisition.mjs`: `45af3ac9c2a447ef80328e5f9c2e3b3e4c6f9271c497b5c525618aa4a30f44cd`
- `src/sphere-comparison.mjs`: `650685b105afdc5687f076cd589ed09a3b7f1ef98d958c29e3938c4ac4aaf750`
- `src/sphere-comparison-ui.mjs`: `0a2b583d338aab19f563539b205c2eb28f8909ba85c9b6bcd94ef0a4c8ad4b68`
- `src/app.mjs`: `d39295994581d7d99afc052dad6783ae6ca951381c6f39f98cc41bf5dfdffe63`
- `index.html`: `907e7232d1a07afab17d4741b9d8d9160fc921a9c48c46215c8b363b5bad3386`
- `src/styles.css`: `43c09569f989d45c31ee56f6f7174820d39140571b7888a7b4efba4b07f3a08a`
- `tests/sphere-comparison.test.mjs`: `a8e8029abd4dd5db2ff39f5efa51dca813af03ceb77bc29a61a8bd98f5aea2e0`
- `research/sphere-osf-registration.json`: `f31cf900ac8f710f91ac82769d6a6196538e6b03234c895bea2f7d075c42c08e`

## Executed gates

`npm run check` in `location-spectrum` passes 33 native tests and its actual dependency-free build. Five new tests cover default-model/band separation, strict positive/finite frequency inputs, managed versus explicit standalone navigation, four source receipts and the registered/local contract distinction. Existing independent SciPy fixtures, model invariance, passivity, observation and acquisition controls remain passing.

The final browser receipt is `location-spectrum/research/sphere-round1-browser.json`, with desktop/mobile captures beside it. Six checks cover current frequency, all four source receipts, sign/unit/TOST scope, exact archived registration JSON, managed `/#sphere` handoff, 44px controls and 390px overflow/JS errors. No hardware was accessed; physical measurements remain zero.

## Objections and next-round acceptance proposal

Do not equate a shared reference with perfect drift cancellation: differential temperature coefficients, support history, channel transfer, time offset and correlated noise survive. Same-position lift/replace, sham moves, orientation changes, support swaps, environmental telemetry, raw waveforms and blind frozen analysis are required. An absolute k×u comparison is not a TOST equivalence result. Failure to reject a difference is not evidence of equivalence.

For a selected next round, first freeze the actual registered estimator/sign and a measurement map. A synthetic two-channel ratio tool could distinguish common multiplicative drift from differential drift and verify covariance propagation, block dependence and an explicitly inconclusive outcome. It should export source pins and assumptions; a numeric equivalence margin must come from a stated qualification fixture or user-defined illustrative input, never be presented as an already verified registered value. Do not pre-execute this as round 2 or call a model fit a measurement.
