# Sphere panel round1: primary-source review

Read the resonance-research-advisor and historical-physics-panel skills and their contracts/lenses references. This was a model-agent source review, not a panel of historical people, human reviewers or independent laboratories.

The current first-party pages explicitly report no measurements. Retrieved the HTML whitepaper, actual Zenodo metadata and archived38-page PDF; read selected technical passages, not every page/source. DOI23583932 is a CC BY4.0 working paper v1.0 (2026-10-22), not a peer-reviewed result. Its downloaded SHA matches the registration attachment.

The homepage’s OSF link5b6mj is a project node, not itself a registration. Following its primary registrations relationship verified actual public registration pd3st, registered2026-10-23, not withdrawn. Read registered metadata for design, outcomes, sampling, blinding and analysis. It states no existing data;80placements,10blocks×8,40perposition,0.40m and default30minsettling are declared design choices, not achieved performance. Preserve the proposed four-object variant separately from the registered two-sphere plan.

Downloaded official GUM and read covariance/coverage clauses. Read the linked2025 lithium-niobate resonator paper abstract/introduction from primaryPDF and metadata, not its entire performance case. It is relevant metrology engineering; it does not validate hollow copper, levitation or health claims. Read MITPoynting conservation section and selected Newton/Tesla primary-text passages for method/source-budget context. No invented frequency follows from historical/occult naming.

Compared actual Location Spectrum Lab README and model specification. Its illustrative44.45mm/0.5mm shell is a ~23kHz membrane example with passive fixture and temperature confounds; it is not the >230kHz registered target. No sphere was measured by either local simulation. Full physical isolation, a total frequency signature and unique inverse causal identification are not delivered.

Retained unsuccessful guessed /spherevl/404, corrected from actual links to /vl/. OSF overview yielded an app shell; primary API resolved actual metadata and registration. Visual Lab live HTML was read only; no external interactive simulator audit was performed. Acoustic/clinical and quantum source ownership is separate; exact source handoffs are merged when available.

Artifacts: public/sphere-lab/research.json and docs/sphere-panel/source-ledger.json; captures and retrieval manifests under sources/. Catalogue metadata uses exact status/readDepth. No source dates imply validity; archive custody and preregistration establish provenance and plans, not experimental correctness.

Clinical distinction resolved with actual 2025 dental systematic-review full text: nine qualitative/six quantitative studies; low GRADE certainty and high selection/detection bias. Some anxiety comparisons favor the intervention, while pain versus no intervention is inconclusive with high heterogeneity. This is outcome-specific evidence, not universal healing, nor proof of a unique therapeutic frequency. The 2023 EEG review concerns a different endpoint. A bounded2020–2026 EuropePMC query and unread newer leads are retained explicitly as metadata, not reviewed findings.

Peer handoffs merged with ownership and reading depth preserved: three audio source records (two2025 primary levitation papers;2023 EEG systematic review), and three quantum records (1993 institutional abstract, selected1999 PDF sections, selected2024 fiber preprint sections). Publisher202 response was a challenge, not paper reading; the legitimate arXiv preprint was read instead. No experimental source values were reproduced.

Validation:20 unique source IDs,6comparison records; all source references resolve; all20 capture files exist and match recorded SHA256. JSON parses; no UI/engine file changed by this source task. The collection is a bounded selection, not all literature or a claim of2026 state-of-the-art completeness.
