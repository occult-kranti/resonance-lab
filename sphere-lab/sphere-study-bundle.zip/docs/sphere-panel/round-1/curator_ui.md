# Round 1 — Interface specialist

Implemented the six-study lab in `src/workbench/SphereLab.tsx`, the scoped `sphere-lab.css`, and the opt-in `SphereScene.tsx`. Root owns study definitions, numerical models, routes and generated research assets.

The first viewport identifies this as a teaching lab and gives six named investigations. A selected study keeps apparatus context, declared inputs and the computed result together. Input symbols, units and plain meanings are visible beside fields. Deeper equations, numeric plot samples, assumptions, controls, falsifier, proposed setup and source reading depth remain optional. The native disclosure and button controls retain keyboard behavior. Each study's local input draft survives switching; no browser persistence or agent execution is implied.

Invalid or empty inputs preserve entered state and withhold results/export. Restore reference recovers the study. Parameter JSON records exact inputs, definitions, computed results, model scope and source IDs; it explicitly labels the record as a computation rather than a measurement.

The concept PNG is the initial view. The 3D component imports Three.js, its loader and OrbitControls only after an explicit request, loads one whitelisted local GLB, bounds its byte budget and renders on camera changes. It does not spin or autoplay. Buttons provide orbit, zoom and reset alternatives to pointer gestures. Closing or changing study aborts fetch and disposes the renderer, controls, geometry, materials and textures. The still image remains the fallback. Geometry is labeled assumed, proposed and unbuilt.

Source evidence loads only on the first source-disclosure opening. The UI preserves source status, exact `readDepth`, passage, claim, limitations, hash and safe HTTP(S) link. The research catalogue's registration status, comparison boundary and attribution are displayed without turning a registration into experimental support.

## Evidence

- Read PRODUCT.md and DESIGN.md and applied their Operate mode, ivory/forest palette, serif headings, visible focus and 44px controls. Read Impeccable and Design Partner skills. The Impeccable launcher and its cloud reference files were unavailable; direct project-context and Design Partner accessibility/foundations guidance supplied the fallback. No context files were changed.
- TypeScript project compilation and scoped ESLint passed on the implemented files.
- Actual Vite route at `http://127.0.0.1:4181/#sphere`: all six default models produced metrics and response samples; blank input withheld export; restore recovered; a 240000 Hz draft survived a case switch; downloaded JSON matched that input and the computation-only flag.
- Browser request log confirmed no GLB or research-catalogue request before opt-in. A real GLB opened, reset and closed without a page error. At 390px the page had no horizontal overflow.
- `ui-smoke.json` records those actions. `desktop.png` and `mobile.png` are the initial batched inspection; a repeated scope paragraph found there was removed in the single correction batch. `ui-confirmation.json` and the confirmation captures record source loading, attribution and a keyboard-opened notation disclosure after research assets became available.

## Remaining limits for Round 2

Plot ticks shrink on small screens; the disclosure exposes a readable numeric table. No screen-reader session or broad accessibility certification was performed. Three-dimensional models illustrate the apparatus and do not respond geometrically to model-control changes. This interface is a teaching and protocol workspace; it supplies no actual metrology, clinical, acoustic-capture or quantum-hardware result. Root must preserve the explicit distinction between the local ratio toy and the registered Sphere sign, unit and analysis convention.

No publication or repository push occurred. UI source hashes are recorded in `source-sha256.txt`; generated assets and numerical models have separate ownership and provenance.
