# Sphere panel round 1 — apparatus concepts and mechanism boundaries

Six actual Blender PNGs and GLB scenes were generated in this round. They are **proposed, unbuilt illustrations with assumed geometry**, not physical experiments, manufacturing drawings, patent certification or recovered frequencies. Natural materials, lights, contact shadows and blank displays make components recognizable without fabricating measurements. The companion patent sheets retain their separate role.

## Reproducible artifacts

- Generator: `scripts/render-sphere-studies.py`, SHA256 `8e44ea0ee2a825c8ab40092635dc1cb073354bcb7938db7edcb23b1d269e2887`.
- Output manifest: `public/sphere-lab/scene-manifest.json`, SHA256 `c38024900f887f05da96e492d72629b3fff1de7cca2fbdcef8ade16bf99640fb` at this review freeze. It contains every output SHA256/byte size, 34 logical component records and 447 apparatus-object transforms/dimensions. Every position/extent is in metres; rotations are in radians. Extents describe drawn objects, not toleranced parts or ratings.
- Reproduce: `blender --background --python scripts/render-sphere-studies.py`. Optional `-- --scene <id>`, `--samples 8..256`, `--width 400..1600` are bounded. Default: Blender 4.3.2, Cycles CPU, 800 × 500, 64 samples, fixed seed 17, AgX medium-high contrast, −0.65 stops, no unsupported denoiser.
- Files: `/sphere-lab/scenes/<id>.png` and `.glb`. glTF converts Blender Z-up to standard Y-up. One model unit is one metre. Apparatus only is exported: no giant artistic floor, camera or rendering lights.
- These are original procedural meshes. No stock models, third-party images, paid software copies or downloaded textures were used. Built-in Draco compression was unavailable; no compression was requested, and the resulting uncompressed GLBs validate.

| Scene ID | Logical components | Geometry objects | PNG + GLB bytes |
|---|---:|---:|---:|
| copper-spheres | 5 | 53 | 890191 |
| acoustic-levitation | 5 | 44 | 852699 |
| passive-rlc | 7 | 31 | 1027214 |
| audio-binaural | 5 | 25 | 867643 |
| quantum-teleportation | 7 | 238 | 6090487 |
| pattern-imaging | 5 | 56 | 980768 |

Every scene includes separate legend records (reference, component ID, label and mechanism limitation), component dimensions/positions, camera convention, a complete object geometry list and explicit limitations. Numeric plaques are visual aids; the separate text legend is the accessible identification record. Minor Monte Carlo grain and foreshortened plaques are render limits, not measurement noise.

## Mechanisms and omitted premises

1. **Copper paired-sphere metrology.** Two assumed 100 mm copper spheres, 160 mm centre spacing, 60 mm surface gap, ruler, sensor proxy and blank readout. Gap is geometric subtraction, not a measured coupling, natural frequency, anomalous force or energy effect. Sensor modality, stiffness, uncertainty and calibration are unselected.
2. **Acoustic levitation.** Transducer, reflector, bead target, driver and scale. The 143.5 mm drawn face gap and 8 mm bead are layout assumptions. The bead position is a target marker, not an observed levitation or solved equilibrium. No frequency, acoustic field, particle force balance or intensity is supplied. An external drive is required.
3. **Passive electrical RLC.** Source, coil, capacitor, load and separate probes. Eight drawn turns do not determine L, R, parasitics or ratings. Leads are conceptual, not verified wiring. The explanatory model budget is input work = dissipative output + internal losses + stored-energy change. For a declared series model, E = L i²/2 + q²/(2C) and dE/dt = v i − R i²; the mesh supplies none of those electrical parameter values.
4. **Audio measurement.** Separate headphone channels, analyzer and coupler. No audio is emitted, and no level, carrier, beat, cochlear response, brainwave or physiological result is claimed. The optical/acoustic/voltage channels retain different observables and calibration requirements.
5. **Quantum protocol companion.** Source, optics proxies, Alice analysis, input preparation, detection, Bob receiver and classical electronics. Three ideal qubits, a pre-shared Bell resource, Alice measurement, two classical bits and Bob correction belong to the separate mathematical protocol. This mesh does not implement preparation, a complete Bell analyzer, heralding, timing, noise control or tomography. Yellow paths are visual routing guides; the optical path is not solved. No matter teleportation or superluminal communication is implied.
6. **Pattern imaging.** Camera, scale, two light panels and an original synthetic geometric target. The target is not an authenticated ancient/cultural artifact. Image pixel structure does not identify a physical resonance; any sonification requires an explicitly chosen mapping. Lens distortion, radiometry, scale and camera response remain uncalibrated.

## Evidence and gates

The Tesla mechanism/resonance SKILL.md, its selected research reference and readout-resource reference were read. The modern RLC energy identity follows the selected reference’s reconstruction of energy accounting; no complete historical corpus or new patent-performance audit is claimed. The primary historical lecture lead remains <https://www.gutenberg.org/files/13476/old/13476-h/13476-h.htm>. The prior `scripts/render_device_blender.py` was inspected to retain the distinction between concept geometry and engineering documentation.

Actual checks passed: six scene IDs; all 12 PNG/GLB hashes and byte sizes; PNG headers and 800 × 500 sizes; GLB version/chunk lengths and self-contained buffers; all 34 logical component IDs preserved as GLB extras; matching legend references; finite positive logical extents and finite nonnegative per-object extents. Exported copper POSITION accessor extents independently give 100 mm sphere diameters and exported node translations give 160 mm centres within 1 μm of the assumed geometry. This is a file/geometry check, not metrology.

All six final PNGs were visually inspected. One shared exposure correction improved component contrast; no further style loop was performed. No hardware run, FEM/BEM/optical solver, audible output, participant study or quantum experiment was performed.

Independent critic `/root/discourse` accepted the **quantum manifest semantics**, recorded in `docs/sphere-panel/round-1/discourse.md`. That is metadata review, not independent image inspection or optical build validation. Round 2 should review the integrated selected-scene UI, dimension/legend accessibility, scope labels and GLB lifecycle. Round 3 should test the final compiled artifact after any concrete corrections. This document does not claim those later rounds have occurred.
