# Sphere panel round 3 — final apparatus and document acceptance

Accepted the compiled 0.7 study workspace at `http://127.0.0.1:4192/#sphere` as a source-bound educational/synthetic product with proposed unbuilt apparatus concepts. No blocking apparatus/render/export defect remained. This is the third and final requested review round; no further asset, model or interface change was made in this round.

## Reviewed freeze

- Input build implementation digest: `eded7620177c00de80ab9f99351332ec8f3c3fc747ce77f6b49233b043024535`.
- Public packet manifest SHA256: `09a4f1f46a3d2e1eda10e8beb1e38db2fb4aa7d662636cba56417aecd98d1f29`.
- Renderer SHA256, unchanged since final R2 repair: `5f1e703adac1c9ff1bf4eeedac6a85e99de8067f080b53e2d65d210394fa92f2`.
- Scene manifest SHA256, unchanged since final R2 repair: `029147f34f6ed6b19634e70a2a547ffb9ac9fdc814bee6aeb5c601ed68a94770`.
- Final drawing source SHA256: `4cec2252a15181dc3000c7937bd54fe4888024985083da6861550d8d964da8bb`.
- Final packet exporter SHA256: `2ab576971a197b047c958ab1bfc20a3e1773806aac22d213ebfab7dbbe5a70cc`.
- Offline bundle: 6445627 bytes, SHA256 `bf980890a6140b011959ff9ffc29bdd94dc1933bd85cd6ded19266f5256265c3`.

The R1 and R2 report files remain historical review receipts. The R2 world-envelope repair is present in the final scene manifest, generated dossiers, drawings, PDFs and live served assets.

## Actual compiled checks

All six study selections opened their own apparatus label/meaning dictionary, metre-unit assumption statement and exact renderer source hash in Chromium. No GLB was fetched before explicit opt-in. Opening copper 3D fetched exactly its one GLB; orbit/reset keyboard buttons worked; closing the viewer removed its canvas. Page-error count was zero. At 390 × 844 the opened acoustic legend retained readable text and no document horizontal overflow. Desktop/mobile screenshot receipts are included. This was software WebGL in Chromium, not a performance or hardware certification.

Numeric component centres/extents are preserved in the downloadable dossier and illustrated study PDF, reached through the optional proposed-setup section. The compact on-screen legend provides identities/meanings/assumptions rather than reproducing that full numeric dictionary inline. Every one of the 34 PDF centre/extent tuples was matched against the corrected scene manifest.

The live compiled acoustic assumption explicitly states that the visible concept bead is 8 mm diameter, outside the default 40 kHz small-particle approximation, while the calculation defaults to a 0.2 mm diameter particle. No force prediction is attached to the rendered bead. `devices-bead-boundary.json` records the actual visible statement.

## Export and geometry controls

Live HTTP responses were checked for all six PNGs, six GLBs, 18 PDFs and the ZIP: all 31 responses returned valid content with exact recorded byte counts and SHA256 values. These checks use served bytes, not just source files (`devices-served-assets.json`).

An independent binary GLB parser again decoded all 34 actual component meshes, POSITION buffers and node transforms, converted glTF Y-up to Blender Z-up, and compared the resulting geometry with source world envelopes. Maximum extent discrepancy was 2.53871918e-07 m and centre discrepancy 2.21956372e-07 m, both below the 2 µm **computer-geometry rounding tolerance**, not a physical tolerance. All 447 auxiliary object records remain in the separate geometry inventory. No hardware precision is inferred.

Independent XML projection checks passed all 34 parts and reference mappings across six scenes. The final acoustic setup uses x/z elevation and separates reflector, bead and transducer heights. Other setups use declared x/y envelope plans. Final leader ordering and reference metadata are present; some crossing leaders remain in the multi-part plans and are disclosed as a draft-layout limitation, with every identity repeated in the companion dictionary.

All 18 actual PDFs have A4 page dimensions. Actual vector bounds in the 12 setup/protocol PDFs lie inside the common drawing margins. All six setup PDFs and the acoustic protocol PDF were rasterized and visually inspected: numerals and outlines remain legible, no printed border or fabricated physical annotations appeared, and the acoustic elevation is published. The illustrated acoustic study dictionary was also visually reviewed. All six study PDFs retain assumed centre/envelope values in metres, proposed status, source/measurement limitations and the filing-compliance boundary. These remain draft-format checks, not legal compliance/enablement/novelty acceptance.

## Mechanism acceptance and limits

The passive RLC scene names a real external source boundary and separate load/probes; the dossier counts source work, losses and finite-window storage. There is no simulated radiated electromagnetic field or mesh-derived inductance. Copper displacement metrology is proposed, not measured. The acoustic bead is a target marker. Audio channels are measurement placeholders, not physiological results. Quantum optical blocks are incomplete educational proxies and require classical communication; no transported matter or superluminal signal is suggested. The imaging target is an original synthetic fixture and does not identify a physical frequency from its image.

Remaining physical work includes actual material/geometry surveys, ratings, calibration, full apparatus design, uncertainty propagation and acquired data. Accepted scope is the compiled teaching interface, inspectable source-bound assumptions, reproducible 3D concepts and downloadable draft technical documentation. No physical experiment, field solver, clinical study or legal certification occurred.

Evidence: `devices-browser-checks.json`, `devices-geometry-checks.json`, `devices-projection-checks.json`, `devices-served-assets.json`, `devices-pdf-checks.json`, `devices-pdf-dimensions.json`, `devices-study-pdf-text.json`, `devices-bead-boundary.json` and the actual PDF/browser PNG previews in this round directory.
