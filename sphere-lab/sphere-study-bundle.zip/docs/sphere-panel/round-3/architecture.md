# Sphere panel round 3 — final metrology acceptance

Reviewed 2026-11-17T06:51:37.470789+00:00 from the actual combined 0.7 build identified by input-build.json. This is the third and final adaptive review by an AI model-agent, using an experimental-design lens. It is not Newton's participation, human peer review or a physical experiment. No child source change, fourth round, push or publication occurred.

## Artifact and source identity

Actual compiled route http://127.0.0.1:4192/#sphere and preserved child /apps/brainwave_opensync/location-spectrum/#protocol function. Workspace API reports matching complete built/live digest `eded7620177c00de80ab9f99351332ec8f3c3fc747ce77f6b49233b043024535`, equal to the frozen input. Current public packet manifest SHA matches `09a4f1f46a3d2e1eda10e8beb1e38db2fb4aa7d662636cba56417aecd98d1f29`. All six dossier implementation pins now match actual files, resolving the round 2 regeneration gate:

- `src/workbench/sphere-models.ts`: `91fef14bac21692d6bfd8d3775a19c6e283881f8f403b013a2c7c03814ecf50d` — matches final file.
- `src/workbench/sphere-acoustics.ts`: `561880987217232467212a3d0c3c60b964ace6b11aaa63ed5feee7f52ec12473` — matches final file.
- `src/workbench/sphere-quantum.ts`: `15a1a416362bc53aac4ae2dee9554b78ffa738b1f52a21e81cef53fee446ce4c` — matches final file.
- `src/workbench/sphere-drawings.ts`: `4cec2252a15181dc3000c7937bd54fe4888024985083da6861550d8d964da8bb` — matches final file.
- `src/workbench/patent-drawings.ts`: `6a7eec387096b9a751c82ce40afa31e63fcd71b146ca20691d0e2a64a24df61e` — matches final file.
- `scripts/export-sphere-studies.mjs`: `2ab576971a197b047c958ab1bfc20a3e1773806aac22d213ebfab7dbbe5a70cc` — matches final file.

Preserved child engine/source bytes:

- `src/models.mjs`: `2371578a26dba7cdb580940c8cd64b7fa361a3ec2ee2d52581a6fa8fba2445fe`
- `src/acquisition.mjs`: `45af3ac9c2a447ef80328e5f9c2e3b3e4c6f9271c497b5c525618aa4a30f44cd`
- `src/app.mjs`: `9e96f76d2ea12f603fa0145a3adc5e4a79c3029dfeef8932ffbd4a8caab9fc6a`
- `src/sphere-comparison.mjs`: `4d3da5dc8ecac857495172159de1124aa5808844b759a8ad5c84ccc8ed400470`

The scientific sphere/acquisition engine hashes remain unchanged since before this panel. The child's round 2 independent control receipt remains explicitly dated and pins the source actually executed then; it is not represented as a fresh execution of every later source revision.

## Compiled behavior, actual downloads and offline readability

Four real browser gates passed in 2025ms: downloaded default JSON gives −1ppm and −0.25Hz; common-clock 100 ppm preserves −1ppm; zero temperature mismatch/zero injected term gives exactly zero; final child comparison retains the 1250 ppb counterexample and returns to http://127.0.0.1:4192/#sphere. No JavaScript errors occurred. Receipt: architecture-browser.json.

Actual parameter download `sphere-study-sphere.json`: 7582 bytes; SHA-256 `e06a0a802bcac5c3f8434b31b66f858b3d0caa13dde9535c3e8c379719a1e890`. It retains exact inputs, definitions, model scope and source IDs. Complete implementation pins reside in the companion offline dossier/API receipt; an individual interactive run JSON is not a self-contained engine archive.

Twelve direct HTTP checks passed: dossier/Markdown, setup and field-map SVGs, sphere study/setup PDFs, complete ZIP and preserved child engines/control output. ZIP bytes match the download manifest and contain 59 entries including sphere PDF and source-bound JSON. Details: architecture-validation.json.

Actual sphere study PDF SHA-256 `52b5677d328dbfd6da4c38ce8bf09ccc9ac71f8f5eccefbf991a2dc917451482`. Full extracted text retains the sign/normalization/unit distinction and no-physical-data status. First page was rendered and visually inspected: source boundary, image, setup and equipment text are readable without visible clipping. architecture-pdf.png preserves that bounded inspection; no full accessibility or legal drafting certification is claimed.

## Estimand and metrology verdict

Host D=10^6(r_B/r_A−1) in ppm differs from registered C=10^9(mean(r_A)−mean(r_B)) in ppb. The child retains its separate B-minus-A Hz difference. Independent fixture r_A=1.25,D=−1ppm gives C=+1250ppb; sign reversal and factor 1000 alone would wrongly give +1000ppb. These are synthetic quantities, not measured estimates.

All root inputs retain plain meanings and units. The mode is assumed, not inferred from the illustration. A calibrated mode-temperature slope and matched multiplicative channel-clock error are assumptions; shared hardware alone does not provide covariance or remove differential reference temperature, transfer-function or timing drift. No uncertainty interval, TOST decision, calibrated sensitivity or candidate detection follows from deterministic arithmetic. No numeric equivalence margin was supplied by the registered_meta passages read and none was invented.

Illustrative 0.16 m specimen spacing remains distinct from registered 0.40 m treatment-position spacing. Role assignments and picture dimensions are not measured parts, tolerances or construction qualification. Registration verifies a plan record rather than the hypothesis.

## Independent RLC quadrature

Read-only existing dynamics were checked by independently reconstructing i(t)=I_peak*sin(omega*t), q(t)=−I_peak*cos(omega*t)/omega and source voltage R*i+L*di/dt+q/C. Simpson integration of signed v*i, load*i² and loss*i² used 10000 then 20000 intervals; storage came separately from Li²/2+q²/(2C). This does not reuse the producer's integrated-work formula.

Default, detuned 37 Hz/0.0123 s and zero-source cases pass. Maximum residual is 8.43857e-20J; refinement and analytic-energy comparisons are below 1e−16J. Omitting initial capacitor storage deliberately fails, giving -2.02518e-06J in the detuned case. architecture-energy.json records actual inputs, source SHA and outputs. This validates the finite periodic-state window identity, not startup dynamics, hardware efficiency or energy creation.

## Decision

Accept source-linked educational calculations, explicit observation channels/assumptions, inspectable proposed apparatus and source-bound offline records within their declared models. Reject interpretations as measured location effects, hardware qualification, healing, antigravity, free energy or matter teleportation. Three requested rounds are complete for this reviewer; no further feature or cosmetic work is proposed.
