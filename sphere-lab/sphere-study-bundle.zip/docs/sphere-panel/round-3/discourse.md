# Sphere panel final round 3 — skeptical acceptance

Accepted within the declared teaching-model scope. No blocking correction or additional feature was needed in round3. This review starts from the actual compiled0.7 build at `http://127.0.0.1:4192/#sphere` and the frozen `input-build.json`; it does not re-label the prior source/DOM reviews as compiled acceptance.

## Actual compiled interface and exports

Selected the quantum case, entered the complex state θ=π/2,φ=π/2 and exported results at resource visibility v=1,0,1/3 and0.2. Exported fidelities were1,0.5,2/3 and0.6. All four Bell branch probabilities remained1/4, and the unconditioned receiver matrix stayed I₂/2 for every case. Complex-state branch Bloch coordinates and corrected outputs are retained in the actual downloaded JSON files; those exports explicitly say `computed-model-not-measurement`.

The field now reads “Bell-resource visibility,” which includes its separable v≤1/3 range without calling every resource entangled. The visible disclosure states unknown pure qubits uniformly distributed over the Bloch sphere, deterministic single-copy/no-entanglement measure-and-prepare, and warns that one selected input does not demonstrate an ensemble advantage. Matrix/imaginary-unit definitions, no-message versus conditioned/corrected states, no macroscopic matter teleportation and the classical message remain explicit. The benchmark is an applied known theorem, not a new experimental result or a probability that the selected state is quantum.

Opened the actual selected-scene legend. It displays the missing complete Bell analyzer, absent real preparation/heralding/timing/feed-forward premises, no superluminal channel or matter transport, and fixed assumed geometry. The scene explicitly says that model input changes do not alter the drawn apparatus. No new causal bridge from sigils, sound, copper or historical inspiration to quantum information transfer was found. All six actual concept PNGs and GLB semantics were independently inspected in round2; their unchanged manifest pin is verified here. This is not optical design, entanglement generation or field simulation validation.

## Offline and served artifact consistency

`discourse-offline-checks.json` pins the exact reviewed implementation and artifacts. All four frozen manifest/research/download hashes match the round3 input. All24 declared raw packet files match their byte counts and hashes. All18 PDF files have PDF headers and matching declared sizes/hashes. The59-entry ZIP passes CRC and bundle SHA checks and contains the quantum dossier. Eight selected served files—including the three quantum PDFs—return HTTP200 and match the reviewed public bytes.

For all six study dossiers, the saved default calculations exactly equal a fresh current-model calculation, and every implementation source pin matches its file bytes. The quantum JSON retains the repaired eight-test module SHA `15a1a416362bc53aac4ae2dee9554b78ffa738b1f52a21e81cef53fee446ce4c`. All three quantum source records match the reviewed ledger's hashes, reading depth and actual raw capture bytes.

The quantum study PDF was text-extracted and selected passages read: declared inputs, channel equation, all four branches, pre-message matrix, source reading depth, no-matter boundary, proposed optical prerequisites and drafting limits agree with the JSON/Markdown. Human documents refer to the JSON companion for complete hash/passage/dimension records; this review does not pretend every machine hash is printed in every prose format. Protocol PDFs are numbered field-map drawings to be interpreted with their corresponding dossiers, rather than stand-alone experimental results.

## Executed gates and finite limits

Eight independent native quantum/inverse tests pass again, including explicit three-qubit Bell projection, separate complex Pauli correction, no-message mixture, wrong-correction control, endpoint/benchmark checks and overflow/underflow rejection. Targeted TypeScript and ESLint pass. No product source changed in this round. `discourse-ui.json` contains actual compiled browser checks with zero page errors; per-case exported files preserve exact inputs and tables.

Acceptance is confined to deterministic finite-dimensional algebra, declared inverse-scaling counterexamples, source provenance and the reviewed interface/documents. No hardware measurements, calibration, entanglement witness, photon success rate, detector efficiency, biological outcome, complete state-of-art review, legal filing compliance, publication or deployment was established. The optical-fiber preprint is selected primary evidence read at the recorded depth; the publisher challenge response is not a read paper. The proposed copper-sphere study remains a separate unmeasured metrology question. This is final round3of3; no further panel round or feature is implied.

Provenance granularity: the live parameter export contains exact inputs/results and source IDs. The offline dossier/manifest contains implementation hashes. The live parameter export alone is not a cryptographic build attestation; retain the matching frozen dossier/manifest when archiving it.
