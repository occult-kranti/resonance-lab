# Sphere panel round3 — final source acceptance

Accepted the bounded source and science-editing scope of the actual compiled0.7 build at `http://127.0.0.1:4192/#sphere`, starting from `input-build.json`. This closes this agent’s third requested review. It does not describe historical people or humans as participants, certify an experiment, or expand the literature corpus.

## Actual final checks

- Retrieved the served research catalogue: exact byte match to the frozen local20-source JSON and expected SHA256. All20 retained raw captures still match their recorded hashes. Source IDs are unique and all six study/dossier source mappings resolve.
- Retrieved all six served JSON dossiers. Their source records exactly equal the latest catalogue records, including `passageKind`, publication/version/DOI metadata, passage wording, reading depth, limitations and source SHA. Their reviewed date and source mappings agree. All24 files listed by the packet manifest match their hashes.
- Confirmed all18 PDF hashes and the bundle hash against the download manifest. Opened the actual ZIP and checked that its research catalogue and six complete dossier JSON files exactly match the current files. Extracted and inspected the text of all six study PDFs: bounded-source, draft and scientific-limit language is retained. This is content/hash inspection, not a complete print-layout audit.
- In actual Chromium on4192, opened source disclosures for all six studies. The sphere study shows three exact-excerpt blockquotes and two labeled research notes; acoustics two excerpts; EM two notes; audio two excerpts; quantum three notes and zero blockquotes; pattern one excerpt and two notes. Actual compiled help uses the repaired assumed-calibration-slope wording. `research-browser.json` records these counts.

## Scientific boundaries accepted

Actual registration `pd3st` remains independently verified as a public, nonwithdrawn study plan, not measurement evidence. Its reference ratio, A-minus-B ppb contrast, covariance/block/TOST treatment and qualification-dependent equivalence margins remain distinct from the local first-order B/A ppm teaching model. The selected250kHz input is assumed; drawn geometry does not derive that mode. A common multiplicative drift cancellation in the toy does not demonstrate environmental control in hardware.

The clinical display and packets retain endpoint distinctions: inconsistent EEG entrainment in a selected2023 review; low-certainty2025 dental pain/anxiety evidence with some favorable anxiety comparisons, high risk of bias and inconclusive pain versus no intervention. This neither declares every intervention ineffective nor supports universal healing or a special curative pitch. Monaural waveform arithmetic is a separate observable.

The selected2025 levitation studies do not validate a large copper shell through a small-particle force law. The selected2024 optical quantum preprint and foundational protocol papers do not turn a deterministic ideal channel into an optical apparatus or transport matter. The passive electrical model retains source/storage/loss accounting; historical patent custody is not performance proof. Images and historical/occult motifs do not determine a unique physical frequency.

The20-source collection remains a bounded, dated selection with exact reading depths. Unread2026 search leads are explicitly leads. No exhaustive state-of-the-art, novelty, scientific breakthrough or human-peer-review claim is inferred. First-party Sphere text and working-paper attribution remain CC BY4.0; other source terms remain separate.

US/EPO statements are appropriately qualified: drawing/profile checks do not certify filing compliance, enablement, patentability, manufacturing readiness or physical validity. Checked those qualifications in current exported content; this is not an independent legal review of the standards. One suspected identical-PDF issue was investigated: actual `sphere-protocol.pdf` renders a nonblank generic601–605 field map, intentionally shared across studies with specific companion dictionaries. Identical outlined-map bytes are not evidence of lost scientific content; no repair was required.

## Remaining gap and stop

Accept the source/provenance and wording corrections. No blocking source defect remains. The future work is measurement: characterized specimens and identified modes, calibrated sensors/pressure/timebase and uncertainty, independent artifact controls, any outcome-specific approved clinical protocol, and characterized quantum hardware where applicable. None is supplied by the current simulations, pictures, reference counts or source archive.

No source corpus, UI, numerical model or publication changed during this final review. Evidence is `research-qa.json`, `research-browser.json` and the input-build freeze. Final reviewed hashes:

- `public/sphere-lab/research.json`: `118c1a091002e961bc81f44701e13878d7ea7e930b12c824b0cd0391ebfe5658`
- `docs/sphere-panel/source-ledger.json`: `24927777a14aa755fc54a2c6ce386e7ccbf6b43292e6cec9c4b820467158683d`
- `public/sphere-lab/manifest.json`: `09a4f1f46a3d2e1eda10e8beb1e38db2fb4aa7d662636cba56417aecd98d1f29`
- `public/sphere-lab/downloads.json`: `7b41ddce55da1d2ef5b9a5779bfac44b5569539cf07b547fac4a218adc207657`
- `public/sphere-lab/sphere-study-bundle.zip`: `bf980890a6140b011959ff9ffc29bdd94dc1933bd85cd6ded19266f5256265c3`
- `src/workbench/SphereLab.tsx`: `ea1a308a78a3cf7ca569b5b1fa3b5864c8390dfa45031f0bad50f75544c9504a`
- `src/workbench/sphere-models.ts`: `91fef14bac21692d6bfd8d3775a19c6e283881f8f403b013a2c7c03814ecf50d`
