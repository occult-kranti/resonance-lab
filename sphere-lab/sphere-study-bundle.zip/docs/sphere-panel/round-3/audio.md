# Sphere panel round 3: acoustic and biological-evidence acceptance

Final bounded acceptance against `round-3/input-build.json` and the compiled 0.7 application served at `http://127.0.0.1:4192/#sphere`. This is round three of three. No new feature or acoustic production-code change was made in this round.

## Verified result

Seven acoustic native tests were actually rerun and passed (`audio-tests.txt`), and focused ESLint passed. The independent potential-gradient, force/work quadrature, signed-contrast, pressure²/radius³/frequency, null, invalid-domain, beat-identity and allocation controls remain passing.

Fetched the **served** acoustic and audio dossiers as JSON and compared their default calculations with the current executable wrapper. Both agree exactly after normal JSON normalization of signed zero (JSON represents −0 as 0). All six implementation hashes in each dossier match current source bytes. The acoustic module remains SHA-256 `561880987217232467212a3d0c3c60b964ace6b11aaa63ed5feee7f52ec12473`; final wrapper is `91fef14bac21692d6bfd8d3775a19c6e283881f8f403b013a2c7c03814ecf50d`.

Fourteen served artifact files—JSON, Markdown, study/setup/protocol PDFs, and setup/protocol SVGs for both studies—returned HTTP 200 and matched current public bytes exactly. `audio-portable.json` records each served SHA-256 and the successful model/source-pin checks. PDF headers were verified; both study PDFs were text-extracted and read at the relevant parameter, equation, assumptions and source passages. This review does not certify typography, every rendered PDF page or filing compliance.

The regenerated audio dossier/PDF retains all 2000 samples, the −24 dBFS sample-peak convention, division of the equal-tone sum by two, and the exact linear taper `min(1,i/T,(N−1−i)/T)` with N=2000 and T=160. Both endpoints are zero. At the adversarial 1000 Hz carrier / zero separation, the wrapper preserves the ≈0.0630957 underlying sample peak. The round-two zero-crossing alias defect is repaired, not hidden by a different label. Neither dB SPL, reconstructed true peak, EEG nor clinical improvement is inferred from these digital amplitudes.

The acoustic JSON/Markdown/PDF retains peak antinode pressure, explicit medium density and sound speed, assumed material contrast and the conservative small-particle/linear-field restrictions. Its generated 8 mm concept bead is expressly separated from the default 0.2 mm calculation particle. The actual scene component is an 0.008 m target marker and explicitly claims no observed levitation or force balance. The acoustic setup SVG is an assumed **x/z front elevation** and the audio setup is an assumed **x/y top plan**; their reference records explain components rather than asserting working hardware. The protocol SVGs identify documentation concept maps, not hardware or execution order.

## Actual compiled UI checks

Executed desktop (1440×1000) and mobile (390×844) browser probes; both passed with no page errors or horizontal overflow (`audio-browser.json`):

- 5000 Pa pressure: linear-field warning appears, force metrics disappear and no force-response samples are shown.
- 3 mm radius: Rayleigh warning appears and force metrics disappear.
- Restore 0.1 mm radius and choose contrast zero: the null is accepted and returns zero radiation force.
- The assumptions disclose the 8 mm rendered bead / 0.2 mm default-model distinction.
- The high-carrier audio response contains 2000 points with a nonflat plotted range.
- Both selected audio source records load, including the visibly **low-certainty clinical evidence** classification.

The dental review remains a source-qualified clinical comparison, not a generated outcome or proof of EEG entrainment. Its GRADE/risk-of-bias limits and the distinct 2023 EEG review scope survive into served JSON, Markdown and PDF. No new claim of a complete literature review or trial reanalysis is made.

## Accepted scope and physical unknowns

Accepted as deterministic, source-bound educational calculations with explicit withheld domains and a repaired display. No physical levitator, pressure calibration, material scattering measurement, three-dimensional stable trap, manufacturing plan, participant experiment or clinical efficacy result has been established.

Unresolved physical work is specific: actual field mapping, particle compressibility/density, viscous and thermal scales, streaming, deformation/shell scattering, lateral stability, transducer efficiency and full energy/loss accounting. The necessary ideal force/weight comparison cannot supply those quantities. A calibrated within-domain experiment that fails the predicted pressure² scaling, contrast sign or drive-off/matched-contrast null beyond uncertainty would reject this approximation for that apparatus. Final acceptance does not resolve these unknowns by analogy to an image, monument, frequency or healing claim.

This completes the assigned third round; no further panel round is implied.
