# Sphere panel round 2 — actual geometry and drafting review

R1 report remains unchanged. This review found and repaired an actual source-metadata defect; it does not claim a hardware experiment or legal drawing acceptance.

## Findings and corrections

1. **Curves and rotated components had incorrect logical envelopes.** The R1 coil/headband stored the Blender object origin at zero rather than the visible curve centre. Rotated headphone cups/probes retained local extents. Logical components now derive centres and extents from actual evaluated mesh vertices in world coordinates. An intermediate attempt using Curve.bound_box was rejected by independent GLB decoding because Blender inflated its envelope by the unit control radius. The final implementation uses the evaluated mesh and was tested against the exported asset. No apparatus geometry or PNG composition was changed.
2. **Acoustic plan collapsed three distinct heights.** The original root draft placed transducer, reflector and bead leader endpoints at one x/y coordinate; `acoustic-plan-before.png` records the actual issue. Root changed this scene to x/z front elevation. The independent XML projection check accepts the revised source function and distinct heights. A final regenerated packet/compiled UI is deferred to R3.
3. **Legend accessibility must exist in the interface.** Numeric plaques are insufficient without their separate meaning dictionary. This was sent to the UI owner; curator reports an optional label/assumption disclosure now exists. This agent does not claim visual/keyboard acceptance of that new interface from metadata alone. Component dimensions remain explicitly assumed and available in the manifest and dossier.

## Actual artifact pins and independent checks

- Renderer SHA256: `5f1e703adac1c9ff1bf4eeedac6a85e99de8067f080b53e2d65d210394fa92f2`.
- Scene manifest SHA256: `029147f34f6ed6b19634e70a2a547ffb9ac9fdc814bee6aeb5c601ed68a94770`.
- Reviewed revised drawing module SHA256: `68152cb76761b7880d0822acdf51f1af75e7337d9996ccd6f0d148903281412e`.
- Exporter SHA256 at review: `2ab576971a197b047c958ab1bfc20a3e1773806aac22d213ebfab7dbbe5a70cc`.
- All 12 current output hashes/byte counts passed. Six PNGs were visually reviewed for component arrangements and blank displays; source-only metadata repair leaves those arrangements unchanged.
- Independent GLB binary decoder read actual POSITION buffers and node matrices/quaternions, transformed glTF Y-up back to Blender Z-up, and compared all 34 component meshes against the declared envelopes. Maximum outward extent discrepancy: 2.53871918e-07 m; maximum centre discrepancy: 2.21956372e-07 m. Both are below 2 µm numerical tolerance. These numbers compare computer geometry; they are not measured hardware tolerances.
- Full auxiliary inventory contains 447 objects with raw transforms/dimensions plus explicit world envelopes. It includes mounting fixtures, leads, synthetic patterns and markers. The large artistic floor, cameras and lights are excluded from exported GLB apparatus.
- Independent XML parsing checked all 34 rendered envelope centres/widths/heights and reference-to-component mappings across the six scenes, using metres-to-paper-mm scaling and the appropriate vertical axis. Acoustic now uses z; the others use y. Minimum outlined reference ink height is 3.469851517 mm. Sheet bounds, A4 dimensions and no-FIG single-view convention are mechanical profile checks only.

`devices-geometry-checks.json` and `devices-projection-checks.json` retain per-part/per-scene results. The root exporter must regenerate dossiers/setup files after the final corrected scene freeze. Old dossier positions should not be interpreted as current geometry until regenerated.

## Mechanism and compliance scope

The RLC dossier explicitly names an external source, useful load, losses and finite-window stored energy. Its signed work budget is consistent with the Tesla research reference’s modern passive-circuit reconstruction; no free-energy interpretation, radiated electromagnetic field, or inductance derived from mesh geometry is asserted. Acoustic drive, optical preparation/detection and calibrated measurement resources remain missing physical premises. The quantum apparatus is an educational proxy, not a complete optical implementation; the ideal protocol cannot transport matter or send the input without the classical message.

The draft’s limitations explicitly reject filing compliance, enablement, patentability and physical validation. Current US 37 CFR 1.84 and EPO OJ2025A49 are linked as source requirements; historical deleted EPO Rule46 is not promoted as current. A4 black-line appearance and numerical formatting checks do not establish a complete drawing set. R3 should verify final regenerated packet pins, selected-scene legend/units, acoustic elevation and actual GLB disposal/loading behavior against the compiled product.
