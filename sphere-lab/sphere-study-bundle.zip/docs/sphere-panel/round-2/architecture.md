# Sphere panel round 2 — reverse reconstruction and metrology

Reviewed 2026-11-17T06:41:13.293166+00:00. Independent AI model-agent task, not Newton's participation, human peer review or physical replication. This is the second adaptive round following the actual round 1 freeze, other five reports, revised root `sphere-models.ts`, CONTRACT.md and the generated sphere JSON/Markdown dossier and A4 setup projection. No new historical or paper reading is claimed in this round.

## Actual incoming artifacts and changed question

Round1 established the registration/source status and separated the Location Spectrum recreation's B-minus-A Hz output from the registered estimator. The root host now defines a different teaching quantity, D=10^6(r_B/r_A−1) in ppm. This round asks whether its mapping, clock cancellation and reverse inference are justified, and whether public setup notes preserve the missing premises. The root study source actually executed by this independent check has SHA-256 `9515254ba39198de1235dce685f8d278acfa844f1d76c821692ff494deb1da20`.

## Independent calculation and wrong-model controls

Executed `python3 reference/sphere-ratio-controls.py` in Location Spectrum. It reconstructs both contrasts from four raw frequency estimates using 60-digit Python Decimal arithmetic, rather than copying the producer's alpha×temperature-plus-injection implementation. The actual output is retained in `research/sphere-ratio-controls.json`.

| Declared synthetic case | Host relative B/A quantity | Registered A−B ratio contrast | Conclusion |
|---|---:|---:|---|
| f_TA=250000Hz, f_RA=200000Hz, f_TB=249999.75Hz, f_RB=200000Hz | −1ppm | +1250ppb | r_A=1.25; baseline ratio matters |
| Same fixture, common test/reference factor+15ppm atA and−30ppm atB | −1ppm | +1250ppb | Matched multiplicative factors cancel even when they vary with position/time |
| No mechanical change; only test-channelB clock factor+1ppm | +1ppm | −1250ppb | A channel mismatch creates an apparent signal under the true mechanical null |

The tempting conversion −1000×D predicts+1000ppb for the first case and fails. Exact algebra is C_ppb=−1000*r_A*D_ppm. This is an estimand/sign/normalization difference, not a numerical bug in either deliberately different teaching definition. The producer's default −1ppm and−0.25Hz frequency equivalent match the independent fixture; changing its declared common clock between −100 and +100ppm leaves the output unchanged, and injecting +1ppm cancels its default thermal −1ppm. Those outputs were actually executed and recorded.

The root producer algebraically eliminates its common-clock parameter instead of simulating two clocks and a measurement chain. That is acceptable within its declared exact common-factor assumption, but not evidence that real shared instruments cancel all drift. Differential channel timing, readout transfer, reference temperature and covariance are absent. The wrong-clock control makes that missing premise operational. No uncertainty interval, power, TOST decision or detection claim follows from the deterministic arithmetic.

## Model, documentation and setup critique

All five root inputs retain symbol, plain meaning and unit. f0 is an assumed selected mode, not derived from the fixed illustrative sphere. alpha in ppm/K must be calibrated for the selected mode; deltaK is differential temperature; epsilon is synthetic; c is a matched fractional clock error. A reference without differential temperature is an explicit restriction. The numeric equivalence margin remains unprovided by the registered_meta passages read; no local k-times-u value was promoted into a registered TOST margin.

The public sphere dossier exposes source reading depth and SHA receipts, reference dictionaries, every input and a proposed setup from scratch. Equipment entries are categories and selection criteria, not quotes, checked stock, guaranteed bandwidth or a complete safe bill of materials. The A4 sheet is a checked common-profile illustration, not physical measurement, legal certification or manufacturing detail.

A semantic concern was reported to root: labeling two objects “sphereA/B” can blur object identity with treatment positionsA/B. Root added a concrete assumption distinguishing the illustrative 0.16 m specimen spacing from registered 0.40 m treatment separation and requiring test/reference roles to be assigned separately. This correction is accepted as a clear scope limit without fabricating apparatus geometry.

At the report checkpoint, the generated public dossier still carries the preceding candidate's source hashes for `src/workbench/sphere-models.ts, src/workbench/sphere-quantum.ts, src/workbench/sphere-drawings.ts`. The root was notified. This is expected during active source revision, but the dossier must be regenerated before round 2 freeze and all implementation pins must match the final executed artifact before round 3 acceptance. Stale public exports are not accepted as new-source verification.

## Child implementation and executed checks

The Location Spectrum comparison now links the independent arithmetic receipt, explains the baseline-ratio/sign/scale trap and common-clock premise, and rereads an explicit standalone workbench preference when the Protocol tab is reopened. No new preference key, automatic external request, published host address or scientific-engine change was introduced. Its existing B-minus-A Hz label is preserved.

`npm run check` passes 33 native tests and the actual build. The final independent JSON was then included in a refreshed build. Three real browser gates pass: managed UI exposes the counterexample and receipt; standalone initially assumes no host, then resolves a user-set URL on reopening Protocol; a malicious javascript preference produces no active host link. `research/sphere-round2-browser.json` records the actual checks. Existing scientific-engine byte hashes remain unchanged.

Changed/source-bound artifacts at handoff:

- `reference/sphere-ratio-controls.py`: `36ed52e486dc93a7bd93e7359427cec8a3adca86628cba154022b5d70efb9e88`
- `research/sphere-ratio-controls.json`: `1e09eb35705783ae10e4f60637935009954c42964015e27d6ebf187849cc7363`
- `src/sphere-comparison.mjs`: `4d3da5dc8ecac857495172159de1124aa5808844b759a8ad5c84ccc8ed400470`
- `src/sphere-comparison-ui.mjs`: `d39dd609e83c5fea929d78838cd52287d70f778de86439b566758a1eea052628`
- `src/app.mjs`: `9e96f76d2ea12f603fa0145a3adc5e4a79c3029dfeef8932ffbd4a8caab9fc6a`
- `src/models.mjs`: `2371578a26dba7cdb580940c8cd64b7fa361a3ec2ee2d52581a6fa8fba2445fe`
- `src/acquisition.mjs`: `45af3ac9c2a447ef80328e5f9c2e3b3e4c6f9271c497b5c525618aa4a30f44cd`
- `research/sphere-round2-browser.json`: `f57b4a6e4b77a167b91abd384bc383a0eb574d332389ce662f13f881cd100179`

## Round 3 acceptance decision

Accept the root sphere arithmetic within its explicitly conditional first-order teaching scope. No numerical root repair is required by this review. Require the regenerated dossier/setup/export pins to match the final source, with current role/spacing and ratio-estimand disclosures retained. Round3 should independently check the compiled default+null/clock outputs, the unknown-margin/inconclusive boundary, exact downloadable receipt bytes, and managed/explicit-standalone host navigation. Neither a source registration nor the synthetic residual qualifies as a measured location effect. Do not expand this into a new covariance/inference engine without a frozen observation model and numerical uncertainty contract.
