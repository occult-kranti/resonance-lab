# Sphere panel round 2 — source and science-editing review

Reviewed the actual round1 freeze, all five other specialist reports, current SphereLab and sphere-models, all six exported study dossiers, and the20-source catalogue against retained captures. This is an independent model-agent review with shared underlying model authorship, not human peer review or an empirical replication. No new physical experiment, clinical experiment or literature-completeness claim is made.

## Decisive corrections

1. **Research notes were displayed as quotations.** The UI put every `passage` in a blockquote, but all three quantum entries, historical method summaries and metadata notes were paraphrases or interpretations. Added explicit `passageKind` to every record: nine `verbatim-excerpt` entries verified as contiguous words against retained extracted text, with whitespace normalization declared; eleven `research-note` entries. Removed ambiguous decorative quotation marks from notes. Sent the interface owner the exact contract so notes render as labeled prose. Nine text-capture hashes are preserved in `research-qa.json`. A downloaded document is still not described as fully read.

2. **Registered estimator and teaching ratio differ.** Directly reread actual `pd3st` registered metadata344-66/71/77/79: `r=f_T/f_R`, `Delta_ppb=10^9*(mean(r_A)-mean(r_B))`, covariance, mixed effects/block dependence and TOST; numeric equivalence bounds are established during qualification, not supplied here. The root toy uses `D_ppm=10^6*(r_B/r_A-1)`, with the first-order synthetic temperature/injection model. An explicit witness `r_A=1,r_B=1.000001` gives approximately +1ppm in the toy and−1000ppb in the registered contrast. For a single exact pair the relation is `Delta_ppb=−1000*r_A*D_ppm`; normalization as well as sign and units differ. Group means and registered covariance/TOST are further differences. Current scope discloses this correctly. Actual module runs produced the declared −1ppm thermal default, +1ppm injection, and unchanged result under common±100ppm drift. This only checks the deterministic toy, not attainable cancellation in hardware. Asked root to replace the equation-help phrase “measured slope” with “assumed calibration slope; must be measured for actual mode,” matching the honest input/assumption text.

3. **Endpoint and bibliography boundaries remain explicit.** The 2023 review concerns heterogeneous EEG entrainment in selected healthy adults. The2025 dental review concerns pain/anxiety, reports some favorable anxiety comparisons, but lowGRADE certainty/high selection/detection bias and inconclusive pain versus no intervention. Neither outcome is a universal healing frequency or validates monaural arithmetic as dichotic stimulation. The2025 levitation sources concern externally driven small droplets or data-driven large-object dynamics; neither validates large copper shell lift through the Rayleigh law. Quantum2024 source results are source-reported selected preprint material, not a replicated optical system. Source selection is bounded; unread2026 metadata leads are not a latest-literature review.

## Bibliographic and provenance checks

All20 retained source files exist and match the catalogue SHA256. All source IDs are unique; six comparison records resolve. Registry source IDs, six dossier `study.sourceIds` and embedded source-record IDs agree. Dossiers retain `proposed-setup-with-synthetic-computation` status. No reviewed setup claims built hardware, healing, hidden physical-frequency recovery, unsupported energy gain or new physics.

Added typed publication/version/DOI fields where primary metadata was actually checked. Re-read Newton transcription header: Second Edition, London1718; online transcription date is separate. Checked XML publication dates/DOIs for all four acoustic/clinical papers. Resolved one apparent quantum-date conflict using exact-DOI Crossref: publisher-deposited publication fields are20December2024;28October2024 is record creation and appears as OpenAlex publication_date. The repository v4 date is26October2024. Exact metadata and receipt are retained under `sources/bibliographic-quantum-crossref*`; this does not extend publisher full-text reading beyond the disclosed202 challenge.

## Acceptance and final gates

Accept the current bounded source corpus and scientific scope. Before round3 final acceptance, require the revised UI to distinguish excerpts from research notes, regenerated offline dossiers to preserve those classifications, the assumed-slope wording repair, and final source/catalogue/registry hashes to agree. Preserve the registered-vs-toy sign/normalization distinction in UI and exports, the finite clinical/quantum scope, and the original20-source reading-depth declarations. No further literature expansion is necessary for these concrete corrections.

Evidence: `research-qa.json` and `research-actual-module.json`. Reviewed file hashes at this checkpoint:

- `public/sphere-lab/research.json`: `118c1a091002e961bc81f44701e13878d7ea7e930b12c824b0cd0391ebfe5658`
- `docs/sphere-panel/source-ledger.json`: `24927777a14aa755fc54a2c6ce386e7ccbf6b43292e6cec9c4b820467158683d`
- `src/workbench/SphereLab.tsx`: `25772dc1e2a447c7600fd0586784903ebb171cf541d81f6ba435bcfc88a4f410`
- `src/workbench/sphere-models.ts`: `fe1f74075d1b3a3a9a3de8ea32315bf8f9e2a11aecec9557c6d99302ddb9bc5a`
- `public/sphere-lab/dossiers/sphere.json`: `963d81291d7fe2392b045c85fb71dba1f6575919e534249b66e271416f44bc78`

Checkpoint confirmation after the coordinated fixes: current SphereLab uses `passageKind` to render only verbatim excerpts in blockquotes and research notes as explicitly labeled paraphrase paragraphs. Current sphere equation help now calls alpha an assumed calibration slope that must be measured for the actual mode. These are source/code inspections; the interface owner/root performs compiled-browser confirmation. Offline dossier regeneration remains a final gate for the revised source metadata.
