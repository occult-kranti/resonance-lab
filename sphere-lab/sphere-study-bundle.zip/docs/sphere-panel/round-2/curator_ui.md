# Round 2 — Interface specialist

Reviewed the actual first-round surface and implemented the agreed corrections in SphereLab, SphereScene and their scoped CSS. The page now has its own H1. The main apparatus link opens the generated setup drawing; a separately named link opens the documentation field map. Geometry labels, limits and source identity are available beside the selected scene, and the caption states that the illustration remains fixed when model inputs change.

Quantum results now expose the root model's actual four-branch and pre-message density-matrix tables through an optional disclosure. The nearby explanation defines Bell measurement, branch probability, two classical bits, Pauli X/Z/XZ, density matrix, identity and the imaginary unit. It distinguishes the pre-message I/2 average from conditioned/corrected branches and states the exact comparator scope: unknown pure qubits uniformly distributed, deterministic one-copy, no-entanglement measure-and-prepare strategies. A selected-state example is not treated as ensemble evidence.

Source records use the research catalogue's `passageKind`. Only an explicitly marked verbatim excerpt is displayed as a quotation. Other passages are labeled research-note paraphrases. Source IDs are displayed; an unresolved relation produces an explicit notice rather than silent reassignment. Panel records load only on request, describe software-agent provenance, and display frozen complete versus pending rounds without implying a new execution or human peer review.

The 3D loader's 20 MB rule is an accepted asset-size cap. A supplied Content-Length above that cap is rejected before buffering; the actual buffer is checked afterward. This is not a strict bound on browser peak allocation. All six current GLBs are self-contained and below the cap, as independently checked by the architecture specialist.

## Executed evidence

- TypeScript project compilation and scoped ESLint pass.
- `ui-smoke.json` records an actual Vite browser run at port 4181. This is source-mode runtime evidence; root separately builds and freezes the combined production artifact.
- All six selected PNGs decoded; all six GLBs opened, reset using Enter, and closed. Every setup-drawing and field-map link resolved. An intercepted 503 GLB response displayed the still-image fallback and actionable status.
- A radius outside the acoustic approximation removed force metrics and the force curve. Restoring reference recovered the model. Quantum branch/matrix rows and the exact comparator explanation were present. Research notes and the optional panel record rendered. Optional catalogue/panel/GLB resources were absent before opening them.
- Desktop and 390px mobile screenshots were captured together and inspected. No page errors or whole-page horizontal overflow occurred. The initial test harness incorrectly passed a relative link to Playwright's request API; converting it to an absolute URL corrected the harness without a product change.

The final source hashes are in `source-sha256.txt`. No screen-reader session was performed. Mobile plot ticks remain small, with a native numeric-table alternative. No measurements, clinical effects, physical quantum channel, metrology replication or executed apparatus are claimed. No publication or push occurred. Ready for the third round's combined-artifact acceptance.
