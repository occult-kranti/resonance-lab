# Sphere panel round 2: wrapper and evidence audit

Reviewed the actual six-report round-one freeze (`round-1/freeze.json`) and the current model wrapper, acoustic/audio dossiers, component-plan generator and source records. This is the second adaptive round, not a claim that later acceptance has already occurred. Owned implementation scope remains the acoustic module/tests; wrapper changes belong to root.

## Actual findings and corrections

The initial wrapper’s acoustic contrast slider started at 0.01, preventing its zero-contrast force null from being exercised. Root was notified and changed the lower bound to zero. The executed wrapper probe then confirmed this null, with a finite zero-force curve. Positive-only contrast is an explicit wrapper restriction: a future negative-contrast control must preserve the force sign rather than building a signed curve from the absolute maximum.

The audio wrapper originally stated only that the renderer scaled and tapered the waveform. Root was asked to preserve exact digital gain and taper conventions in portable results. Its revised assumptions now declare −24 dBFS, gain 10^(−24/20), sample-peak versus true-peak/SPL limits, and no playback. The synthesis uses a linear 20 ms endpoint taper, additionally bounded by one quarter of the sample count; no physiological noise or health outcome is generated.

A concrete **plot aliasing defect** was then identified in the actual wrapper: it retained every fourth sample from 8000 samples/s, producing an effective plotted rate of 2000 samples/s, while the allowed component range extends to 1020 Hz. At carrier=1000 Hz and separation=0, every retained sample falls near a sine zero. Executed result: 500-point plot peak ≈2.096×10⁻¹⁴ versus underlying sample peak ≈0.0630957335. Root was notified to retain every second sample or all samples, with consistent time coordinates. Root retained all 2000 samples; an executed recheck gives a plot peak equal to the underlying 0.0630957335 sample peak. `audio-alias-after.json` pins that repaired wrapper and result. The earlier edge-case command output was observed directly but its exact simultaneous file hash was not independently captured; the preceding general probe pinned the then-current 500-point wrapper. Synthesis itself is correctly Nyquist-validated; this defect concerned the displayed response. Round-three acceptance must still verify the final regenerated dossier.

## Independent numerical checks

Seven acoustic native tests and focused ESLint pass. The added round-two test constructs the potential independently from material density/compressibility:

U(x)=V E_ac[f₀ cos²(kx)−(3/2)f₁ sin²(kx)].

Central finite differences of this potential at three nontrivial positions agree with the production signed force to relative 10⁻⁸. Independent 1000-panel Simpson quadrature of force agrees with U(start)−U(end) to relative 10⁻⁹. An explicit negative assumed contrast reverses the signed force and leaves its absolute maximum unchanged. This checks the spatial sign and pressure convention through a different numerical operation; it does not establish experimental accuracy. The six earlier null, scaling, threshold, domain, allocation and beating-identity tests remain passing (`audio-tests.txt`).

`audio-wrapper-probe.mts` executes the real root wrapper. At default inputs, maximum force is 1.3000823799398536×10⁻⁸ N versus an independently simplified pressure expression of 1.3000823799398532×10⁻⁸ N. Zero pressure, zero contrast, signed buoyancy for sub-medium density, invalid-radius and invalid-pressure withholding, nonfinite/out-of-range rejection and finite quiet audio bounds pass. High pressure (5000 Pa) and radius (3 mm) return no force metrics or curve, with validity warnings. The model reports peak antinode pressure consistently, not RMS or supply voltage. A necessary maximum-force comparison is not interpreted as 3D capture or a solved equilibrium.

The drawn 8 mm bead and transducer gap remain assumed scene geometry. They are not the current 0.1 mm model radius or an acoustic solution, and their legend explicitly identifies the bead as a target rather than observed levitation. Similarly, headphones/analyzer geometry does not turn the summed monaural signal into a binaural physiological model. The separate small-particle force and recorded/drawn apparatus boundaries must remain visible.

## Clinical-source countercheck

Independently read the captured dental review’s risk-of-bias/GRADE, comparator-result, limitations and conclusion passages in `sources/clinical-dental-2025.xml` (SHA-256 `005cdce1b33c6a936306c1b81aa531e1c9c4413891102d8c80c634280d076378`; DOI 10.5005/jp-journals-10005-3230). The paper explicitly calls certainty **low**. Its dental-pain comparison against no intervention reports MD −3.30 with interval [−37.67,31.06] and I²=94%; the interval includes no effect and heterogeneity is considerable. This is not evidence that an arbitrary pitch heals. Other comparisons/clinical anxiety endpoints are different analyses, with selection/detection bias and limited blinding. No forest-plot reconstruction or individual-trial reanalysis was performed.

The 2023 EEG review concerns neural entrainment under selected dichotic protocols. The 2025 dental review concerns specific clinical outcomes and comparators. A possible clinical outcome does not prove EEG entrainment as its mechanism, and inconsistent EEG findings do not prove every clinical intervention ineffective. Existing source descriptions preserve this distinction and the app generates neither endpoint. No source was silently reassigned to the monaural oscillator demonstration.

## Falsifier and remaining round-three gate

The physical falsifier remains a calibrated within-domain force/position sweep that departs from the declared pressure², contrast-sign or zero-field controls beyond uncertainty. Neither an out-of-domain formula nor a persuasive illustration can settle that question.

Round three should verify the actual repaired high-carrier plot, portable waveform conventions, zero-contrast control, invalid-domain metric/curve absence and final source/dossier hashes. No additional model complexity is requested. Experimental field calibration, viscosity/streaming corrections, real 3D stability and clinical evidence remain finite limitations rather than implied results.
